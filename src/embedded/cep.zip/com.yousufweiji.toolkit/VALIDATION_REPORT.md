# 6.5.1 — Advanced tab repair

Fixed the missing Advanced-mode navigation handlers. Previously the Import page remained visible when another mode was clicked. All ten tiles now switch their corresponding pages. Native buttons also support keyboard activation and expose the selected state.

Fixed a duplicate btnStripMeta ID shared by Fix and Advanced > Optimize. The Advanced metadata action now has its own ID and handler.

Retains the 6.5.0 SOP upgrade, stage options, Prebuild layouts and ScriptUI. Production Studio remains removed. Versions updated together to 6.5.1.

Validation: reproduced the original navigation failure in 6.5.0, then tested all ten modes, all 46 action-button bindings, ten representative mocked host dispatches, Enter/Space activation and leaving/reopening Advanced. No browser page errors. Static syntax/ES3, public API, DOM references, duplicate DOM IDs, script includes and host references passed. Manifest XML parsed; ZIP CRC verified.

This patch fixes panel navigation and wiring. Actual Illustrator execution of every Advanced operation has not been tested; browser dispatch tests use a simulated bridge.

Install: close Illustrator, replace the existing com.yousufweiji.toolkit folder with the folder from this ZIP (do not merge), then reopen Illustrator.

Previous 6.5.0 evidence is retained under docs/validation; advanced-tests.json and static-results.json are the fresh 6.5.1 results.
