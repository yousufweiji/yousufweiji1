// client/utils-ui.js — Standalone-script UIs integrated into the panel
'use strict';

window.YWUtils = function () {
  // ═══════════════════════════════════════════════════════════════
  // LAYER TOGGLE — visibility manager
  // ═══════════════════════════════════════════════════════════════
  function openLayerToggle() {
    const modal = _buildModal('Layer Toggle', 620, async body => {
      body.innerHTML = `
                <div style="padding:12px">
                    <div style="font-size:10px;color:var(--muted);margin-bottom:10px">Show/hide hall map layer groups. Quick presets below.</div>
                    <div style="display:flex;gap:6px;margin-bottom:10px">
                        <button class="btn primary" id="ltShowAll" style="flex:1;margin:0">Show All</button>
                        <button class="btn danger"  id="ltHideAll" style="flex:1;margin:0">Hide All</button>
                        <button class="btn"         id="ltRefresh" style="flex:0 0 70px;margin:0">↻ Refresh</button>
                    </div>
                    <div id="ltGrid" style="display:grid;grid-template-columns:1fr auto auto auto auto auto;gap:4px;align-items:center;font-size:10px;margin-bottom:14px">
                        <div style="font-weight:700;color:var(--muted);padding:4px">Layer Type</div>
                        <div style="font-weight:700;color:var(--muted);padding:4px;text-align:center">Count</div>
                        <div style="font-weight:700;color:var(--muted);padding:4px;text-align:center">Status</div>
                        <div></div><div></div><div></div>
                    </div>
                    <div style="font-size:10px;font-weight:700;color:var(--muted);text-transform:uppercase;margin-bottom:6px">Quick Presets</div>
                    <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:5px">
                        <button class="btn" id="ltPreSeatsOnly">🪑 Seats Only</button>
                        <button class="btn" id="ltPreSectionsOnly">📐 Sections Only</button>
                        <button class="btn" id="ltPreLabelsOnly">🏷 Labels Only</button>
                        <button class="btn" id="ltPreGeometry">⊞ Geometry</button>
                        <button class="btn" id="ltPreHideSeats">🚫 Hide Seats</button>
                        <button class="btn" id="ltPreFullMap">🗺 Full Map</button>
                    </div>
                    <div id="ltSummary" style="margin-top:12px;padding:8px;background:var(--bg3);border-radius:4px;font-size:10px;color:var(--muted)"></div>
                </div>`;
      await _ltRefresh(body);
      body.querySelector('#ltRefresh').onclick = () => _ltRefresh(body);
      body.querySelector('#ltShowAll').onclick = () => _ltBulk('showAll', body);
      body.querySelector('#ltHideAll').onclick = () => _ltBulk('hideAll', body);
      const presets = {
        ltPreSeatsOnly: ['SEAT', 'STAGE'],
        ltPreSectionsOnly: ['SECTION', 'SECTIONDECORATION', 'DECORATION', 'STAGE'],
        ltPreLabelsOnly: ['SECTIONDECORATION', 'DECORATION', 'STAGE'],
        ltPreGeometry: ['SECTION', 'SEAT', 'STAGE'],
        ltPreHideSeats: ['SECTION', 'SECTIONDECORATION', 'DECORATION', 'STAGE', 'SEATLABELS'],
        ltPreFullMap: ['SECTION', 'SECTIONDECORATION', 'SEAT', 'SEATDECORATION', 'UNDERSEATDECORATION', 'DECORATION', 'STAGE', 'SEATLABELS']
      };
      Object.keys(presets).forEach(id => {
        const btn = body.querySelector('#' + id);
        if (btn) btn.onclick = () => _ltPreset(presets[id], body);
      });
    });
  }
  async function _ltRefresh(body) {
    try {
      const r = await window.YWRunOp('layerToggleScan()', 'layer-scan');
      // Guard: if JSX wasn't reloaded yet, layerToggleScan returns ''
      // and run() resolves with 'Done.' — JSON.parse('Done.') errors with "D".
      if (typeof r !== 'string' || r.charAt(0) !== '{') {
        throw new Error('JSX not reloaded. Close & reopen the panel ' + '(Window > Extensions > Yousufweiji Hall Map Toolkit) ' + 'so Illustrator picks up the new sopFunctions.jsx. ' + '(Got: ' + String(r).slice(0, 60) + ')');
      }
      const data = JSON.parse(r);
      if (data.error) throw new Error(data.error);
      const grid = body.querySelector('#ltGrid');
      // Clear except header (first 6 cells)
      while (grid.children.length > 6) grid.removeChild(grid.lastChild);
      let totalGroups = 0,
        totalLegacy = 0;
      data.types.forEach(t => {
        totalGroups += t.count;
        totalLegacy += t.legacy || 0;
        const label = document.createElement('div');
        label.style.cssText = `padding:4px 6px;color:${t.count > 0 ? 'var(--text)' : 'var(--muted)'};font-weight:${t.count > 0 ? '700' : '400'}`;
        label.textContent = t.label;
        const count = document.createElement('div');
        count.style.cssText = 'text-align:center;color:var(--accent);padding:4px';
        let countText = String(t.count);
        if (t.legacy > 0) countText += ` <span style="color:var(--red);font-size:9px">⚠${t.legacy}</span>`;
        count.innerHTML = countText;
        const status = document.createElement('div');
        const sColor = t.status === 'VISIBLE' ? 'var(--green)' : t.status === 'HIDDEN' ? 'var(--red)' : t.status === 'MIXED' ? 'var(--orange)' : 'var(--muted)';
        status.style.cssText = `text-align:center;color:${sColor};padding:4px;font-size:9px;font-weight:700`;
        status.textContent = t.status;
        const bShow = document.createElement('button');
        bShow.className = 'btn';
        bShow.style.margin = '0';
        bShow.style.padding = '3px 8px';
        bShow.style.fontSize = '9px';
        bShow.textContent = 'Show';
        bShow.disabled = t.count === 0;
        bShow.onclick = () => _ltAct(t.label, 'show', body);
        const bHide = document.createElement('button');
        bHide.className = 'btn';
        bHide.style.margin = '0';
        bHide.style.padding = '3px 8px';
        bHide.style.fontSize = '9px';
        bHide.textContent = 'Hide';
        bHide.disabled = t.count === 0;
        bHide.onclick = () => _ltAct(t.label, 'hide', body);
        const bSolo = document.createElement('button');
        bSolo.className = 'btn primary';
        bSolo.style.margin = '0';
        bSolo.style.padding = '3px 8px';
        bSolo.style.fontSize = '9px';
        bSolo.textContent = 'Solo';
        bSolo.disabled = t.count === 0;
        bSolo.onclick = () => _ltAct(t.label, 'solo', body);
        grid.appendChild(label);
        grid.appendChild(count);
        grid.appendChild(status);
        grid.appendChild(bShow);
        grid.appendChild(bHide);
        grid.appendChild(bSolo);
      });
      const sum = body.querySelector('#ltSummary');
      let html = `Total groups: <b>${totalGroups}</b> · Layer types: <b>${data.types.length}</b>`;
      if (totalLegacy > 0) {
        html += `<div style="margin-top:6px;color:var(--red);font-weight:700">⚠ ${totalLegacy} group(s) use legacy _n_ suffix</div>`;
        html += `<div style="color:var(--muted);font-size:9px;margin-top:2px">SOP requires clean names — run FIX → Structure → Fix Sublayer Names</div>`;
      }
      sum.innerHTML = html;
    } catch (e) {
      if (window.YWToast) window.YWToast.error('Scan failed: ' + e);
    }
  }
  async function _ltAct(label, action, body) {
    try {
      await window.YWRunOp(`layerToggleAct("${label}","${action}")`, 'layer-' + action);
      await _ltRefresh(body);
    } catch (e) {
      if (window.YWToast) window.YWToast.error(String(e));
    }
  }
  async function _ltBulk(action, body) {
    try {
      await window.YWRunOp(`layerToggleBulk("${action}")`, 'layer-bulk');
      await _ltRefresh(body);
    } catch (e) {
      if (window.YWToast) window.YWToast.error(String(e));
    }
  }
  async function _ltPreset(labels, body) {
    try {
      await window.YWRunOp(`layerTogglePreset(${JSON.stringify(JSON.stringify(labels))})`, 'layer-preset');
      await _ltRefresh(body);
      if (window.YWToast) window.YWToast.success('Preset applied');
    } catch (e) {
      if (window.YWToast) window.YWToast.error(String(e));
    }
  }

  // ═══════════════════════════════════════════════════════════════
  // RESIZE SEATS (v2.1 enhanced UI — already exists in main.js,
  // this adds a dedicated modal for discoverability)
  // ═══════════════════════════════════════════════════════════════
  function openResizeSeats() {
    _buildModal('Resize & Reflow Seats', 520, body => {
      body.innerHTML = `
                <div style="padding:14px">
                    <div class="card info" style="font-size:10px;margin-bottom:10px">
                        <strong style="color:var(--accent)">SOP:</strong> 7×7 px seats · 9 px step · 2 px gap · 27 px aisle.
                        Detects rows by Y-centre, preserves aisles, reflows to uniform spacing.
                    </div>

                    <div class="sl" style="margin-top:4px">Mode</div>
                    <div class="btn-row" style="margin-bottom:8px">
                        <button class="btn primary" data-rsmode="reflow" id="rsModeReflow">⊳ Reflow (9px)</button>
                        <button class="btn"         data-rsmode="resize" id="rsModeResize">📐 Resize Only</button>
                    </div>

                    <div class="sl">Options</div>
                    <div class="toggle-row"><input type="checkbox" id="rsRemoveStroke" checked><label for="rsRemoveStroke">Remove seat strokes</label></div>
                    <div class="toggle-row"><input type="checkbox" id="rsAlignRowY" checked><label for="rsAlignRowY">Align row Y-centres (straighten rows)</label></div>
                    <div class="toggle-row"><input type="checkbox" id="rsPreviewOnly"><label for="rsPreviewOnly">Preview only (no changes)</label></div>
                    <div class="toggle-row"><input type="checkbox" id="rsAutoSnap" checked><label for="rsAutoSnap">Auto-snapshot before resize</label></div>

                    <div class="inp-row" style="margin-top:6px">
                        <div class="inp-group"><label>Aisle threshold (px)</label><input id="rsAisleThresh" type="number" value="20" min="5" max="200"></div>
                        <div class="inp-group"><label>Row Y tolerance (px)</label><input id="rsRowTol" type="number" value="4" min="1" max="20"></div>
                    </div>

                    <button class="btn primary" id="rsRun" style="margin-top:10px;padding:8px;font-weight:700">📐 Run Resize & Reflow</button>
                    <div id="rsReport" class="qa-report" style="display:none;margin-top:8px;max-height:280px"></div>
                </div>`;
      let mode = 'reflow';
      body.querySelectorAll('[data-rsmode]').forEach(b => {
        b.onclick = () => {
          mode = b.dataset.rsmode;
          body.querySelectorAll('[data-rsmode]').forEach(x => x.classList.remove('primary'));
          b.classList.add('primary');
        };
      });
      body.querySelector('#rsRun').onclick = async () => {
        const autoSnap = body.querySelector('#rsAutoSnap').checked;
        const previewOnly = body.querySelector('#rsPreviewOnly').checked;
        if (autoSnap && !previewOnly) {
          if (window.YWToast) window.YWToast.info('Creating snapshot…');
          try {
            await window.YWRunOp('createBackupSnapshot("resize-seats")', 'snapshot');
          } catch (e) {}
        }
        const ps = JSON.stringify({
          mode,
          removeStroke: body.querySelector('#rsRemoveStroke').checked,
          alignRowY: body.querySelector('#rsAlignRowY').checked,
          previewOnly,
          aisleThresh: parseFloat(body.querySelector('#rsAisleThresh').value) || 20,
          rowTolerance: parseFloat(body.querySelector('#rsRowTol').value) || 4
        }).replace(/'/g, "\\'");
        body.querySelector('#rsRun').disabled = true;
        try {
          const r = await window.YWRunOp(`seatResizerRun('${ps}')`, 'resize-seats');
          const rpt = body.querySelector('#rsReport');
          rpt.style.display = 'block';
          rpt.textContent = r;
          if (window.YWToast) window.YWToast.success('Resize complete');
        } catch (e) {
          if (window.YWToast) window.YWToast.error(String(e));
        } finally {
          body.querySelector('#rsRun').disabled = false;
        }
      };
    });
  }

  // ═══════════════════════════════════════════════════════════════
  // CONVERT TO SEAT SHAPE — turns selected paths into 7×7 rounded rects
  // with deduplication by centre proximity
  // ═══════════════════════════════════════════════════════════════
  function openConvertToSeat() {
    _buildModal('Convert to Seat Shape', 460, body => {
      body.innerHTML = `
                <div style="padding:14px">
                    <div class="card info" style="font-size:10px;margin-bottom:10px">
                        Converts selected paths/groups to SOP-compliant <b>7×7 px</b> rounded rects (rx/ry = 1.5).
                        Auto-deduplicates paths sharing the same centre (±tolerance).
                    </div>

                    <div class="sl">Settings</div>
                    <div class="inp-row">
                        <div class="inp-group"><label>Dedupe tolerance (px)</label><input id="csDedup" type="number" value="2" min="0" max="10" step="0.5"></div>
                        <div class="inp-group"><label>Default fill (hex)</label><input id="csFill" type="text" value="#CCCCCC" maxlength="7"></div>
                    </div>

                    <div class="toggle-row"><input type="checkbox" id="csKeepFill" checked><label for="csKeepFill">Preserve original path's fill colour</label></div>
                    <div class="toggle-row"><input type="checkbox" id="csGroup" checked><label for="csGroup">Place new seats in "CONVERTED_SEATS" group</label></div>
                    <div class="toggle-row"><input type="checkbox" id="csRemoveOrig" checked><label for="csRemoveOrig">Remove original paths after conversion</label></div>
                    <div class="toggle-row"><input type="checkbox" id="csAutoSnap" checked><label for="csAutoSnap">Auto-snapshot first</label></div>

                    <button class="btn primary" id="csRun" style="margin-top:10px;padding:8px;font-weight:700">🔄 Convert Selection → 7×7 Seats</button>
                    <div id="csReport" class="qa-report" style="display:none;margin-top:8px;max-height:240px"></div>
                </div>`;
      body.querySelector('#csRun').onclick = async () => {
        const autoSnap = body.querySelector('#csAutoSnap').checked;
        if (autoSnap) {
          try {
            await window.YWRunOp('createBackupSnapshot("convert-seats")', 'snapshot');
          } catch (e) {}
        }
        const ps = JSON.stringify({
          tolerance: parseFloat(body.querySelector('#csDedup').value) || 2,
          fill: body.querySelector('#csFill').value || '#CCCCCC',
          keepFill: body.querySelector('#csKeepFill').checked,
          group: body.querySelector('#csGroup').checked,
          removeOrig: body.querySelector('#csRemoveOrig').checked
        }).replace(/'/g, "\\'");
        body.querySelector('#csRun').disabled = true;
        try {
          const r = await window.YWRunOp(`convertToSeatShape('${ps}')`, 'convert-seats');
          const rpt = body.querySelector('#csReport');
          rpt.style.display = 'block';
          rpt.textContent = r;
          if (window.YWToast) window.YWToast.success('Convert complete');
        } catch (e) {
          if (window.YWToast) window.YWToast.error(String(e));
        } finally {
          body.querySelector('#csRun').disabled = false;
        }
      };
    });
  }

  // ═══════════════════════════════════════════════════════════════
  // SEATS TO ZONE — builds full SOP zone hierarchy from selection
  // ═══════════════════════════════════════════════════════════════
  function openSeatsToZone() {
    _buildModal('Seats → Zone Hierarchy', 540, body => {
      body.innerHTML = `
                <div style="padding:14px">
                    <div class="card info" style="font-size:10px;margin-bottom:10px">
                        Builds complete SOP zone hierarchy around selected seats:<br>
                        <code style="color:var(--accent)">ZONE_name → SECTION_1_ · UNDERSEATDECORATION · SEAT_1_ · SEATDECORATION · SECTIONDECORATION_1_</code>
                    </div>

                    <div class="sl">Step 1 — Scan selection</div>
                    <button class="btn" id="szScan" style="margin-bottom:10px">🔍 Detect Clusters</button>
                    <div id="szClusters" style="margin-bottom:10px"></div>

                    <div class="sl">Options</div>
                    <div class="inp-row">
                        <div class="inp-group"><label>Section padding (px)</label><input id="szPad" type="number" value="6" min="0" max="50"></div>
                        <div class="inp-group"><label>Label font size (px)</label><input id="szFont" type="number" value="30" min="8" max="120"></div>
                    </div>
                    <div class="toggle-row"><input type="checkbox" id="szCreateSL" checked><label for="szCreateSL">Create SEATLABELS group if missing</label></div>
                    <div class="toggle-row"><input type="checkbox" id="szAutoSnap" checked><label for="szAutoSnap">Auto-snapshot first</label></div>

                    <button class="btn primary" id="szBuild" style="margin-top:10px;padding:8px;font-weight:700" disabled>🏗 Build Zone Hierarchy</button>
                    <div id="szReport" class="qa-report" style="display:none;margin-top:8px;max-height:200px"></div>
                </div>`;
      let clusters = [];
      body.querySelector('#szScan').onclick = async () => {
        try {
          const r = await window.YWRunOp('seatsToZoneScan()', 'stz-scan');
          if (typeof r !== 'string' || r.charAt(0) !== '{') {
            throw new Error('JSX not reloaded. Reopen the panel so Illustrator picks up new sopFunctions.jsx.');
          }
          const data = JSON.parse(r);
          if (data.error) throw new Error(data.error);
          clusters = data.clusters || [];
          _szRenderClusters(body, clusters);
          body.querySelector('#szBuild').disabled = clusters.length === 0;
        } catch (e) {
          if (window.YWToast) window.YWToast.error(String(e));
        }
      };
      body.querySelector('#szBuild').onclick = async () => {
        if (clusters.length === 0) return;
        // Collect zone names from inputs
        const names = [];
        body.querySelectorAll('[data-cluster-idx]').forEach(inp => {
          names[parseInt(inp.dataset.clusterIdx)] = inp.value.trim().toUpperCase().replace(/[^A-Z0-9]/g, '') || 'Z' + (parseInt(inp.dataset.clusterIdx) + 1);
        });
        if (body.querySelector('#szAutoSnap').checked) {
          try {
            await window.YWRunOp('createBackupSnapshot("seats-to-zone")', 'snapshot');
          } catch (e) {}
        }
        const ps = JSON.stringify({
          zoneNames: names,
          padding: parseFloat(body.querySelector('#szPad').value) || 6,
          fontSize: parseFloat(body.querySelector('#szFont').value) || 30,
          createSeatLabels: body.querySelector('#szCreateSL').checked
        }).replace(/'/g, "\\'");
        body.querySelector('#szBuild').disabled = true;
        try {
          const r = await window.YWRunOp(`seatsToZoneBuild('${ps}')`, 'stz-build');
          const rpt = body.querySelector('#szReport');
          rpt.style.display = 'block';
          rpt.textContent = r;
          if (window.YWToast) window.YWToast.success('Zones built');
        } catch (e) {
          if (window.YWToast) window.YWToast.error(String(e));
        } finally {
          body.querySelector('#szBuild').disabled = false;
        }
      };
    });
  }
  function _szRenderClusters(body, clusters) {
    const box = body.querySelector('#szClusters');
    if (clusters.length === 0) {
      box.innerHTML = '<div style="color:var(--muted);font-size:10px;padding:12px;text-align:center">No clusters found. Select seats and click Scan.</div>';
      return;
    }
    box.innerHTML = '<div style="font-size:10px;color:var(--muted);margin-bottom:4px">Found ' + clusters.length + ' cluster(s). Name each zone:</div>';
    const grid = document.createElement('div');
    grid.style.cssText = 'display:grid;grid-template-columns:1fr auto;gap:6px;max-height:140px;overflow-y:auto';
    clusters.forEach((c, i) => {
      const lbl = document.createElement('div');
      lbl.style.cssText = 'padding:4px 8px;background:var(--bg3);border:1px solid var(--border);border-radius:3px;font-size:10px';
      lbl.innerHTML = `Cluster ${i + 1} <span style="color:var(--muted)">(${c.seatCount} seats${c.sourceName ? ' · from ' + c.sourceName : ''})</span>`;
      const inp = document.createElement('input');
      inp.type = 'text';
      inp.maxLength = 15;
      inp.dataset.clusterIdx = i;
      inp.value = c.suggestedName || 'Z' + (i + 1);
      inp.style.cssText = 'width:120px;padding:3px 6px;background:var(--bg3);border:1px solid var(--border);border-radius:3px;color:var(--text);font-size:10px;text-transform:uppercase';
      grid.appendChild(lbl);
      grid.appendChild(inp);
    });
    box.appendChild(grid);
  }

  // ═══════════════════════════════════════════════════════════════
  // HIERARCHY VALIDATOR — dedicated 10-item check modal
  // ═══════════════════════════════════════════════════════════════
  function openHierarchyValidator() {
    _buildModal('Hierarchy Validator (10 Items)', 560, async body => {
      body.innerHTML = `
                <div style="padding:14px">
                    <div class="card info" style="font-size:10px;margin-bottom:10px">
                        10-item layer hierarchy compliance check (SOP §4). Click Run to validate the active document.
                    </div>
                    <div style="display:flex;gap:6px;margin-bottom:10px">
                        <button class="btn primary" id="hvRun" style="flex:1;padding:8px;font-weight:700">▶ Run Validator</button>
                        <button class="btn"         id="hvAutoFix" style="flex:1;padding:8px">🔧 Auto-Fix Issues</button>
                    </div>
                    <div id="hvChecks" style="font-size:10.5px"></div>
                    <div id="hvSummary" style="margin-top:10px;padding:8px 10px;background:var(--bg3);border-radius:4px;display:none"></div>
                </div>`;
      const runCheck = async () => {
        body.querySelector('#hvChecks').innerHTML = '<div style="padding:20px;text-align:center;color:var(--muted)">Running 10 checks…</div>';
        body.querySelector('#hvSummary').style.display = 'none';
        try {
          const r = await window.YWRunOp('hierarchyValidate()', 'hierarchy-validate');
          if (typeof r !== 'string' || r.charAt(0) !== '{') {
            throw new Error('JSX not reloaded. Close & reopen the panel so Illustrator loads the new sopFunctions.jsx. (Got: ' + String(r).slice(0, 60) + ')');
          }
          const data = JSON.parse(r);
          if (data.error) throw new Error(data.error);
          _hvRender(body, data);
        } catch (e) {
          body.querySelector('#hvChecks').innerHTML = '<div style="color:var(--red);padding:12px">' + String(e) + '</div>';
        }
      };
      body.querySelector('#hvRun').onclick = runCheck;
      body.querySelector('#hvAutoFix').onclick = async () => {
        if (!confirm('Auto-fix will run: fixSubLayerNames, fixZOrder, addSEATLABELS, fixSectionOneShape, fixStageGroup. Create snapshot first?')) return;
        try {
          await window.YWRunOp('createBackupSnapshot("hier-autofix")', 'snapshot');
          await window.YWRunOp('fixSubLayerNames()', 'fix1');
          await window.YWRunOp('fixZOrder()', 'fix2');
          await window.YWRunOp('addSEATLABELS()', 'fix3');
          await window.YWRunOp('fixSectionOneShape()', 'fix4');
          await window.YWRunOp('fixStageGroup()', 'fix5');
          if (window.YWToast) window.YWToast.success('Auto-fix done — re-running validator');
          await runCheck();
        } catch (e) {
          if (window.YWToast) window.YWToast.error(String(e));
        }
      };
      await runCheck();
    });
  }
  function _hvRender(body, data) {
    const box = body.querySelector('#hvChecks');
    box.innerHTML = '';
    let pass = 0,
      fail = 0,
      warn = 0;
    (data.checks || []).forEach((c, i) => {
      let statusColor, icon;
      if (c.status === 'pass') {
        statusColor = 'var(--green)';
        icon = '✓';
        pass++;
      } else if (c.status === 'fail') {
        statusColor = 'var(--red)';
        icon = '✘';
        fail++;
      } else {
        statusColor = 'var(--orange)';
        icon = '⚠';
        warn++;
      }
      const row = document.createElement('div');
      row.style.cssText = `display:grid;grid-template-columns:20px 20px 1fr auto;gap:6px;padding:6px 8px;margin-bottom:3px;background:var(--bg3);border:1px solid var(--border);border-left:3px solid ${statusColor};border-radius:3px;align-items:center`;
      row.innerHTML = `
                <span style="color:var(--muted);text-align:right;font-size:9px">${String(i + 1).padStart(2, '0')}</span>
                <span style="color:${statusColor};font-weight:700;font-size:13px;text-align:center">${icon}</span>
                <span style="color:var(--text);font-size:10.5px">${c.label}${c.detail ? '<span style="color:var(--muted);font-size:9.5px"> — ' + c.detail + '</span>' : ''}</span>
                <span style="color:${statusColor};font-size:9px;font-weight:700;text-transform:uppercase">${c.status}</span>`;
      box.appendChild(row);
    });
    const sum = body.querySelector('#hvSummary');
    sum.style.display = 'block';
    const total = pass + fail + warn;
    const pct = total ? Math.round(pass / total * 100) : 0;
    let cls = fail === 0 && warn === 0 ? 'success' : fail > 0 ? 'error' : 'warn';
    const bg = {
      success: '#173325',
      warn: '#3a2a15',
      error: '#3a1919'
    }[cls];
    const fg = {
      success: 'var(--green)',
      warn: 'var(--orange)',
      error: 'var(--red)'
    }[cls];
    sum.style.background = bg;
    sum.innerHTML = `<div style="color:${fg};font-weight:700;font-size:11px">
            ${pass}/${total} passing (${pct}%) · ${fail} failed · ${warn} warnings
        </div><div style="color:var(--muted);font-size:9.5px;margin-top:4px">
            ${fail === 0 && warn === 0 ? '✓ All hierarchy checks pass — ready to export' : 'Click Auto-Fix to run standard repairs'}
        </div>`;
  }

  // ═══════════════════════════════════════════════════════════════
  // MODAL BUILDER (reusable)
  // ═══════════════════════════════════════════════════════════════
  function _buildModal(title, width, onMount) {
    const existing = document.getElementById('yw-util-modal');
    if (existing) existing.remove();
    const modal = document.createElement('div');
    modal.id = 'yw-util-modal';
    modal.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.75);z-index:10002;display:flex;align-items:center;justify-content:center;padding:10px';
    modal.innerHTML = `
            <div style="background:var(--bg2);border:1px solid var(--border2);border-radius:8px;width:100%;max-width:${width}px;max-height:92vh;display:flex;flex-direction:column;box-shadow:0 12px 40px rgba(0,0,0,.6)">
                <div style="padding:10px 14px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between;flex-shrink:0">
                    <div style="font-weight:800;font-size:1.1em;color:var(--text)">${title}</div>
                    <button class="sp-close" id="ywUtilClose">✕</button>
                </div>
                <div id="ywUtilBody" style="flex:1;overflow-y:auto;min-height:0"></div>
            </div>`;
    document.body.appendChild(modal);
    modal.onclick = e => {
      if (e.target === modal) modal.remove();
    };
    modal.querySelector('#ywUtilClose').onclick = () => modal.remove();
    if (onMount) onMount(modal.querySelector('#ywUtilBody'));
    return modal;
  }
  return {
    openLayerToggle,
    openResizeSeats,
    openConvertToSeat,
    openSeatsToZone,
    openHierarchyValidator
  };
}();