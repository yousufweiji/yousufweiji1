// Hall Map Toolkit 6.5.1. One host operation at a time; timeout never implies cancellation.
'use strict';

window.YWBridge = function () {
  var cs,
    state = 'init',
    busy = false,
    version = '',
    listener = null,
    cancelled = false,
    pendingProbe = null;
  function change(s, m) {
    state = s;
    if (listener) listener(s, m);
  }
  function init(c) {
    cs = c;
  }
  function evaluate(code, ms) {
    return new Promise(function (resolve, reject) {
      var done = false,
        t = setTimeout(function () {
          if (!done) {
            done = true;
            reject(new Error('Illustrator did not respond within ' + Math.round(ms / 1000) + ' seconds.'));
          }
        }, ms);
      try {
        cs.evalScript(code, function (r) {
          if (done) return;
          done = true;
          clearTimeout(t);
          resolve(String(r == null ? '' : r));
        });
      } catch (e) {
        clearTimeout(t);
        done = true;
        reject(e);
      }
    });
  }
  function quote(v) {
    return JSON.stringify(String(v)).replace(/\u2028/g, '\\u2028').replace(/\u2029/g, '\\u2029');
  }
  function ensureHostScriptLoaded(callback) {
    evaluate('typeof testCEP === "function" && typeof YW_HOST_VERSION !== "undefined" && YW_HOST_VERSION === "6.5.1"', 10000).then(function (r) {
      if (r === 'true') return 'Bridge fully operational';
      var p = cs.getSystemPath(SystemPath.EXTENSION);
      if (!p) throw new Error('Cannot resolve extension installation path.');
      p = String(p).replace(/\\/g, '/');
      if (/^file:\/\/\/[^/]/i.test(p)) {
        p = p.replace(/^file:\/\/\//i, '');
        if (!/^[A-Za-z]:/.test(p)) p = '/' + p;
      } else if (/^file:\/\//i.test(p)) p = p.replace(/^file:/i, '');
      try {
        p = decodeURI(p);
      } catch (e) {}
      p = p.replace(/\/$/, '') + '/jsx/sopFunctions.jsx';
      return evaluate('(function(){try{var f=new File(' + quote(p) + ');if(!f.exists)throw new Error("Missing JSX: "+f.fsName);$.evalFile(f);if(typeof YW_HOST_VERSION==="undefined"||YW_HOST_VERSION!=="6.5.1")throw new Error("Incomplete or wrong JSX build");return testCEP();}catch(e){return "BOOTSTRAP_ERROR: "+e+" line="+(e.line||"?");}})()', 30000);
    }).then(function (r) {
      callback(r.indexOf('Bridge fully operational') !== -1, r);
    }, function (e) {
      callback(false, e.message);
    });
  }
  function probe() {
    if (pendingProbe) return pendingProbe;
    if (busy) return Promise.resolve(state);
    if (!cs || !window.__adobe_cep__) {
      change('offline', 'Open this panel in Illustrator to use host tools.');
      return Promise.resolve('offline');
    }
    change('init', 'Connecting to Illustrator…');
    pendingProbe = new Promise(function (resolve) {
      function attempt(n) {
        evaluate('app.version', 5000).then(function (r) {
          if (!/^\d+(?:\.\d+)*$/.test(r.trim())) throw new Error(r || 'Empty host response');
          version = r;
          ensureHostScriptLoaded(function (ok, detail) {
            change(ok ? 'ok' : 'warn', ok ? 'Bridge fully operational — Illustrator ' + version : detail);
            resolve(state);
          });
        }).catch(function (e) {
          if (n < 3) setTimeout(function () {
            attempt(n + 1);
          }, 700);else {
            change('down', 'Bridge unavailable: ' + e.message);
            resolve(state);
          }
        });
      }
      attempt(1);
    }).then(function (s) {
      pendingProbe = null;
      return s;
    });
    return pendingProbe;
  }
  function run(code, opts) {
    opts = opts || {};
    if (busy) return Promise.reject(new Error('Illustrator is still processing the previous operation.'));
    if (state !== 'ok') return probe().then(function (s) {
      if (s !== 'ok') throw new Error('Host script unavailable. Reconnect the Illustrator bridge.');
      return run(code, opts);
    });
    busy = true;
    cancelled = false;
    return new Promise(function (resolve, reject) {
      var settled = false,
        t = setTimeout(function () {
          settled = true;
          change('warn', 'Operation timed out; Illustrator may still be running it. Wait for its response before continuing.');
          reject(new Error('Timed out. Host operation may still be running; further operations are blocked until it returns.'));
        }, opts.timeout || 180000);
      try {
        cs.evalScript('(function(){try{return eval(' + quote(code) + ');}catch(e){return "ERROR: "+e+" line="+(e.line||"?");}})()', function (r) {
          clearTimeout(t);
          busy = false;
          if (settled) {
            change('ok', 'Previous host operation returned. Review the document before retrying.');
            return;
          }
          settled = true;
          if (cancelled) return reject(new Error('Result dismissed. Illustrator finished the operation; changes may have been applied.'));
          r = String(r == null ? '' : r);
          if (!r || /^(?:EvalScript error|CRITICAL ERROR|ERROR\b|EXPORT BLOCKED)|\berror\s*:/i.test(r)) return reject(new Error(r || 'Empty response from Illustrator.'));
          resolve(r);
        });
      } catch (e) {
        clearTimeout(t);
        busy = false;
        settled = true;
        reject(e);
      }
    });
  }
  var api = {
    init: init,
    run: run,
    probe: probe,
    ensureHostScriptLoaded: ensureHostScriptLoaded,
    cancel: function () {
      cancelled = true;
    },
    isBusy: function () {
      return busy;
    }
  };
  Object.defineProperty(api, 'state', {
    get: function () {
      return state;
    }
  });
  Object.defineProperty(api, 'aiVersion', {
    get: function () {
      return version;
    }
  });
  Object.defineProperty(api, 'onStateChange', {
    get: function () {
      return listener;
    },
    set: function (f) {
      listener = typeof f === 'function' ? f : null;
    }
  });
  return api;
}();