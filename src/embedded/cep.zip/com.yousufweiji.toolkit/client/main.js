// client/main.js — Yousufweiji Hall Map Toolkit v6.5.1
// CEP panel controller: bootstrap, bridge, status, button wiring
// Depends: CSInterface.js, bridge.js (YWBridge), helpers.js (YWToast/YWLog/YWState/YWShortcuts)
'use strict';

/* ═══════════════════════════════════════════════════════════════
   1 · Bootstrap — CSInterface + YWBridge init
   ═══════════════════════════════════════════════════════════════ */
let cs = null;
window.onload = function () {
  // ── CSInterface init ──────────────────────────────────────
  try {
    if (typeof CSInterface === 'undefined') throw new Error('CSInterface.js not found');
    cs = new CSInterface();
    window._csi = cs;
  } catch (err) {
    setSta('❌ CSInterface.js missing — ensure client/CSInterface.js exists.\n' + err, '#e85252');
    return;
  }

  // ── YWBridge init ─────────────────────────────────────────
  if (window.YWBridge) {
    YWBridge.init(cs);
    YWBridge.onStateChange = function (state, msg) {
      setBridgeState(state, msg);
      const color = state === 'ok' ? '#3ecf6e' : state === 'warn' ? '#f0923a' : '#e85252';
      const icon = state === 'ok' ? '✅ ' : state === 'warn' ? '⚠ ' : state === 'offline' ? '🔌 ' : '❌ ';
      if (state !== 'init') setSta(icon + msg, color);
      if (state === 'ok') setTimeout(refreshBadge, 900);
    };
  }

  // ── AI 2020: __adobe_cep__ may not be injected yet at parse time ──
  if (typeof window.__adobe_cep__ === 'undefined') {
    setBridgeState('offline', 'Running outside Illustrator — open via Window > Extensions.');
    setSta('❌ Open this panel inside Adobe Illustrator: Window → Extensions → Yousufweiji Hall Map Toolkit', '#e85252');
    wireAll();
    return;
  }

  // ── Theme + events ────────────────────────────────────────
  syncTheme();
  try {
    cs.addEventListener('com.adobe.csxs.events.ThemeColorChanged', syncTheme);
  } catch (_) {}

  // ── Restore saved state ───────────────────────────────────
  if (window.YWState) {
    const diagMode = YWState.get('diagMode', false);
    if (diagMode && window.YWLog) YWLog.enable();
    const savedFs = YWState.get('fontSize', 'm');
    document.documentElement.className = 'fs-' + savedFs;
    const fsBtns = document.querySelectorAll('.fs-btn');
    fsBtns.forEach(b => b.classList.toggle('active', b.dataset.fs === savedFs));
  }
  wireAll();
  runBridgeProbe();

  // ── UI controls ───────────────────────────────────────────
  const reBtn = document.getElementById('btnReconnect');
  if (reBtn) reBtn.onclick = runBridgeProbe;
  const dotEl = document.getElementById('connDot');
  if (dotEl) dotEl.onclick = runBridgeProbe;
  const diagBtn = document.getElementById('btnDiagProbe');
  if (diagBtn) diagBtn.onclick = runBridgeProbe;

  // Re-probe on panel focus if bridge is unhealthy
  window.addEventListener('focus', function () {
    schedBadge();
    if (window.YWBridge && YWBridge.state !== 'ok' && !YWBridge.isBusy()) runBridgeProbe();
  });

  // Double-click status bar → copy to clipboard
  const sb = document.getElementById('status');
  if (sb) sb.ondblclick = function () {
    try {
      const t = sb.textContent || '';
      navigator.clipboard.writeText(t);
      const orig = sb.style.outline;
      sb.style.outline = '1px solid #3ecf6e';
      setTimeout(() => {
        sb.style.outline = orig;
      }, 600);
      if (window.YWToast) YWToast.info('Copied to clipboard');
    } catch (_) {}
  };

  // Diagnostics toggle
  const diagToggle = document.getElementById('swDiagMode');
  if (diagToggle) {
    if (window.YWState) diagToggle.checked = YWState.get('diagMode', false);
    diagToggle.addEventListener('change', function () {
      if (window.YWLog) {
        diagToggle.checked ? YWLog.enable() : YWLog.disable();
      }
      if (window.YWState) YWState.set('diagMode', diagToggle.checked);
      if (window.YWToast) YWToast.info('Diagnostics ' + (diagToggle.checked ? 'ON' : 'OFF'));
    });
  }

  // Export diagnostics log
  const diagExport = document.getElementById('btnExportDiag');
  if (diagExport) diagExport.onclick = function () {
    if (!window.YWLog) return;
    const dump = YWLog.dump() || '(empty)';
    const blob = new Blob([dump], {
      type: 'text/plain'
    });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'yw_diagnostics_' + Date.now() + '.txt';
    a.click();
  };
};

/* ═══════════════════════════════════════════════════════════════
   2 · Bridge probe
   ═══════════════════════════════════════════════════════════════ */
let _probeRunning = false;
function runBridgeProbe() {
  if (_probeRunning) return;
  _probeRunning = true;
  setBridgeState('init', 'Probing bridge…');
  setSta('Probing bridge…', '#4f8ef7');
  if (window.YWBridge) {
    YWBridge.probe().finally(() => {
      _probeRunning = false;
    });
  } else {
    // Fallback minimal probe
    probeBridgeFallback(1, function (state, msg) {
      _probeRunning = false;
      setBridgeState(state, msg);
      const color = state === 'ok' ? '#3ecf6e' : state === 'warn' ? '#f0923a' : '#e85252';
      const icon = state === 'ok' ? '✅ ' : state === 'warn' ? '⚠ ' : '❌ ';
      setSta(icon + msg, color);
      if (state === 'ok') setTimeout(refreshBadge, 900);
    });
  }
}
function probeBridgeFallback(attempt, cb) {
  if (!cs) return cb('down', 'CSInterface not ready');
  cs.evalScript('testCEP()', function (result) {
    if (result && result.indexOf('Bridge fully operational') !== -1) return cb('ok', result);
    cs.evalScript('app.version', function (raw) {
      const hasAI = raw && /^[\d.]+$/.test(String(raw).replace(/\s+/g, ''));
      if (hasAI && attempt < 3) return setTimeout(() => probeBridgeFallback(attempt + 1, cb), [0, 400, 900][attempt]);
      if (hasAI) return cb('warn', 'AI responds but testCEP() not defined — JSX may have a syntax error.');
      if (attempt < 3) return setTimeout(() => probeBridgeFallback(attempt + 1, cb), 700);
      cb('down', 'No response from Illustrator after 3 attempts.\nRun docs/INSTALL.ps1 → restart Illustrator → Reconnect.');
    });
  });
}

/* ═══════════════════════════════════════════════════════════════
   3 · UI state helpers
   ═══════════════════════════════════════════════════════════════ */
let _aiVersion = '';
function setBridgeState(state, label) {
  const dot = document.getElementById('connDot');
  if (dot) {
    dot.classList.remove('ok', 'warn', 'down', 'init', 'offline');
    dot.classList.add(state);
    dot.title = label || state;
  }
  const ver = document.getElementById('aiVer');
  if (ver && window.YWBridge) ver.textContent = state === 'ok' && YWBridge.aiVersion ? 'AI ' + YWBridge.aiVersion : '';
  const ds = document.getElementById('diagState');
  if (ds) {
    const pretty = {
      ok: 'CONNECTED',
      warn: 'PARTIAL',
      down: 'DOWN',
      init: 'PROBING…',
      offline: 'OFFLINE'
    }[state] || state;
    const col = {
      ok: '#3ecf6e',
      warn: '#f0923a',
      down: '#e85252',
      init: '#9b9b9b',
      offline: '#e85252'
    }[state] || '#ccc';
    ds.textContent = pretty;
    ds.style.color = col;
  }
  const dv = document.getElementById('diagAiVer');
  if (dv) dv.textContent = window.YWBridge && YWBridge.aiVersion || '--';
}
function setSta(msg, color) {
  color = color || '#3ecf6e';
  const el = document.getElementById('status');
  if (!el) return;
  el.innerHTML = String(msg).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/\n/g, '<br>');
  el.style.color = color;
  if (window.YWLog) YWLog.info('STATUS:', String(msg).replace(/<[^>]+>/g, '').slice(0, 120));
}
function cfor(t) {
  t = String(t || '');
  if (t.includes('FAIL') || t.includes('ERROR') || t.includes('CRITICAL')) return '#e85252';
  if (t.includes('WARNING') || t.includes('⚠')) return '#f0923a';
  return '#3ecf6e';
}
let _pt = null;
function showProg(on) {
  const f = document.getElementById('pf');
  if (!f) return;
  if (on) {
    let pct = 0;
    _pt = setInterval(() => {
      pct = Math.min(pct + Math.random() * 10, 88);
      f.style.width = pct + '%';
    }, 300);
  } else {
    clearInterval(_pt);
    f.style.width = '100%';
    setTimeout(() => {
      f.style.width = '0%';
    }, 500);
  }
}
function setAllDis(state) {
  const KEEP = ['tab', 'map-btn', 'fs-btn', 'sp-close', 'gear-btn', 'scope-chip', 'scope-action'];
  document.querySelectorAll('button,input,select').forEach(el => {
    for (const cls of KEEP) {
      if (el.classList.contains(cls)) return;
    }
    if (el.closest && el.closest('.settings-overlay')) return;
    if (el.id === 'btnCancel') return;
    el.disabled = !!state;
  });
  // Show cancel button row when busy
  const cancelRow = document.getElementById('cancelRow');
  if (cancelRow) cancelRow.style.display = state ? 'block' : 'none';
}

/* ═══════════════════════════════════════════════════════════════
   4 · Cancel support
   ═══════════════════════════════════════════════════════════════ */
const btnCancel = document.getElementById('btnCancel');
if (btnCancel) btnCancel.onclick = function () {
  if (window.YWBridge) YWBridge.cancel();
  setAllDis(false);
  showProg(false);
  setSta('Result dismissed. Illustrator may still be running; wait before retrying.', '#f0923a');
  if (window.YWToast) YWToast.warn('Illustrator execution cannot be cancelled by CEP');
};

/* ═══════════════════════════════════════════════════════════════
   5 · ExtendScript runner (wraps YWBridge.run or bare evalScript)
   ═══════════════════════════════════════════════════════════════ */
function run(code) {
  if (window.YWBridge && typeof YWBridge.run === 'function') {
    return YWBridge.run(code);
  }
  // Bare fallback (when bridge.js not loaded or YWBridge not ready)
  return new Promise((resolve, reject) => {
    if (!cs) return reject('CSInterface not ready.\nOpen panel inside Illustrator.');
    let settled = false;
    const timeout = setTimeout(() => {
      if (!settled) {
        settled = true;
        reject('Operation timed out after 3 minutes.');
      }
    }, 180000);
    cs.evalScript(code, result => {
      clearTimeout(timeout);
      if (settled) return;
      settled = true;
      if (result === null || result === undefined) return reject('No response.\n• Is a document open?\n• Check ESTK console for JSX errors');
      if (result === '') return resolve('Done.');
      if (/^CRITICAL ERROR/.test(result)) return reject(result);
      if (/^ERROR:/.test(result)) return reject(result);
      resolve(result);
    });
  });
}
// Expose for YWRunOp in helpers.js
window.run = run;

/* ═══════════════════════════════════════════════════════════════
   6 · Live seat count badge
   ═══════════════════════════════════════════════════════════════ */
let _sct = null;
function refreshBadge() {
  if (!cs || typeof window.__adobe_cep__ === 'undefined') return;
  cs.evalScript('quickSeatCount()', r => {
    const el = document.getElementById('liveBadge');
    if (el) el.textContent = r && !isNaN(parseInt(r, 10)) ? parseInt(r, 10).toLocaleString() + ' seats' : '-- seats';
  });
}
function schedBadge() {
  clearTimeout(_sct);
  _sct = setTimeout(refreshBadge, 1800);
}

/* ═══════════════════════════════════════════════════════════════
   7 · Theme sync with Illustrator dark/light
   ═══════════════════════════════════════════════════════════════ */
function syncTheme() {
  if (!cs) return;
  try {
    const env = cs.getHostEnvironment();
    if (!env || !env.appSkinInfo) return;
    const bg = env.appSkinInfo.panelBackgroundColor.color;
    const r = Math.round(bg.red),
      g = Math.round(bg.green),
      b = Math.round(bg.blue);
    const lum = 0.299 * r + 0.587 * g + 0.114 * b;
    const root = document.documentElement.style;
    let theme;
    if (lum < 60) {
      theme = 'darkest';
      root.setProperty('--bg', '#1e1e1e');
      root.setProperty('--bg2', '#252525');
      root.setProperty('--bg3', '#2d2d2d');
      root.setProperty('--bg4', '#363636');
      root.setProperty('--border', '#3a3a3a');
      root.setProperty('--border2', '#484848');
      root.setProperty('--text', '#cccccc');
      root.setProperty('--muted', '#6a6a6a');
    } else if (lum < 110) {
      theme = 'dark';
      root.setProperty('--bg', '#303030');
      root.setProperty('--bg2', '#393939');
      root.setProperty('--bg3', '#424242');
      root.setProperty('--bg4', '#4a4a4a');
      root.setProperty('--border', '#505050');
      root.setProperty('--border2', '#5e5e5e');
      root.setProperty('--text', '#d4d4d4');
      root.setProperty('--muted', '#808080');
    } else if (lum < 180) {
      theme = 'light';
      root.setProperty('--bg', '#b8b8b8');
      root.setProperty('--bg2', '#c4c4c4');
      root.setProperty('--bg3', '#d0d0d0');
      root.setProperty('--bg4', '#dadada');
      root.setProperty('--border', '#a0a0a0');
      root.setProperty('--border2', '#909090');
      root.setProperty('--text', '#2b2b2b');
      root.setProperty('--muted', '#606060');
      root.setProperty('--accent', '#2868c8');
      root.setProperty('--green', '#1a9e4a');
      root.setProperty('--orange', '#c06010');
      root.setProperty('--red', '#c03030');
    } else {
      theme = 'lightest';
      root.setProperty('--bg', '#e8e8e8');
      root.setProperty('--bg2', '#f0f0f0');
      root.setProperty('--bg3', '#f6f6f6');
      root.setProperty('--bg4', '#fafafa');
      root.setProperty('--border', '#c0c0c0');
      root.setProperty('--border2', '#b0b0b0');
      root.setProperty('--text', '#1a1a1a');
      root.setProperty('--muted', '#555555');
      root.setProperty('--accent', '#1a5ab8');
      root.setProperty('--green', '#0e7a38');
      root.setProperty('--orange', '#a05010');
      root.setProperty('--red', '#a02020');
    }
    // Exact AI panel bg colour override
    root.setProperty('--bg', 'rgb(' + r + ',' + g + ',' + b + ')');
    document.documentElement.setAttribute('data-theme', theme);
  } catch (_) {/* keep default dark theme */}
}

/* ═══════════════════════════════════════════════════════════════
   8 · Input helpers + generic wire()
   ═══════════════════════════════════════════════════════════════ */
const $ = id => document.getElementById(id);
function getPrefix() {
  const e = $('inPrefix');
  return e ? e.value.trim().toUpperCase() : '';
}
function getFrom() {
  const e = $('inFrom');
  return e ? e.value.trim().toUpperCase() : '';
}
function getTo() {
  const e = $('inTo');
  return e ? e.value.trim().toUpperCase() : '';
}
function escJS(s) {
  return String(s).replace(/\\/g, '\\\\').replace(/'/g, "\\'");
}
function wire(id, statusMsg, jsx, colOverride) {
  const btn = $(id);
  if (!btn) return;
  btn.onclick = async () => {
    setAllDis(true);
    showProg(true);
    setSta(statusMsg, '#4f8ef7');
    try {
      const r = await run(jsx);
      if (r && (r.includes('SOP §12') || r.includes('Checklist') || r.includes('==='))) {
        setSta('✅ Report ready — see Validate tab.', '#3ecf6e');
        if (typeof window.__setQAReport === 'function') window.__setQAReport(r);
      } else {
        setSta(r, colOverride || cfor(r));
      }
      schedBadge();
    } catch (e) {
      const msg = String(e);
      setSta(msg, '#e85252');
      if (window.YWToast) YWToast.error(msg.slice(0, 120));
    } finally {
      setAllDis(false);
      showProg(false);
    }
  };
}

/* ═══════════════════════════════════════════════════════════════
   9 · Wire all buttons (preserved from v2.2, upgraded)
   ═══════════════════════════════════════════════════════════════ */
function wireAll() {
  /* ── VALIDATE tab — wired ONCE in the main VALIDATE block below ─── */
  /*    (FIX 9: removed duplicate wires that overwrote each other)    */

  /* ── FIX tab — RECOVERY ─────────────────────────────── */
  wire('btnFixAll', 'Running Full Recovery (50+ ops)…', 'fixAllSOP()');

  /* ── FIX tab — COLOURS ─────────────────────────────── */
  wire('btnFixFills', 'Fixing section fills → #F1F1F1…', 'fixSectionFills()');
  wire('btnFixSectionStroke', 'Fixing section strokes → #D1D2D4…', 'fixSectionStrokes()');
  wire('btnFixStrokes', 'Removing seat strokes…', 'fixSeatStrokes()');
  wire('btnFixSeatOpacity', 'Fixing seat opacity → 100%…', 'fixSeatOpacity()');
  wire('btnFixLabels', 'Fixing label colours → #6d6e70…', 'fixLabelColors()');
  wire('btnFixTextStrokes', 'Removing text strokes…', 'fixTextStrokes()');
  wire('btnFixDecoFill', 'Fixing decor badge fills…', 'fixDecorBadgeFills()');
  wire('btnFixCanvasBG', 'Cleaning canvas background…', 'cleanCanvasBackground()');

  /* ── FIX tab — IDS ─────────────────────────────────── */
  wire('btnAutoFixIDs', 'Auto-fixing all seat IDs…', 'autoFixSeatIDs()');
  wire('btnFixDupHash', 'Fixing duplicate hashes…', 'fixDuplicateHashes()');
  wire('btnFixMalformed', 'Fixing malformed IDs…', 'fixMalformedIDs()');
  wire('btnFixSeatMatch', 'Fixing SEAT field mismatch…', 'fixSeatFieldMismatch()');
  wire('btnFixField4', 'Fixing field 4 ≠ 1…', 'fixField4()');
  wire('btnFixGroupHyphens', 'Removing GROUP hyphens…', 'fixGroupHyphens()');
  wire('btnFixHashSpaces', 'Removing hash spaces…', 'fixHashSpaces()');
  wire('btnFixPrefix', 'Fixing seatData case…', 'fixSeatDataCase()');
  wire('btnRegenAllHash', 'Regenerating all hashes…', 'regenAllHashes()');

  /* ── FIX tab — SIZES ───────────────────────────────── */
  wire('btnFixSizes', 'Resizing seats to 7×7px…', 'fixSeatSizes()');
  wire('btnFixRxRy', 'Fixing rx/ry to 1.5…', 'fixRxRy()');
  wire('btnFixSelSize', 'Resizing selection to 7×7px…', 'fixSelectionSize()');
  wire('btnFixSpacing', 'Snapping to 9px grid…', 'snapToGrid()');
  wire('btnFlattenTransforms', 'Flattening transforms…', 'flattenTransforms()');
  wire('btnAlignPixels', 'Aligning to pixel grid…', 'alignToPixelGrid()');

  /* ── FIX tab — SEAT RESIZER (v2.1) ─────────────────── */
  // Mode toggle buttons
  var _srMode = 'reflow';
  document.querySelectorAll('.srmode-opt').forEach(function (b) {
    b.onclick = function () {
      _srMode = b.dataset.srmode;
      document.querySelectorAll('.srmode-opt').forEach(function (x) {
        x.classList.remove('active');
      });
      b.classList.add('active');
    };
  });
  const btnSR = $('btnSeatResizer');
  if (btnSR) btnSR.onclick = async () => {
    const mode = _srMode;
    const removeStroke = $('srRemoveStroke') ? $('srRemoveStroke').checked : true;
    const alignRowY = $('srAlignRowY') ? $('srAlignRowY').checked : true;
    const previewOnly = $('srPreviewOnly') ? $('srPreviewOnly').checked : false;
    const aisleThresh = parseFloat(($('srAisleThresh') || {}).value || '20') || 20;
    const rowTolerance = parseFloat(($('srRowTol') || {}).value || '4') || 4;
    const ps = JSON.stringify({
      mode,
      removeStroke,
      alignRowY,
      previewOnly,
      aisleThresh,
      rowTolerance
    }).replace(/'/g, "\\'");
    setAllDis(true);
    showProg(true);
    setSta((previewOnly ? 'Previewing' : 'Running') + ' Seat Resizer & Reflow (' + mode + ')…', '#4f8ef7');
    try {
      const r = await run("seatResizerRun('" + ps + "')");
      setSta(r.includes('✅') ? '✅ Seat Resizer complete — see report below.' : r, cfor(r));
      const box = $('srReportBox');
      if (box) {
        box.style.display = 'block';
        box.textContent = r;
      }
      schedBadge();
    } catch (e) {
      setSta(String(e), '#e85252');
    } finally {
      setAllDis(false);
      showProg(false);
    }
  };

  /* ── FIX tab — IMAGE → VECTOR ───────────────────────── */
  var _iv2Preset = '[Default]';
  var _iv2Layer = 'active';
  document.querySelectorAll('.iv2-preset').forEach(function (b) {
    b.onclick = function () {
      _iv2Preset = b.dataset.preset;
      document.querySelectorAll('.iv2-preset').forEach(function (x) {
        x.classList.remove('active');
      });
      b.classList.add('active');
    };
  });
  document.querySelectorAll('.iv2-layer').forEach(function (b) {
    b.onclick = function () {
      _iv2Layer = b.dataset.layer;
      document.querySelectorAll('.iv2-layer').forEach(function (x) {
        x.classList.remove('active');
      });
      b.classList.add('active');
    };
  });
  function iv2Run(action) {
    return async function () {
      const fp = ($('iv2FilePath') || {}).value || '';
      if (!fp && action !== 'load') {
        setSta('⚠ Enter image file path first.', '#f5a623');
        return;
      }
      const ps = JSON.stringify({
        filePath: fp,
        preset: _iv2Preset,
        threshold: parseInt(($('iv2Threshold') || {}).value || '128') || 128,
        removeWhite: $('iv2RemoveWhite') ? $('iv2RemoveWhite').checked : true,
        removeRasters: $('iv2RemoveRasters') ? $('iv2RemoveRasters').checked : true,
        targetLayer: _iv2Layer,
        action: action
      }).replace(/'/g, "\\'");
      setAllDis(true);
      showProg(true);
      setSta((action === 'load' ? 'Loading' : 'Tracing') + ' image…', '#4f8ef7');
      try {
        const r = await run("imageToVectorRun('" + ps + "')");
        setSta(r.includes('✅') ? '✅ Image→Vector complete.' : r.split('\n')[0], cfor(r));
        const box = $('iv2ReportBox');
        if (box) {
          box.style.display = 'block';
          box.textContent = r;
        }
      } catch (e) {
        setSta(String(e), '#e85252');
      } finally {
        setAllDis(false);
        showProg(false);
      }
    };
  }
  const btnIL = $('btnImgLoad');
  if (btnIL) btnIL.onclick = iv2Run('load');
  const btnIT = $('btnImgTrace');
  if (btnIT) btnIT.onclick = iv2Run('trace');

  /* ── FIX tab — DIAMONDS / FACE STAGE DIRECTION ─────── */
  var _fsdScope = 'document';
  var _fsdMode = 'fix';
  document.querySelectorAll('.fsd-scope').forEach(function (b) {
    b.onclick = function () {
      _fsdScope = b.dataset.scope;
      document.querySelectorAll('.fsd-scope').forEach(function (x) {
        x.classList.remove('active');
      });
      b.classList.add('active');
    };
  });
  document.querySelectorAll('.fsd-mode').forEach(function (b) {
    b.onclick = function () {
      _fsdMode = b.dataset.fsdmode;
      document.querySelectorAll('.fsd-mode').forEach(function (x) {
        x.classList.remove('active');
      });
      b.classList.add('active');
    };
  });
  const btnFS = $('btnFaceStage');
  if (btnFS) btnFS.onclick = async () => {
    const ps = JSON.stringify({
      scope: _fsdScope,
      mode: _fsdMode,
      fixOnly: $('fsdFixOnly') ? $('fsdFixOnly').checked : true,
      stageX: ($('fsdStageX') || {}).value || '',
      stageY: ($('fsdStageY') || {}).value || ''
    }).replace(/'/g, "\\'");
    setAllDis(true);
    showProg(true);
    setSta('Running Face Stage Direction (' + _fsdMode + ')…', '#4f8ef7');
    try {
      const r = await run("faceStageDirectionRun('" + ps + "')");
      setSta(r.includes('✅') ? '✅ Face Stage Direction complete.' : r.split('\n')[0], cfor(r));
      const box = $('fsdReportBox');
      if (box) {
        box.style.display = 'block';
        box.textContent = r;
      }
      schedBadge();
    } catch (e) {
      setSta(String(e), '#e85252');
    } finally {
      setAllDis(false);
      showProg(false);
    }
  };

  /* ── FIX tab — MULTI-ZONE ALIGNER ──────────────────── */
  var _mzaScope = 'all';
  document.querySelectorAll('.mza-scope').forEach(function (b) {
    b.onclick = function () {
      _mzaScope = b.dataset.mzascope;
      document.querySelectorAll('.mza-scope').forEach(function (x) {
        x.classList.remove('active');
      });
      b.classList.add('active');
    };
  });
  function mzaRun(operation) {
    return async function () {
      const ps = JSON.stringify({
        scope: _mzaScope,
        namedList: ($('mzaNameList') || {}).value || '',
        operation: operation
      }).replace(/'/g, "\\'");
      setAllDis(true);
      showProg(true);
      setSta('Zone Aligner: ' + operation + '…', '#4f8ef7');
      try {
        const r = await run("multiZoneAlignerRun('" + ps + "')");
        setSta(r.includes('✅') ? '✅ Zone Aligner: ' + operation + ' complete.' : r.split('\n')[0], cfor(r));
        const box = $('mzaReportBox');
        if (box) {
          box.style.display = 'block';
          box.textContent = r;
        }
        schedBadge();
      } catch (e) {
        setSta(String(e), '#e85252');
      } finally {
        setAllDis(false);
        showProg(false);
      }
    };
  }
  const _mzaOps = {
    btnMzaStageAxis: 'stageAxis',
    btnMzaTopEdge: 'top',
    btnMzaBotEdge: 'bottom',
    btnMzaLeftEdge: 'left',
    btnMzaRightEdge: 'right',
    btnMzaCentreH: 'centreH',
    btnMzaCentreV: 'centreV',
    btnMzaAnalyse: 'analyse',
    btnMzaDistH: 'distH',
    btnMzaDistV: 'distV',
    btnMzaSnapGrid: 'snapGrid',
    btnMzaFixSymm: 'fixSymm'
  };
  Object.keys(_mzaOps).forEach(function (id) {
    var btn = $(id);
    if (btn) btn.onclick = mzaRun(_mzaOps[id]);
  });

  /* ── FIX tab — STRUCTURE ───────────────────────────── */
  wire('btnFixNames', 'Fixing sublayer names…', 'fixSubLayerNames()');
  wire('btnFixSDNest', 'Flattening SECTIONDECORATION…', 'fixSectionDecorationNesting()');
  wire('btnAddSL', 'Adding SEATLABELS…', 'addSEATLABELS()');
  wire('btnFixZOrder', 'Fixing z-order…', 'fixZOrder()');
  wire('btnFixSecOneShape', 'Fixing section shapes…', 'fixSectionOneShape()');
  wire('btnFixSecNoText', 'Moving text from SECTION…', 'moveTextFromSection()');

  /* ── FIX tab — LAYERS ──────────────────────────────── */
  wire('btnCleanHide', 'Deleting hidden layers…', 'cleanHiddenLayers()');
  wire('btnCleanEmpty', 'Deleting empty groups…', 'cleanEmptyGroups()');
  wire('btnCleanStray', 'Removing stray objects…', 'removeStrayObjects()');
  wire('btnCleanGuides', 'Removing guides…', 'removeAllGuides()');
  wire('btnUnlockAll', 'Unlocking all layers…', 'unlockAllLayers()');
  wire('btnShowAll', 'Showing all layers…', 'showAllLayers()');

  /* ── FIX tab — FORBIDDEN ───────────────────────────── */
  wire('btnRemoveAllForbidden', 'Removing all forbidden elements…', 'removeAllForbidden()');
  wire('btnRmClipPath', 'Removing clipPaths…', 'removeForbiddenType("clipPath")');
  wire('btnRmMask', 'Removing masks…', 'removeForbiddenType("mask")');
  wire('btnRmSymbol', 'Removing symbols/use…', 'removeForbiddenType("symbol")');
  wire('btnRmImage', 'Removing images…', 'removeForbiddenType("image")');
  wire('btnRmFilter', 'Removing filters…', 'removeForbiddenType("filter")');
  wire('btnRmCircle', 'Removing circles/ellipses…', 'removeForbiddenType("circle")');
  wire('btnRmPolygon', 'Removing polygons…', 'removeForbiddenType("polygon")');
  wire('btnConvertCircles', 'Converting circles to rects…', 'convertCirclesToRects()');

  /* ── FIX tab — STAGE ───────────────────────────────── */
  wire('btnFixStage', 'Fixing STAGE group…', 'fixStageGroup()');
  wire('btnFixStageFill', 'Fixing stage fill…', 'fixStageFill()');
  wire('btnFixStageLabel', 'Moving stage label to DECORATION…', 'fixStageLabel()');
  wire('btnFixStageNoSub', 'Flattening stage sub-groups…', 'flattenStageGroup()');

  /* ── FIX tab — SVG CLEAN ───────────────────────────── */
  wire('btnFixSVGFile', 'Opening SVG file picker…', 'fixSVGFile()', '#e85252');
  wire('btnStripMeta', 'Stripping metadata…', 'stripSVGMetadata()');
  wire('btnStripComments', 'Stripping comments…', 'stripSVGComments()');
  wire('btnFixSVGIDs', 'Fixing renamed IDs…', 'fixRenamedSVGIDs()');
  wire('btnOptimizePaths', 'Optimizing paths…', 'optimizeSVGPaths()');

  /* ── FIX tab — DIAGNOSE ────────────────────────────── */
  const btnDiag = $('btnDiagnose');
  if (btnDiag) btnDiag.onclick = async () => {
    setAllDis(true);
    showProg(true);
    setSta('Running full diagnostics…', '#4f8ef7');
    try {
      const r = await run('runFullDiagnostics()');
      setSta('Diagnostics complete — see report.', '#3ecf6e');
      var box = $('diagReportBox');
      if (box) {
        box.style.display = 'block';
        box.textContent = r;
      }
      if (typeof window.__setQAReport === 'function') window.__setQAReport(r);
    } catch (e) {
      setSta(String(e), '#e85252');
    } finally {
      setAllDis(false);
      showProg(false);
    }
  };
  wire('btnDiagForbidden', 'Scanning for forbidden elements…', 'scanForbiddenElements()');
  wire('btnDiagIDs', 'Scanning for bad IDs…', 'scanBadIDs()');
  wire('btnDiagDupes', 'Scanning for duplicates…', 'findDuplicates()');
  wire('btnDiagSizes', 'Scanning wrong-size seats…', 'scanWrongSizeSeats()');
  wire('btnDiagHierarchy', 'Checking hierarchy…', 'checkHierarchy()');
  wire('btnDiagFileSize', 'Checking file size…', 'checkDocFileSize()');

  /* ── VALIDATE tab ──────────────────────────────────── */
  wire('btnChecklist', 'Running full 23-item checklist…', 'runFullChecklist()');
  wire('btnValidate', 'Validating geometry + IDs…', 'validateGeometry()');
  wire('btnDuplicates', 'Scanning for duplicate IDs…', 'findDuplicates()');
  wire('btnSeatCount', 'Counting seats by zone…', 'detailedSeatCount()');
  wire('btnValidateIDs', 'Validating ID format…', 'validateIDFormat()');
  wire('btnCheckHierarchy', 'Checking layer hierarchy…', 'checkHierarchy()');
  wire('btnCheckForbidden', 'Scanning for forbidden tags…', 'scanForbiddenElements()');
  wire('btnCheckZOrder', 'Checking z-order…', 'checkZOrder()');
  wire('btnCheckFileSize', 'Checking file size…', 'checkDocFileSize()');
  const btnCC = $('btnCrossCheck');
  if (btnCC) btnCC.onclick = async () => {
    const expected = ($('valExpected') ? $('valExpected').value : '').trim();
    if (!expected || isNaN(parseInt(expected))) {
      setSta('Enter expected seat total from manifest.', '#f0923a');
      return;
    }
    setAllDis(true);
    showProg(true);
    setSta('Cross-checking seat count vs manifest…', '#4f8ef7');
    try {
      const r = await run("crossCheckManifest(" + parseInt(expected) + ")");
      setSta(r, cfor(r));
      if (typeof window.__setQAReport === 'function') window.__setQAReport(r);
    } catch (e) {
      setSta(String(e), '#e85252');
    } finally {
      setAllDis(false);
      showProg(false);
    }
  };

  /* ── EXPORT tab ────────────────────────────────────── */
  wire('btnPLSave', 'Saving document…', 'platinumlistSave()', '#d4a017');
  wire('btnExport', 'Exporting SVG…', 'stripAndExport()');
  wire('btnExportAI', 'Exporting AI backup copy…', 'exportAICopy()');
  wire('btnPreCheck', 'Running full checklist…', 'runFullChecklist()');
  wire('btnQuickAudit', 'Running quick pre-flight…', 'quickPreFlight()');
  wire('btnExportCatJPEG', 'Exporting category map JPEG…', 'exportCategoryJPEG()');
  wire('btnFixSVGFile2', 'Opening SVG file picker…', 'fixSVGFile()', '#e85252');

  /* ── BUILD tab — LAYERS+ (PL-01 enhanced) ───────────── */
  const btnBLH = $('btnBuildLayerHier');
  if (btnBLH) btnBLH.onclick = async () => {
    const cnt = ($('blZoneCount') ? $('blZoneCount').value : '4').trim();
    const pfx = ($('blZonePrefix') ? $('blZonePrefix').value : 'ZONE_').trim().toUpperCase();
    const clear = $('blClearExist') ? $('blClearExist').checked : false;
    const stage = $('blIncStage') ? $('blIncStage').checked : true;
    const sl = $('blIncSeatlabels') ? $('blIncSeatlabels').checked : true;
    const ps = JSON.stringify({
      zoneCount: parseInt(cnt) || 4,
      prefix: pfx,
      clearExisting: clear,
      includeStage: stage,
      includeSeatlabels: sl
    }).replace(/'/g, "\\'");
    setAllDis(true);
    showProg(true);
    setSta('Building layer-based SOP hierarchy…', '#4f8ef7');
    try {
      const r = await run("buildLayerHierarchy('" + ps + "')");
      setSta(r, cfor(r));
      schedBadge();
    } catch (e) {
      setSta(String(e), '#e85252');
    } finally {
      setAllDis(false);
      showProg(false);
    }
  };
  const btnQAZ = $('btnQuickAddZone');
  if (btnQAZ) btnQAZ.onclick = async () => {
    const zn = ($('blQuickZone') ? $('blQuickZone').value : '').trim().toUpperCase();
    if (!zn) {
      setSta('Enter a zone name (e.g. ZONE_VIP).', '#f0923a');
      return;
    }
    setAllDis(true);
    showProg(true);
    setSta('Adding zone layer "' + zn + '"…', '#4f8ef7');
    try {
      const r = await run("addZoneLayer('" + escJS(zn) + "')");
      setSta(r, cfor(r));
    } catch (e) {
      setSta(String(e), '#e85252');
    } finally {
      setAllDis(false);
      showProg(false);
    }
  };

  /* ── BUILD tab — STAGE+ (PL-02 enhanced) ──────────────── */
  
  

  /* ── BUILD tab — GEN IDS (PL-07 enhanced) ─────────────── */
  const btnGS = $('btnGenSingle');
  if (btnGS) btnGS.onclick = async () => {
    const grp = ($('idGroup') ? $('idGroup').value : '').trim().toUpperCase().replace(/[^A-Z0-9]/g, '');
    const seat = ($('idSeat') ? $('idSeat').value : '1').trim();
    if (!grp) {
      setSta('Enter a GROUP (zone+row, no hyphens).', '#f0923a');
      return;
    }
    setAllDis(true);
    showProg(true);
    setSta('Generating single seatData ID…', '#4f8ef7');
    try {
      const r = await run("generateSingleID('" + escJS(grp) + "'," + (parseInt(seat) || 1) + ")");
      setSta(r, cfor(r));
    } catch (e) {
      setSta(String(e), '#e85252');
    } finally {
      setAllDis(false);
      showProg(false);
    }
  };
  const btnGB = $('btnGenBatch');
  if (btnGB) btnGB.onclick = async () => {
    const grp = ($('idBatchGroup') ? $('idBatchGroup').value : '').trim().toUpperCase().replace(/[^A-Z0-9]/g, '');
    const from = parseInt($('idBatchFrom') ? $('idBatchFrom').value : '1') || 1;
    const to = parseInt($('idBatchTo') ? $('idBatchTo').value : '20') || 20;
    if (!grp) {
      setSta('Enter a GROUP prefix.', '#f0923a');
      return;
    }
    if (from > to) {
      setSta('From must be ≤ To.', '#f0923a');
      return;
    }
    const ps = JSON.stringify({
      group: grp,
      from: from,
      to: to
    }).replace(/'/g, "\\'");
    setAllDis(true);
    showProg(true);
    setSta('Generating batch IDs (' + grp + ' #' + from + '–' + to + ')…', '#4f8ef7');
    try {
      const r = await run("generateBatchIDs('" + ps + "')");
      setSta(r, cfor(r));
    } catch (e) {
      setSta(String(e), '#e85252');
    } finally {
      setAllDis(false);
      showProg(false);
    }
  };
  const btnGBA = $('btnGenBatchApply');
  if (btnGBA) btnGBA.onclick = async () => {
    const grp = ($('idBatchGroup') ? $('idBatchGroup').value : '').trim().toUpperCase().replace(/[^A-Z0-9]/g, '');
    const from = parseInt($('idBatchFrom') ? $('idBatchFrom').value : '1') || 1;
    const to = parseInt($('idBatchTo') ? $('idBatchTo').value : '20') || 20;
    if (!grp) {
      setSta('Enter a GROUP prefix.', '#f0923a');
      return;
    }
    const ps = JSON.stringify({
      group: grp,
      from: from,
      to: to
    }).replace(/'/g, "\\'");
    setAllDis(true);
    showProg(true);
    setSta('Applying batch IDs to selected seats…', '#4f8ef7');
    try {
      const r = await run("applyBatchIDsToSelection('" + ps + "')");
      setSta(r, cfor(r));
      schedBadge();
    } catch (e) {
      setSta(String(e), '#e85252');
    } finally {
      setAllDis(false);
      showProg(false);
    }
  };
  const btnGSel = $('btnGenSelection');
  if (btnGSel) btnGSel.onclick = async () => {
    const grp = ($('idSelGroup') ? $('idSelGroup').value : '').trim().toUpperCase().replace(/[^A-Z0-9]/g, '');
    const start = parseInt($('idSelStart') ? $('idSelStart').value : '1') || 1;
    const sort = $('idSelSort') ? $('idSelSort').value : 'topdown';
    if (!grp) {
      setSta('Enter a GROUP prefix.', '#f0923a');
      return;
    }
    const ps = JSON.stringify({
      group: grp,
      startSeat: start,
      sortOrder: sort
    }).replace(/'/g, "\\'");
    setAllDis(true);
    showProg(true);
    setSta('Assigning IDs to selected seats (' + sort + ')…', '#4f8ef7');
    try {
      const r = await run("assignIDsToSelection('" + ps + "')");
      setSta(r, cfor(r));
      schedBadge();
    } catch (e) {
      setSta(String(e), '#e85252');
    } finally {
      setAllDis(false);
      showProg(false);
    }
  };
  wire('btnSaveIDs', 'Saving all seat IDs to text file…', 'saveAllIDsToFile()');

  /* ── BUILD tab — RENAME (PL-09 enhanced) ──────────────── */
  const btnRen = $('btnRename');
  if (btnRen) btnRen.onclick = async () => {
    const f = getFrom(),
      t = getTo();
    const scope = $('rnScope') ? $('rnScope').value : 'prefix';
    const regenHash = $('rnRegenHash') ? $('rnRegenHash').checked : true;
    const preview = $('rnPreview') ? $('rnPreview').checked : true;
    if (scope !== 'all' && scope !== 'selected' && !f) {
      setSta('Enter the Old GROUP prefix to match.', '#f0923a');
      return;
    }
    if (!t) {
      setSta('Enter the New GROUP prefix.', '#f0923a');
      return;
    }
    if (f.includes('-') || t.includes('-')) {
      setSta('GROUP prefixes must not contain hyphens (SOP §6.1).', '#e85252');
      return;
    }
    const ps = JSON.stringify({
      oldPrefix: f,
      newPrefix: t,
      scope: scope,
      regenHash: regenHash,
      preview: preview
    }).replace(/'/g, "\\'");
    setAllDis(true);
    showProg(true);
    setSta('Renaming "' + f + '" → "' + t + '" (scope: ' + scope + ')…', '#4f8ef7');
    try {
      const r = await run("bulkRenameGroupPrefix('" + ps + "')");
      if (preview && r && r.indexOf('PREVIEW') >= 0) {
        var box = $('rnPreviewBox');
        if (box) {
          box.style.display = 'block';
          box.textContent = r;
        }
        setSta('Preview shown below. Uncheck preview and run again to apply.', '#f0923a');
      } else {
        setSta(r, cfor(r));
        var box2 = $('rnPreviewBox');
        if (box2) box2.style.display = 'none';
      }
      schedBadge();
    } catch (e) {
      setSta(String(e), '#e85252');
    } finally {
      setAllDis(false);
      showProg(false);
    }
  };

  /* ── BUILD tab — CATMAP (PL-12 enhanced) ──────────────── */
  const btnCatMap = $('btnCatMap');
  if (btnCatMap) btnCatMap.onclick = async () => {
    const cats = ($('cmCategories') ? $('cmCategories').value : '').trim();
    if (!cats) {
      setSta('Enter at least one category (NAME | PRICE per line).', '#f0923a');
      return;
    }
    const layout = $('cmLayout') ? $('cmLayout').value : 'horizontal';
    const boxW = parseFloat($('cmBoxW') ? $('cmBoxW').value : '200') || 200;
    const boxH = parseFloat($('cmBoxH') ? $('cmBoxH').value : '80') || 80;
    const spacing = parseFloat($('cmSpacing') ? $('cmSpacing').value : '20') || 20;
    const stageH = parseFloat($('cmStageH') ? $('cmStageH').value : '60') || 60;
    const showPrices = $('cmShowPrices') ? $('cmShowPrices').checked : true;
    const ps = JSON.stringify({
      categories: cats,
      layout: layout,
      boxWidth: boxW,
      boxHeight: boxH,
      spacing: spacing,
      stageHeight: stageH,
      showPrices: showPrices
    }).replace(/'/g, "\\'");
    setAllDis(true);
    showProg(true);
    setSta('Generating Category Selection Map…', '#4f8ef7');
    try {
      const r = await run("buildCategoryMap('" + ps + "')");
      setSta(r, cfor(r));
    } catch (e) {
      setSta(String(e), '#e85252');
    } finally {
      setAllDis(false);
      showProg(false);
    }
  };

  /* ── BUILD tab — NUMBERS (existing, preserved) ────────── */
  const btnBuild = $('btnBuild');
  if (btnBuild) btnBuild.onclick = async () => {
    const pfx = getPrefix();
    if (!pfx) {
      setSta('Enter a GROUP prefix first.\nExample: VIPA · 101A · SILVERCC', '#f0923a');
      $('inPrefix').focus();
      return;
    }
    setAllDis(true);
    showProg(true);
    setSta('Building SOP hierarchy for "' + pfx + '"…', '#4f8ef7');
    try {
      const r = await run("buildSOPHierarchy('" + escJS(pfx) + "')");
      setSta(r, cfor(r));
      schedBadge();
    } catch (e) {
      setSta(String(e), '#e85252');
    } finally {
      setAllDis(false);
      showProg(false);
    }
  };
  const btnGen = $('btnGenIDs');
  if (btnGen) btnGen.onclick = async () => {
    const pfx = getPrefix();
    if (!pfx) {
      setSta('Enter a GROUP prefix first.', '#f0923a');
      $('inPrefix').focus();
      return;
    }
    if (pfx.includes('-')) {
      setSta('GROUP prefix must NOT contain hyphens (SOP §6.1).', '#e85252');
      return;
    }
    setAllDis(true);
    showProg(true);
    setSta('Generating IDs with prefix "' + pfx + '"…', '#4f8ef7');
    try {
      const r = await run("generateSeatIDs('" + escJS(pfx) + "')");
      setSta(r, cfor(r));
    } catch (e) {
      setSta(String(e), '#e85252');
    } finally {
      setAllDis(false);
      showProg(false);
    }
  };
  wire('btnResequence', 'Re-sequencing seat numbers (whole doc)…', 'resequenceSeatNumbers()');
  wire('btnRenumber', 'Renumbering selected seats 1→N…', 'renumberSelectedSeats()');

  /* ── BUILD tab — ARENA (existing, new prefix input) ───── */
  const btnArena = $('btnArenaNum');
  if (btnArena) btnArena.onclick = async () => {
    const pfx = ($('arPrefix') ? $('arPrefix').value : '').trim().toUpperCase() || getPrefix();
    if (!pfx) {
      setSta('Enter a GROUP prefix for arena numbering.', '#f0923a');
      return;
    }
    setAllDis(true);
    showProg(true);
    setSta('Arena auto-numbering for "' + pfx + '"…', '#4f8ef7');
    try {
      const r = await run("autoNumberArena('" + escJS(pfx) + "')");
      setSta(r, cfor(r));
      schedBadge();
    } catch (e) {
      setSta(String(e), '#e85252');
    } finally {
      setAllDis(false);
      showProg(false);
    }
  };

  /* ── BUILD tab — SCALE (existing) ─────────────────────── */
  const btnScale = $('btnScaleRule');
  if (btnScale) btnScale.onclick = async () => {
    const sw = ($('inScale') ? $('inScale').value : '').trim();
    if (!sw || isNaN(parseFloat(sw))) {
      setSta('Enter source seat width first (e.g. 2.55).', '#f0923a');
      return;
    }
    setAllDis(true);
    showProg(true);
    setSta('Applying scale rule (source width: ' + sw + ')…', '#4f8ef7');
    try {
      const r = await run("applyScaleRule('" + escJS(sw) + "')");
      setSta(r, cfor(r));
    } catch (e) {
      setSta(String(e), '#e85252');
    } finally {
      setAllDis(false);
      showProg(false);
    }
  };

  /* ── BUILD tab — CONVERT (existing) ───────────────────── */
  wire('btnConvertShapes', 'Converting selection → SOP seats…', 'replaceWithSOPSeats()');

  /* ── Fix → Clean → Save (used in both FIX recovery and EXPORT) */
  function doFixAndSave() {
    setAllDis(true);
    showProg(true);
    setSta('Fix All → Clean → Validate → Save…', '#4f8ef7');
    (async () => {
      try {
        setSta('Step 1/4 — Full Recovery Fix…', '#4f8ef7');
        await run('fixAllSOP()');
        setSta('Step 2/4 — Clean hidden layers…', '#4f8ef7');
        await run('cleanHiddenLayers()');
        setSta('Step 3/4 — Quick pre-flight…', '#4f8ef7');
        await run('quickPreFlight()');
        setSta('Step 4/4 — Yousuf Weiji Save…', '#4f8ef7');
        const r = await run('platinumlistSave()');
        setSta(r, cfor(r));
      } catch (e) {
        setSta(String(e), '#e85252');
      } finally {
        setAllDis(false);
        showProg(false);
      }
    })();
  }
  // btnFS already used above (Face Stage Direction); rename to avoid
  // strict-mode "Identifier 'btnFS' has already been declared" crash.
  const btnFixSv = $('btnFixSave');
  if (btnFixSv) btnFixSv.onclick = doFixAndSave;
  const btnFAS = $('btnFixAndSave');
  if (btnFAS) btnFAS.onclick = doFixAndSave;

  /* ── ADVANCED tab (v4: 10-mode powerhouse) ──────────────── */

  window.__refreshScope = () => {
    if (!cs) return;
    cs.evalScript('listDocumentZones()', r => {
      if (r && typeof window.__populateScope === 'function') {
        window.__populateScope(r);
      }
    });
  };
  window.addEventListener('focus', () => {
    setTimeout(() => {
      window.__refreshScope();
    }, 2000);
  });

  /* -- Import sub-mode -- */
  const btnAutoImport = $('btnAutoImport');
  if (btnAutoImport) btnAutoImport.onclick = async () => {
    const ps = JSON.stringify({
      scale: parseFloat(($('inImportScale') || {}).value || '1') || 1,
      detectSeats: ($('cbImportDetectSeats') || {}).checked !== false,
      cleanup: ($('cbImportCleanup') || {}).checked !== false,
      buildSOP: ($('cbImportBuildSOP') || {}).checked !== false
    }).replace(/'/g, "\\'");
    setAllDis(true);
    showProg(true);
    setSta('Auto-detecting and importing…', '#4f8ef7');
    try {
      const r = await run("autoDetectImport('" + ps + "')");
      setSta(r, cfor(r));
    } catch (e) {
      setSta(String(e), '#e85252');
    } finally {
      setAllDis(false);
      showProg(false);
    }
  };
  const btnImportImage = $('btnImportImage');
  if (btnImportImage) btnImportImage.onclick = async () => {
    const ps = JSON.stringify({
      opacity: parseInt(($('inRefOpacity') || {}).value || '40') || 40,
      gridStep: parseInt(($('inRefGridStep') || {}).value || '90') || 90
    }).replace(/'/g, "\\'");
    setAllDis(true);
    showProg(true);
    setSta('Placing image reference + grid…', '#4f8ef7');
    try {
      const r = await run("importImageReference('" + ps + "')");
      setSta(r, cfor(r));
    } catch (e) {
      setSta(String(e), '#e85252');
    } finally {
      setAllDis(false);
      showProg(false);
    }
  };

  /* -- JSON→SVG sub-mode -- */
  const btnJsonToSvg = $('btnJsonToSvg');
  if (btnJsonToSvg) btnJsonToSvg.onclick = async () => {
    const ps = JSON.stringify({
      format: ($('selJsonFormat') || {}).value || 'auto',
      keySection: ($('inJsonKeySec') || {}).value || 'section',
      keyRow: ($('inJsonKeyRow') || {}).value || 'row',
      keySeat: ($('inJsonKeySeat') || {}).value || 'seat',
      scale: parseFloat(($('inJsonScale') || {}).value || '1') || 1
    }).replace(/'/g, "\\'");
    setAllDis(true);
    showProg(true);
    setSta('Converting JSON to SVG…', '#4f8ef7');
    try {
      const r = await run("jsonToSVG('" + ps + "')");
      setSta(r, cfor(r));
    } catch (e) {
      setSta(String(e), '#e85252');
    } finally {
      setAllDis(false);
      showProg(false);
    }
  };
  wire('btnSmartDetect', 'Detecting source layout…', 'detectSourceLayout()');

  /* -- PDF→SVG sub-mode -- */
  const btnPdfToSvg = $('btnPdfToSvg');
  if (btnPdfToSvg) btnPdfToSvg.onclick = async () => {
    const ps = JSON.stringify({
      scale: parseFloat(($('inPdfScale') || {}).value || '3') || 3,
      seatMin: parseInt(($('inPdfSeatMin') || {}).value || '3') || 3,
      seatMax: parseInt(($('inPdfSeatMax') || {}).value || '15') || 15,
      removeJunk: ($('cbPdfRemoveJunk') || {}).checked !== false,
      normalize: ($('cbPdfNormalize') || {}).checked !== false,
      groupByProximity: ($('cbPdfGroupProx') || {}).checked !== false,
      buildSOP: ($('cbPdfBuildSOP') || {}).checked !== false
    }).replace(/'/g, "\\'");
    setAllDis(true);
    showProg(true);
    setSta('Processing PDF → extracting seats…', '#4f8ef7');
    try {
      const r = await run("pdfToSVG('" + ps + "')");
      setSta(r, cfor(r));
    } catch (e) {
      setSta(String(e), '#e85252');
    } finally {
      setAllDis(false);
      showProg(false);
    }
  };

  /* -- CSV→SVG sub-mode -- */
  const btnCsvToSvg = $('btnCsvToSvg');
  if (btnCsvToSvg) btnCsvToSvg.onclick = async () => {
    const ps = JSON.stringify({
      layout: ($('selCsvLayout') || {}).value || 'grid',
      startX: parseInt(($('inCsvStartX') || {}).value || '500') || 500,
      startY: parseInt(($('inCsvStartY') || {}).value || '500') || 500,
      step: parseInt(($('inCsvStep') || {}).value || '9') || 9,
      zoneGap: parseInt(($('inCsvZoneGap') || {}).value || '100') || 100
    }).replace(/'/g, "\\'");
    setAllDis(true);
    showProg(true);
    setSta('Loading CSV → generating map…', '#4f8ef7');
    try {
      const r = await run("csvToSVG('" + ps + "')");
      setSta(r, cfor(r));
    } catch (e) {
      setSta(String(e), '#e85252');
    } finally {
      setAllDis(false);
      showProg(false);
    }
  };

  /* -- Turbo sub-mode -- */
  const btnTurboBuild = $('btnTurboBuild');
  if (btnTurboBuild) btnTurboBuild.onclick = async () => {
    var zoneLines = (($('inTurboZones') || {}).value || '').trim().split('\n').filter(function (l) {
      return l.trim();
    });
    var zones = [];
    for (var zi = 0; zi < zoneLines.length; zi++) {
      var parts = zoneLines[zi].split(',');
      if (parts.length >= 3) zones.push({
        code: (parts[0] || 'A').trim(),
        rows: parseInt(parts[1]) || 10,
        cols: parseInt(parts[2]) || 20,
        layout: (parts[3] || 'grid').trim(),
        startX: parseInt(parts[4]) || 500,
        startY: parseInt(parts[5]) || 500
      });
    }
    const ps = JSON.stringify({
      canvasW: parseInt(($('inTurboW') || {}).value || '5000') || 5000,
      canvasH: parseInt(($('inTurboH') || {}).value || '4000') || 4000,
      zones: zones,
      aisleAfter: ($('inTurboAisle') || {}).value || '',
      stagePos: ($('selTurboStage') || {}).value || 'bottom'
    }).replace(/'/g, "\\'");
    setAllDis(true);
    showProg(true);
    setSta('⚡ TURBO BUILD: 5-phase pipeline running…', '#9b72f0');
    try {
      const r = await run("turboBuild('" + ps + "')");
      setSta(r, cfor(r));
    } catch (e) {
      setSta(String(e), '#e85252');
    } finally {
      setAllDis(false);
      showProg(false);
    }
  };
  wire('btnBuildScratch', 'Opening interactive builder…', 'buildFromScratchInteractive()');

  /* -- Speed sub-mode -- */
  const btnSpeedBuild = $('btnSpeedBuild');
  if (btnSpeedBuild) btnSpeedBuild.onclick = async () => {
    var outName = (($('inSpeedOutput') || {}).value || '').trim() || 'hallmap_export';
    setAllDis(true);
    showProg(true);
    setSta('🚀 Speed Build: detect → manifest → build → export…', '#9b72f0');
    try {
      const r = await run("speedBuildComplete('" + escJS(outName) + "')");
      setSta(r, cfor(r));
    } catch (e) {
      setSta(String(e), '#e85252');
    } finally {
      setAllDis(false);
      showProg(false);
    }
  };
  wire('btnBatchFixFolder', 'Batch fixing all SVGs in folder…', 'batchFixFolder()');
  wire('btnBatchValidate', 'Batch validating folder…', 'batchValidateFolder()');
  wire('btnSnapshot', 'Saving version snapshot…', 'snapshotVersion()');
  wire('btnHashRegistry', 'Scanning for hash collisions…', 'hashRegistryCheck()');
  wire('btnStatusReport', 'Generating venue status report…', 'venueStatusReport()');
  wire('btnExportReport', 'Exporting checklist to file…', 'exportChecklistToFile()');

  /* -- Healer sub-mode -- */
  wire('btnAutoHealAll', 'Running full auto-heal (15 ops)…', 'autoHealAll()');
  wire('btnHealNames', 'Fixing layer names…', 'healSublayerNames()');
  wire('btnHealDupIDs', 'Re-hashing duplicate IDs…', 'healDuplicateIDs()');
  wire('btnHealMalformed', 'Fixing malformed IDs…', 'healMalformedIDs()');
  wire('btnHealGeometry', 'Enforcing 7×7 seat geometry…', 'healSeatGeometry()');
  wire('btnHealSeatColors', 'Normalizing seat colors…', 'healSeatColors()');
  wire('btnHealSectionColors', 'Fixing section #F1F1F1…', 'healSectionColors()');
  wire('btnHealTextColors', 'Fixing text colors…', 'healTextColors()');
  wire('btnHealOverlaps', 'Checking seat overlaps…', 'healOverlappingSeats()');
  wire('btnHealOrphans', 'Moving orphan seats…', 'healOrphanSeats()');
  wire('btnHealSublayers', 'Creating missing sublayers…', 'healMissingSublayers()');
  wire('btnHealHidden', 'Unhiding all layers…', 'healHiddenLayers()');
  wire('btnHealLocked', 'Unlocking all layers…', 'healLockedLayers()');
  wire('btnHealEmptyGroups', 'Removing empty groups…', 'healEmptyGroups()');
  wire('btnHealOutOfBounds', 'Checking seat bounds…', 'healOutOfBounds()');
  wire('btnHealStageTag', 'Tagging stage elements…', 'healStageDirection()');
  wire('btnBatchFixAll', 'Batch fix all + save…', 'batchFixAllAndSave()');

  /* -- Deep Clean sub-mode -- */
  const btnDeepScan = $('btnDeepScan');
  if (btnDeepScan) btnDeepScan.onclick = async () => {
    setAllDis(true);
    showProg(true);
    setSta('Scanning document for removable items…', '#4f8ef7');
    try {
      const r = await run("deepCleanScan()");
      setSta(r, cfor(r));
    } catch (e) {
      setSta(String(e), '#e85252');
    } finally {
      setAllDis(false);
      showProg(false);
    }
  };
  const btnDeepClean = $('btnDeepClean');
  if (btnDeepClean) btnDeepClean.onclick = async () => {
    const ps = JSON.stringify({
      invisible: ($('cbClnInvisible') || {}).checked !== false,
      zeroSize: ($('cbClnZeroSize') || {}).checked !== false,
      tiny: ($('cbClnTiny') || {}).checked !== false,
      stray: ($('cbClnStray') || {}).checked !== false,
      empty: ($('cbClnEmpty') || {}).checked !== false,
      guides: ($('cbClnGuides') || {}).checked !== false,
      lowOpacity: ($('cbClnLowOpacity') || {}).checked !== false,
      duplicates: ($('cbClnDuplicates') || {}).checked !== false,
      whiteFill: ($('cbClnWhiteFill') || {}).checked !== false,
      suffix: ($('cbClnSuffix') || {}).checked !== false,
      protectSeats: ($('cbClnProtectSeats') || {}).checked !== false,
      protectLabels: ($('cbClnProtectLabels') || {}).checked !== false,
      protectStage: ($('cbClnProtectStage') || {}).checked !== false
    }).replace(/'/g, "\\'");
    setAllDis(true);
    showProg(true);
    setSta('Deep cleaning document…', '#f0923a');
    try {
      const r = await run("deepCleanExecute('" + ps + "')");
      setSta(r, cfor(r));
    } catch (e) {
      setSta(String(e), '#e85252');
    } finally {
      setAllDis(false);
      showProg(false);
    }
  };

  /* -- Optimize sub-mode -- */
  wire('btnOptimizeSVG', 'Selecting SVG to optimize…', 'optimizeSVGFile()');
  wire('btnAdvStripMeta', 'Stripping metadata + comments…', 'stripSVGMetadata()');
  wire('btnReduceDecimals', 'Reducing decimals to 1dp…', 'reduceSVGDecimals()');
  wire('btnCollapseWS', 'Collapsing whitespace…', 'collapseSVGWhitespace()');
  wire('btnInjectRxRy', 'Injecting rx/ry on seats…', 'injectSeatRxRy()');
  wire('btnFixSVGExportIDs', 'Fixing _n_ IDs in exported SVG…', 'fixRenamedSVGIDs()');
  wire('btnFixSectionWhite', 'Fixing #FFFFFF → #F1F1F1…', 'fixSectionWhiteInSVG()');
  const btnSopExport = $('btnSopExport');
  if (btnSopExport) btnSopExport.onclick = async () => {
    var outName = (($('inSopExportName') || {}).value || '').trim() || 'venue_final';
    setAllDis(true);
    showProg(true);
    setSta('Full SOP Export + Optimize…', '#d4a017');
    try {
      const r = await run("sopExportFull('" + escJS(outName) + "')");
      setSta(r, cfor(r));
    } catch (e) {
      setSta(String(e), '#e85252');
    } finally {
      setAllDis(false);
      showProg(false);
    }
  };

  /* -- QA 50 sub-mode -- */
  const btnFullQA50 = $('btnFullQA50');
  if (btnFullQA50) btnFullQA50.onclick = async () => {
    setAllDis(true);
    showProg(true);
    setSta('Running full 50-point QA check…', '#9b72f0');
    try {
      const r = await run("fullQA50()");
      setSta(r, /[1-9]\d* FAIL|^ERROR/.test(r) ? "#e85252" : /PENDING/.test(r) ? "#f0923a" : cfor(r));
      var rpt = $('qaAdvReport');
      if (rpt) {
        rpt.style.display = 'block';
        rpt.textContent = r;
      }
    } catch (e) {
      setSta(String(e), '#e85252');
    } finally {
      setAllDis(false);
      showProg(false);
    }
  };
  wire('btnQuickValidateAdv', 'Running quick validate…', 'quickValidate()');
  const btnFullDiagnostic = $('btnFullDiagnostic');
  if (btnFullDiagnostic) btnFullDiagnostic.onclick = async () => {
    setAllDis(true);
    showProg(true);
    setSta('Running full diagnostics (6 categories)…', '#4f8ef7');
    try {
      const r = await run("fullDiagnosticTroubleshoot()");
      setSta(r, cfor(r));
      var rpt = $('qaAdvReport');
      if (rpt) {
        rpt.style.display = 'block';
        rpt.textContent = r;
      }
    } catch (e) {
      setSta(String(e), '#e85252');
    } finally {
      setAllDis(false);
      showProg(false);
    }
  };
  const btnQaCrossCheck = $('btnQaCrossCheck');
  if (btnQaCrossCheck) btnQaCrossCheck.onclick = async () => {
    var total = parseInt(($('inQaManifestTotal') || {}).value || '0') || 0;
    if (!total) {
      setSta('Enter expected seat total first.', '#f0923a');
      return;
    }
    setAllDis(true);
    showProg(true);
    setSta('Cross-checking manifest vs SVG…', '#4f8ef7');
    try {
      const r = await run("crossCheckManifest(" + total + ")");
      setSta(r, cfor(r));
    } catch (e) {
      setSta(String(e), '#e85252');
    } finally {
      setAllDis(false);
      showProg(false);
    }
  };

  /* ── MORE tab ──────────────────────────────────────────── */
  const btnBr = $('btnBridge');
  if (btnBr) btnBr.onclick = () => {
    setAllDis(true);
    showProg(true);
    setSta('Testing bridge…', '#4f8ef7');
    cs.evalScript('1+1', r => {
      setSta(r === '2' ? '✅ Bridge OK (1+1=2) — ExtendScript is responding.' : '⚠ Bridge returned: ' + (r || '(nothing)'), r === '2' ? '#3ecf6e' : '#f0923a');
      setAllDis(false);
      showProg(false);
    });
  };
  const btnRef = $('btnRefresh');
  if (btnRef) btnRef.onclick = () => {
    refreshBadge();
    setSta('Seat count refreshed.', '#3ecf6e');
  };
  wire('btnDocInfo', 'Getting document info…', 'getDocumentInfo()');
  wire('btnListZones', 'Listing all zones…', 'listAllZones()');
  wire('btnCountAll', 'Counting all seats…', 'totalSeatCount()');
  wire('btnSelectAll', 'Selecting all seats…', 'selectAllSeats()');

  /* ── CREATE tab — existing v3.5.0 handlers ─────────── */

  window.__pbRun = async paramsStr => {
    setAllDis(true);
    showProg(true);
    setSta('Generating map in Illustrator…', '#4f8ef7');
    try {
      const r = await run("preBuildMap('" + paramsStr.replace(/'/g, "\\'") + "')");
      setSta(r, cfor(r));
      schedBadge();
    } catch (e) {
      setSta(String(e), '#e85252');
    } finally {
      setAllDis(false);
      showProg(false);
    }
  };
  const btnGrab = $('btnCRGrab');
  if (btnGrab) btnGrab.onclick = () => {
    cs.evalScript('getSelectionCenter()', r => {
      if (r && !r.match(/^ERROR/)) {
        const parts = r.split(',');
        if (parts.length === 2) {
          const cxE = $('crCX'),
            cyE = $('crCY');
          if (cxE) cxE.value = parts[0];
          if (cyE) cyE.value = parts[1];
          setSta('Center from selection: (' + parts[0] + ', ' + parts[1] + ')', '#3ecf6e');
        }
      } else {
        setSta(r || 'No response', '#f0923a');
      }
    });
  };
  const btnCR = $('btnCurvedRow');
  if (btnCR) btnCR.onclick = async () => {
    const zone = ($('crZone') ? $('crZone').value : '').toUpperCase().replace(/[^A-Z0-9]/g, '');
    if (!zone) {
      setSta('Enter a zone prefix for the curved row.', '#f0923a');
      return;
    }
    const params = JSON.stringify({
      zone: zone,
      firstRow: $('crRow') ? $('crRow').value : 'A',
      seats: $('crSeats') ? $('crSeats').value : '21',
      cx: $('crCX') ? $('crCX').value : '',
      cy: $('crCY') ? $('crCY').value : '',
      radius: $('crRadius') ? $('crRadius').value : '360',
      arcDeg: $('crArc') ? $('crArc').value : '85',
      curvePct: $('crCurve') ? $('crCurve').value : '75',
      numRows: $('crRows') ? $('crRows').value : '1',
      radStep: $('crStep') ? $('crStep').value : '9',
      stagger: $('crStagger') ? $('crStagger').value : '0'
    }).replace(/'/g, "\\'");
    setAllDis(true);
    showProg(true);
    setSta('Placing curved row(s)…', '#4f8ef7');
    try {
      const r = await run("placeCurvedRow('" + params + "')");
      setSta(r, cfor(r));
      schedBadge();
    } catch (e) {
      setSta(String(e), '#e85252');
    } finally {
      setAllDis(false);
      showProg(false);
    }
  };
  const btnTL = $('btnTableLayout');
  if (btnTL) btnTL.onclick = async () => {
    const tblMode = typeof window.__getTableMode === 'function' ? window.__getTableMode() : 'seats';
    const params = JSON.stringify({
      numTables: $('tbCount') ? $('tbCount').value : '8',
      seatsPerTable: $('tbSeats') ? $('tbSeats').value : '8',
      tableShape: $('tbShape') ? $('tbShape').value : 'circle',
      seatStyle: $('tbSeatStyle') ? $('tbSeatStyle').value : 'standard',
      tableDiam: $('tbDiam') ? $('tbDiam').value : '60',
      tableSpacing: $('tbSpace') ? $('tbSpace').value : '120',
      gridCols: $('tbCols') ? $('tbCols').value : '4',
      startNum: $('tbStart') ? $('tbStart').value : '1',
      naming: $('tbNaming') ? $('tbNaming').value : 'number',
      startX: $('tbX') ? $('tbX').value : '200',
      startY: $('tbY') ? $('tbY').value : '200',
      tableBookable: tblMode === 'table'
    }).replace(/'/g, "\\'");
    setAllDis(true);
    showProg(true);
    setSta('Creating table layout (' + tblMode + ' mode)…', '#4f8ef7');
    try {
      const r = await run("createTableLayout('" + params + "')");
      setSta(r, cfor(r));
      schedBadge();
    } catch (e) {
      setSta(String(e), '#e85252');
    } finally {
      setAllDis(false);
      showProg(false);
    }
  };
  
  

  /* ═════════════════════════════════════════════════════════
     CREATE tab v4.0 — NEW button handlers (7 new sub-modes)
     ═════════════════════════════════════════════════════════ */

  /* ── Straight Row Placer ───────────────────────────── */
  // btnSR already used above (Seat Resizer); rename to avoid strict-mode crash.
  const btnStrR = $('btnStraightRow');
  if (btnStrR) btnStrR.onclick = async () => {
    const zone = ($('srZone') ? $('srZone').value : '').toUpperCase().replace(/[^A-Z0-9]/g, '');
    if (!zone) {
      setSta('Enter a zone prefix for the straight row.', '#f0923a');
      return;
    }
    const params = JSON.stringify({
      zone: zone,
      firstRow: $('srRow') ? $('srRow').value : 'A',
      numRows: $('srRows') ? $('srRows').value : '5',
      seatsPerRow: $('srSeats') ? $('srSeats').value : '20',
      startX: $('srX') ? $('srX').value : '100',
      startY: $('srY') ? $('srY').value : '200',
      step: $('srStep') ? $('srStep').value : '9',
      rowStep: $('srRStep') ? $('srRStep').value : '9',
      aisleAfter: $('srAisles') ? $('srAisles').value : '',
      aisleWidth: $('srAisleW') ? $('srAisleW').value : '27'
    }).replace(/'/g, "\\'");
    setAllDis(true);
    showProg(true);
    setSta('Placing straight row(s)…', '#4f8ef7');
    try {
      const r = await run("placeStraightRow('" + params + "')");
      setSta(r, cfor(r));
      schedBadge();
    } catch (e) {
      setSta(String(e), '#e85252');
    } finally {
      setAllDis(false);
      showProg(false);
    }
  };

  /* ── Auto Section Shapes ───────────────────────────── */
  wire('btnAutoSec', 'Auto-generating section shapes…', 'autoGenerateSectionShapes()');

  /* ── Manual Section Shape ──────────────────────────── */
  const btnMS = $('btnManualSec');
  if (btnMS) btnMS.onclick = async () => {
    const params = JSON.stringify({
      zone: ($('secZone') ? $('secZone').value : '').toUpperCase().replace(/[^A-Z0-9]/g, ''),
      num: $('secNum') ? $('secNum').value : '1',
      x: $('secX') ? $('secX').value : '100',
      y: $('secY') ? $('secY').value : '100',
      w: $('secW') ? $('secW').value : '200',
      h: $('secH') ? $('secH').value : '100',
      pad: $('secPad') ? $('secPad').value : '6',
      rx: $('secRx') ? $('secRx').value : '0'
    }).replace(/'/g, "\\'");
    setAllDis(true);
    showProg(true);
    setSta('Creating manual section shape…', '#4f8ef7');
    try {
      const r = await run("createManualSection('" + params + "')");
      setSta(r, cfor(r));
    } catch (e) {
      setSta(String(e), '#e85252');
    } finally {
      setAllDis(false);
      showProg(false);
    }
  };

  /* ── Add Section Label ─────────────────────────────── */
  const btnAL = $('btnAddLabel');
  if (btnAL) btnAL.onclick = async () => {
    const params = JSON.stringify({
      zone: ($('decZone') ? $('decZone').value : '').toUpperCase().replace(/[^A-Z0-9]/g, ''),
      label: $('decLabel') ? $('decLabel').value : '',
      fontSize: $('decFont') ? $('decFont').value : '30',
      position: $('decPos') ? $('decPos').value : 'below'
    }).replace(/'/g, "\\'");
    setAllDis(true);
    showProg(true);
    setSta('Adding section label…', '#4f8ef7');
    try {
      const r = await run("addSectionLabel('" + params + "')");
      setSta(r, cfor(r));
    } catch (e) {
      setSta(String(e), '#e85252');
    } finally {
      setAllDis(false);
      showProg(false);
    }
  };

  /* ── Add Decoration Element ────────────────────────── */
  /* (handler body was truncated in source; stub left for future work)  */
  const btnAD = $('btnAddDecor');
  if (btnAD) btnAD.onclick = function () {
    setSta('Add Decoration: handler not yet implemented in this build.', '#f0923a');
  };

  /* ----------------------------------------------------------
     LEVEL 2+ UTILITIES — in-panel modals (no external JSX files)
     Backed by window.YWUtils (utils-ui.js) and helpers.js
     (YWToast / YWRunOp / YWShortcuts).
     ---------------------------------------------------------- */
  function wireUtilButton(btnId, getUtilFn) {
    const btn = $(btnId);
    if (!btn) return;
    btn.onclick = () => {
      if (!window.YWUtils) {
        setSta('YWUtils not loaded — check utils-ui.js', '#e85252');
        return;
      }
      const fn = getUtilFn();
      if (typeof fn === 'function') fn();else setSta('Utility not available', '#e85252');
    };
  }

  // Wire both copies (MORE tab + VALIDATE+EXPORT tab)
  wireUtilButton('btnUtilLayerToggle', () => window.YWUtils.openLayerToggle);
  wireUtilButton('btnUtilLayerToggle2', () => window.YWUtils.openLayerToggle);
  wireUtilButton('btnUtilResizeSeats', () => window.YWUtils.openResizeSeats);
  wireUtilButton('btnUtilResizeSeats2', () => window.YWUtils.openResizeSeats);
  wireUtilButton('btnUtilConvertShape', () => window.YWUtils.openConvertToSeat);
  wireUtilButton('btnUtilConvertShape2', () => window.YWUtils.openConvertToSeat);
  wireUtilButton('btnUtilSeatsToZone', () => window.YWUtils.openSeatsToZone);
  wireUtilButton('btnUtilSeatsToZone2', () => window.YWUtils.openSeatsToZone);
  wireUtilButton('btnUtilHierarchyVal', () => window.YWUtils.openHierarchyValidator);

  // Keyboard shortcuts (helpers.js -> YWShortcuts)
  if (window.YWShortcuts) {
    const S = window.YWShortcuts;
    S.register('ctrl+l', function () {
      if (window.YWUtils) window.YWUtils.openLayerToggle();
    }, 'Layer Toggle');
    S.register('ctrl+shift+r', function () {
      if (window.YWUtils) window.YWUtils.openResizeSeats();
    }, 'Resize Seats');
    S.register('ctrl+shift+c', function () {
      if (window.YWUtils) window.YWUtils.openConvertToSeat();
    }, 'Convert -> Seat');
    S.register('ctrl+shift+z', function () {
      if (window.YWUtils) window.YWUtils.openSeatsToZone();
    }, 'Seats -> Zone');
    S.register('ctrl+shift+h', function () {
      if (window.YWUtils) window.YWUtils.openHierarchyValidator();
    }, 'Hierarchy Validator');
  }
} /* end wireAll() */