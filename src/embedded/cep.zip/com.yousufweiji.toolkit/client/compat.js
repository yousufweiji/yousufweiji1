// Offline runtime fallbacks for CEP 9 / Chromium 61. JSX uses ES3 independently.
(function () {
  if (!Blob.prototype.arrayBuffer) Blob.prototype.arrayBuffer = function () { var blob=this; return new Promise(function(resolve,reject){var r=new FileReader();r.onload=function(){resolve(r.result);};r.onerror=reject;r.readAsArrayBuffer(blob);}); };
  if (!Element.prototype.replaceChildren) Element.prototype.replaceChildren = function () { var args=arguments; while(this.firstChild)this.removeChild(this.firstChild);for(var i=0;i<args.length;i++)this.appendChild(typeof args[i]==='string'?document.createTextNode(args[i]):args[i]); };
  if (typeof globalThis === 'undefined') window.globalThis = window;
  if (!Array.prototype.at) Object.defineProperty(Array.prototype, 'at', {
    value: function (i) {
      i = Math.trunc(Number(i) || 0);
      return this[i < 0 ? this.length + i : i];
    }
  });
  if (!Array.prototype.flat) Object.defineProperty(Array.prototype, 'flat', {
    value: function (depth) {
      depth = depth === undefined ? 1 : Number(depth);
      var out = [];
      this.forEach(function (x) {
        if (Array.isArray(x) && depth > 0) out.push.apply(out, x.flat(depth - 1));else out.push(x);
      });
      return out;
    }
  });
  if (!Array.prototype.flatMap) Object.defineProperty(Array.prototype, 'flatMap', {
    value: function (fn, that) {
      return this.map(fn, that).flat();
    }
  });
  if (!String.prototype.replaceAll) Object.defineProperty(String.prototype, 'replaceAll', {
    value: function (a, b) {
      if (a instanceof RegExp) {
        if (!a.global) throw new TypeError('replaceAll requires global RegExp');
        return this.replace(a, b);
      }
      return this.replace(new RegExp(String(a).replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'g'), b);
    }
  });
  if (!Blob.prototype.text) Blob.prototype.text = function () {
    var blob = this;
    return new Promise(function (resolve, reject) {
      var r = new FileReader();
      r.onload = function () {
        resolve(r.result);
      };
      r.onerror = reject;
      r.readAsText(blob);
    });
  };
  if (!Promise.prototype.finally) Promise.prototype.finally = function (fn) {
    return this.then(function (v) {
      return Promise.resolve(fn()).then(function () {
        return v;
      });
    }, function (e) {
      return Promise.resolve(fn()).then(function () {
        throw e;
      });
    });
  };
  if (!Object.fromEntries) Object.fromEntries = function (entries) {
    var o = {};
    Array.from(entries).forEach(function (e) {
      Object.defineProperty(o, e[0], {
        value: e[1],
        writable: true,
        enumerable: true,
        configurable: true
      });
    });
    return o;
  };
})();
