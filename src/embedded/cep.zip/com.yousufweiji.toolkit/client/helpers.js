// client/helpers.js — Yousufweiji Hall Map Toolkit v6.5.1
// Global helpers: YWToast, YWRunOp, YWShortcuts, YWLog, YWState
'use strict';

/* ════════════════════════════════════════════════════════════════
   YWLog — toggleable diagnostic console
   ════════════════════════════════════════════════════════════════ */
window.YWLog = function () {
  let enabled = false;
  let history = [];
  function _fmt(level, args) {
    const msg = Array.prototype.slice.call(args).map(String).join(' ');
    const entry = {
      time: new Date().toISOString(),
      level,
      msg
    };
    history.push(entry);
    if (history.length > 200) history.shift();
    return entry;
  }
  return {
    enable() {
      enabled = true;
    },
    disable() {
      enabled = false;
    },
    get active() {
      return enabled;
    },
    get log() {
      return history;
    },
    clear() {
      history = [];
    },
    info(...a) {
      const e = _fmt('INFO', a);
      if (enabled) console.info('[YW]', e.msg);
    },
    warn(...a) {
      const e = _fmt('WARN', a);
      if (enabled) console.warn('[YW]', e.msg);
    },
    error(...a) {
      const e = _fmt('ERROR', a);
      if (enabled) console.error('[YW]', e.msg);
    },
    dump() {
      return history.map(e => `[${e.level}] ${e.time.slice(11, 23)}  ${e.msg}`).join('\n');
    }
  };
}();

/* ════════════════════════════════════════════════════════════════
   YWState — persistent key-value (localStorage with in-memory fallback)
   ════════════════════════════════════════════════════════════════ */
window.YWState = function () {
  const PFX = 'ywt3_';
  let mem = {};
  let hasLS = false;
  try {
    localStorage.setItem('__ywt_test', '1');
    localStorage.removeItem('__ywt_test');
    hasLS = true;
  } catch (_) {}
  return {
    get(k, def) {
      try {
        const r = hasLS ? localStorage.getItem(PFX + k) : mem[PFX + k];
        return r !== null && r !== undefined ? JSON.parse(r) : def;
      } catch (_) {
        return def;
      }
    },
    set(k, v) {
      try {
        const s = JSON.stringify(v);
        if (hasLS) localStorage.setItem(PFX + k, s);else mem[PFX + k] = s;
      } catch (_) {}
    },
    remove(k) {
      if (hasLS) localStorage.removeItem(PFX + k);else delete mem[PFX + k];
    },
    clear() {
      if (hasLS) Object.keys(localStorage).filter(k => k.startsWith(PFX)).forEach(k => localStorage.removeItem(k));else mem = {};
    }
  };
}();

/* ════════════════════════════════════════════════════════════════
   YWToast — lightweight toast notifications
   ════════════════════════════════════════════════════════════════ */
window.YWToast = function () {
  let host = null;
  function _ensureHost() {
    if (host && document.body.contains(host)) return host;
    host = document.createElement('div');
    host.id = 'yw-toast-host';
    host.style.cssText = 'position:fixed;right:10px;bottom:40px;z-index:20000;display:flex;flex-direction:column-reverse;gap:5px;pointer-events:none;max-width:310px;font-family:Arial,sans-serif';
    document.body.appendChild(host);
    return host;
  }
  function _push(kind, msg, duration) {
    if (window.YWLog) YWLog.info('Toast(' + kind + '):', String(msg).slice(0, 80));
    const h = _ensureHost();
    const P = {
      info: {
        bg: '#1e2d4a',
        bd: '#4f8ef7',
        fg: '#c8d8ff'
      },
      success: {
        bg: '#172a21',
        bd: '#3ecf6e',
        fg: '#c0f0d0'
      },
      error: {
        bg: '#3a1a1a',
        bd: '#e85252',
        fg: '#ffd0d0'
      },
      warn: {
        bg: '#3a2a10',
        bd: '#f0923a',
        fg: '#ffe0b0'
      }
    };
    const p = P[kind] || P.info;
    const ttl = duration || (kind === 'error' ? 7000 : 3500);
    const t = document.createElement('div');
    t.style.cssText = `background:${p.bg};border-left:3px solid ${p.bd};color:${p.fg};padding:7px 10px;border-radius:4px;font-size:11px;line-height:1.4;box-shadow:0 4px 14px rgba(0,0,0,.55);pointer-events:auto;cursor:pointer;opacity:0;transform:translateY(6px);transition:all .16s ease`;
    t.textContent = String(msg || '');
    h.appendChild(t);
    requestAnimationFrame(() => {
      t.style.opacity = '1';
      t.style.transform = 'translateY(0)';
    });
    const dismiss = () => {
      t.style.opacity = '0';
      t.style.transform = 'translateY(6px)';
      setTimeout(() => t.parentNode && t.remove(), 200);
    };
    t.onclick = dismiss;
    setTimeout(dismiss, ttl);
  }
  return {
    info: (m, d) => _push('info', m, d),
    success: (m, d) => _push('success', m, d),
    error: (m, d) => _push('error', m, d),
    warn: (m, d) => _push('warn', m, d)
  };
}();

/* ════════════════════════════════════════════════════════════════
   YWRunOp — Promise wrapper for JSX calls from UI components
   ════════════════════════════════════════════════════════════════ */
window.YWRunOp = function (jsxCode, opTag) {
  if (window.YWLog) YWLog.info('YWRunOp:', opTag || '', '→', jsxCode.slice(0, 60));
  if (window.YWBridge && typeof window.YWBridge.run === 'function') {
    return window.YWBridge.run(jsxCode);
  }
  if (typeof window.run === 'function') return window.run(jsxCode);
  return new Promise(function (resolve, reject) {
    try {
      const cs = window._csi;
      if (!cs) return reject(new Error('CSInterface not initialised'));
      let settled = false;
      const timer = setTimeout(() => {
        if (!settled) {
          settled = true;
          reject(new Error('Timeout: ' + (opTag || '?')));
        }
      }, 180000);
      cs.evalScript(jsxCode, result => {
        clearTimeout(timer);
        if (settled) return;
        settled = true;
        if (!result) return reject(new Error('No response'));
        if (/^CRITICAL ERROR|^ERROR:/.test(result)) return reject(new Error(result));
        resolve(result === '' ? 'Done.' : result);
      });
    } catch (e) {
      reject(e);
    }
  });
};

/* ════════════════════════════════════════════════════════════════
   YWShortcuts — keyboard shortcut registry
   ════════════════════════════════════════════════════════════════ */
window.YWShortcuts = function () {
  const map = new Map();
  function _combo(e) {
    const parts = [];
    if (e.ctrlKey || e.metaKey) parts.push('ctrl');
    if (e.shiftKey) parts.push('shift');
    if (e.altKey) parts.push('alt');
    const k = (e.key || '').toLowerCase();
    if (['control', 'shift', 'alt', 'meta'].includes(k)) return null;
    parts.push(k);
    return parts.join('+');
  }
  function register(combo, handler, label) {
    const key = String(combo).toLowerCase().replace(/\s+/g, '');
    map.set(key, {
      handler,
      label: label || combo
    });
  }
  function unregister(combo) {
    map.delete(String(combo).toLowerCase().replace(/\s+/g, ''));
  }
  function list() {
    const o = [];
    map.forEach((v, k) => o.push({
      combo: k,
      label: v.label
    }));
    return o;
  }
  document.addEventListener('keydown', e => {
    const combo = _combo(e);
    if (!combo) return;
    const entry = map.get(combo);
    if (!entry) return;
    e.preventDefault();
    e.stopPropagation();
    try {
      entry.handler(e);
    } catch (err) {
      if (window.YWToast) YWToast.error('Shortcut error: ' + err);
    }
  }, true);
  return {
    register,
    unregister,
    list
  };
}();
