// CEP builder controls, v6.5.1. Preview and host use the same ES3 geometry planner.
window.YWBuilders=(function(){
    function el(id){return document.getElementById(id);}
    function value(id){return el(id).value;}
    function esc(s){return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/"/g,'&quot;');}
    function points(a){return a.map(function(q){return q[0].toFixed(2)+','+q[1].toFixed(2);}).join(' ');}
    function mapParams(){return {type:mapType,zones:value('pbZ'),seatsPerZone:value('pbS'),rowsPerZone:value('pbR'),prefixes:getChipValues(),stageType:value('pbStageShape'),stageWidth:value('pbStageW'),stageHeight:value('pbStageH'),overlayFill:value('pbOverlayFill'),labelSize:value('pbLabelSize'),labelGap:10};}
    function previewMap(){
        try{
            var plan=YWGeometry.map(mapParams()),svg=el('pvg'),out='<polygon points="'+points(plan.stage.points)+'" fill="#e0e0e0" stroke="#8f949c"/>',colors=['#4f8ef7','#3ecf6e','#9b72f0','#f0923a'];
            for(var z=0;z<plan.zones.length;z++){
                var zone=plan.zones[z];out+='<polygon points="'+points(zone.section)+'" fill="#f1f1f1" stroke="#d1d2d4"/>';
                if(plan.overlayFill!=='white')for(var i=0;i<zone.seats.length;i++){var s=zone.seats[i];out+='<rect x="'+s.x+'" y="'+s.y+'" width="7" height="7" rx="1.5" fill="'+colors[z%4]+'"/>';}
                if(plan.overlayFill==='white')out+='<polygon points="'+points(zone.section)+'" fill="white" stroke="#d1d2d4"/>';
                out+='<text x="'+zone.label.x+'" y="'+zone.label.y+'" text-anchor="middle" fill="#6d6e70" font-family="Arial" font-size="'+zone.label.size+'">'+esc(zone.name)+'</text>';
            }
            var label=plan.stage.label;out+='<text x="'+label.x+'" y="'+(label.y+7)+'" text-anchor="middle" fill="#666" font-family="Arial" font-size="24">STAGE</text>';
            svg.setAttribute('viewBox','0 0 '+plan.width+' '+plan.height);svg.innerHTML=out;
            el('pbTotal').textContent=plan.totalSeats;el('pbBreakdown').textContent=plan.zones.length+' zones · '+plan.width+' × '+plan.height+' px';
            el('pbBuilderInfo').textContent='New document · matching section paths · zone names above sections';el('btnPreBuild').disabled=false;
        }catch(e){el('pbBuilderInfo').textContent=e.message;el('btnPreBuild').disabled=true;}
    }
    function stageParams(prefix){return {shape:value(prefix+'Shape'),width:value(prefix+'W'),height:value(prefix+'H'),x:value(prefix+'X'),y:value(prefix+'Y'),label:value(prefix+'Label'),fontSize:value(prefix+'Font'),cornerRadius:value(prefix+'Radius'),rotation:value(prefix+'Rotation'),createLayers:el(prefix+'CreateLayers').checked,replaceExisting:el(prefix+'Replace').checked};}
    function previewStage(prefix){
        try{var p=stageParams(prefix),pts=YWGeometry.transform(YWGeometry.stage(p.shape,p.width,p.height,p.cornerRadius),0,0,Number(p.rotation)),b=YWGeometry.bounds(pts),margin=15;
            var svg=el(prefix+'Preview');svg.setAttribute('viewBox',[b[0]-margin,b[1]-margin,b[2]-b[0]+margin*2,b[3]-b[1]+margin*2].join(' '));
            svg.innerHTML='<polygon points="'+points(pts)+'" fill="#e0e0e0" stroke="#999" stroke-width="1"/><text x="'+(b[0]+b[2])/2+'" y="'+((b[1]+b[3])/2+Number(p.fontSize)*.3)+'" text-anchor="middle" font-family="Arial" font-size="'+Number(p.fontSize)+'" fill="#6d6e70">'+esc(p.label)+'</text>';
        }catch(e){el(prefix+'Preview').innerHTML='';}
    }
    function execute(name,p){
        setAllDis(true);showProg(true);setSta('Building in Illustrator…','#4f8ef7');
        // Serialize twice so quotes, backslashes and newlines survive the CEP/JSX boundary.
        return YWBridge.run(name+'('+JSON.stringify(JSON.stringify(p))+')').then(function(r){setSta(r,cfor(r));schedBadge();},function(e){setSta(e.message||String(e),'#e85252');}).finally(function(){setAllDis(false);showProg(false);});
    }
    function buildMap(){try{var p=mapParams();YWGeometry.map(p);return execute('preBuildMap',p);}catch(e){setSta(e.message,'#e85252');}}
    function buildStage(prefix){try{var p=stageParams(prefix);YWGeometry.stage(p.shape,p.width,p.height,p.cornerRadius);YWGeometry.number(p.x,0,-15000,15000,'Stage X');YWGeometry.number(p.y,0,-15000,15000,'Stage Y');if(p.replaceExisting&&!confirm('Build this stage and replace any existing STAGE artwork? Other decoration is kept.'))return;return execute('buildStagePlus',p);}catch(e){setSta(e.message,'#e85252');}}
    function init(){
        ['bs','st'].forEach(function(prefix){[prefix+'Shape',prefix+'W',prefix+'H',prefix+'X',prefix+'Y',prefix+'Label',prefix+'Font',prefix+'Radius',prefix+'Rotation'].forEach(function(id){el(id).addEventListener('input',function(){previewStage(prefix);});});previewStage(prefix);});
        el('btnBuildStagePlus').onclick=function(){buildStage('bs');};el('btnBuildStage').onclick=function(){buildStage('st');};el('btnPreBuild').onclick=buildMap;
        ['pbStageShape','pbStageW','pbStageH','pbOverlayFill','pbLabelSize'].forEach(function(id){el(id).addEventListener('input',previewMap);});previewMap();
    }
    window.addEventListener('load',init);
    return {previewMap:previewMap,previewStage:previewStage,buildMap:buildMap};
})();
