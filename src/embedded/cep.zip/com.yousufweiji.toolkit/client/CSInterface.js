/**
 * CSInterface.js — CEP Bridge Shim  v3.0
 * Wraps window.__adobe_cep__ (auto-injected by the CEP runtime).
 * AI 2020 (CEF ~75) compatible — no throwing constructor, lazy __adobe_cep__ checks.
 */
var SystemPath = {
  USER_DATA: 'userData',
  COMMON_FILES: 'commonFiles',
  MY_DOCUMENTS: 'myDocuments',
  APPLICATION: 'application',
  EXTENSION: 'extension',
  HOST_APPLICATION: 'hostApplication'
};
function CSEvent(type, scope, appId, extensionId) {
  this.type = type || '';
  this.scope = scope || 'APPLICATION';
  this.appId = appId || '';
  this.extensionId = extensionId || '';
  this.data = '';
}
function CSInterface() {
  // AI 2020: __adobe_cep__ injected async — do NOT throw in constructor.
  if (typeof window.__adobe_cep__ === 'undefined') {
    console.warn('CSInterface: window.__adobe_cep__ not ready yet (AI 2020 normal).');
  }
}
CSInterface.prototype.evalScript = function (script, callback) {
  if (typeof callback !== 'function') callback = function () {};
  if (typeof window.__adobe_cep__ === 'undefined') {
    // May become available after page fully loads — defer once
    var self = this,
      args = arguments;
    if (!this._evalRetried) {
      this._evalRetried = true;
      setTimeout(function () {
        self.evalScript.apply(self, args);
      }, 500);
    } else {
      this._evalRetried = false;
      callback('EvalScript error: __adobe_cep__ not available');
    }
    return;
  }
  try {
    window.__adobe_cep__.evalScript(script, callback);
  } catch (e) {
    callback('EvalScript error: ' + e.message);
  }
};
CSInterface.prototype.getSystemPath = function (pathType) {
  try {
    return (window.__adobe_cep__ || {}).getSystemPath ? window.__adobe_cep__.getSystemPath(pathType) : '';
  } catch (e) {
    return '';
  }
};
CSInterface.prototype.getExtensionID = function () {
  try {
    return window.__adobe_cep__ ? window.__adobe_cep__.getExtensionId() : '';
  } catch (e) {
    return '';
  }
};
CSInterface.prototype.getHostEnvironment = function () {
  try {
    if (!window.__adobe_cep__) return {};
    var e = window.__adobe_cep__.getHostEnvironment();
    return typeof e === 'string' ? JSON.parse(e) : e || {};
  } catch (e) {
    return {};
  }
};
CSInterface.prototype.addEventListener = function (t, l) {
  try {
    if (window.__adobe_cep__) window.__adobe_cep__.addEventListener(t, l);
  } catch (e) {}
};
CSInterface.prototype.removeEventListener = function (t, l) {
  try {
    if (window.__adobe_cep__) window.__adobe_cep__.removeEventListener(t, l);
  } catch (e) {}
};
CSInterface.prototype.dispatchEvent = function (ev) {
  try {
    if (!window.__adobe_cep__) return;
    if (typeof ev.data === 'object') ev.data = JSON.stringify(ev.data);
    window.__adobe_cep__.dispatchEvent(ev);
  } catch (e) {}
};
CSInterface.prototype.closeExtension = function () {
  try {
    if (window.__adobe_cep__) window.__adobe_cep__.closeExtension();
  } catch (e) {}
};