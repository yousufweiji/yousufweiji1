#!/bin/bash
# Yousufweiji Hall Map Toolkit 6.4.0 — user-level macOS installation.
set -euo pipefail
source_dir="$(cd "$(dirname "$0")/.." && pwd)"
cep_root="$HOME/Library/Application Support/Adobe/CEP/extensions"
destination="$cep_root/com.yousufweiji.toolkit"
if pgrep -x 'Adobe Illustrator' >/dev/null; then
  echo 'Close Illustrator before installing.'; exit 1
fi
for f in CSXS/manifest.xml client/index.html client/bridge.js jsx/sopFunctions.jsx; do
  test -f "$source_dir/$f" || { echo "Missing package file: $f"; exit 1; }
done
test "$source_dir" != "$destination" || { echo 'Run this from the extracted ZIP.'; exit 1; }
mkdir -p "$cep_root"
if test -e "$destination"; then
  backup_root="$HOME/Library/Application Support/Adobe/CEP/toolkit-backups"
  mkdir -p "$backup_root"
  backup="$backup_root/com.yousufweiji.toolkit-$(date +%Y%m%d-%H%M%S)-$$"
  mv "$destination" "$backup"
  echo "Previous installation backed up to $backup"
fi
cp -R "$source_dir" "$destination"
for runtime in 9 10 11 12; do defaults write "com.adobe.CSXS.$runtime" PlayerDebugMode -string 1; done
echo "Installed 6.4.0 to $destination"
echo 'Open Illustrator > Window > Extensions (Legacy) > Yousufweiji Hall Map Toolkit.'
