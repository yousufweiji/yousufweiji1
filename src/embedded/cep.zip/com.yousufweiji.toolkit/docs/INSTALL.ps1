#Requires -Version 3.0
# Yousufweiji Hall Map Toolkit 6.4.0 — user-level installation.
$ErrorActionPreference = 'Stop'
$bundle = 'com.yousufweiji.toolkit'
$source = [IO.Path]::GetFullPath((Split-Path -Parent $PSScriptRoot))
$cepRoot = [IO.Path]::GetFullPath((Join-Path $env:APPDATA 'Adobe\CEP\extensions'))
$destination = [IO.Path]::GetFullPath((Join-Path $cepRoot $bundle))
if (Get-Process -Name Illustrator -ErrorAction SilentlyContinue) { throw 'Close Illustrator before installing.' }
foreach ($relative in @('CSXS\manifest.xml','client\index.html','client\bridge.js','jsx\sopFunctions.jsx')) {
    if (-not (Test-Path -LiteralPath (Join-Path $source $relative))) { throw "Missing package file: $relative" }
}
if ($source -eq $destination) { throw 'Run the installer from the extracted ZIP, outside the installed extension folder.' }
if ((Split-Path -Parent $destination) -ne $cepRoot) { throw 'Unexpected installation path.' }
New-Item -ItemType Directory -Path $cepRoot -Force | Out-Null
if (Test-Path -LiteralPath $destination) {
    $backupRoot = [IO.Path]::GetFullPath((Join-Path $env:APPDATA 'Adobe\CEP\toolkit-backups'))
    New-Item -ItemType Directory -Path $backupRoot -Force | Out-Null
    $backup = [IO.Path]::GetFullPath((Join-Path $backupRoot ($bundle + '-' + (Get-Date -Format 'yyyyMMdd-HHmmss-fff'))))
    if ((Split-Path -Parent $backup) -ne $backupRoot) { throw 'Unexpected backup path.' }
    Move-Item -LiteralPath $destination -Destination $backup
    Write-Host "Previous installation backed up to $backup"
}
Copy-Item -LiteralPath $source -Destination $destination -Recurse
foreach ($runtime in @('9','10','11','12')) {
    $regKey = 'HKCU:\Software\Adobe\CSXS.' + $runtime
    New-Item -Path $regKey -Force | Out-Null
    New-ItemProperty -Path $regKey -Name PlayerDebugMode -Value '1' -PropertyType String -Force | Out-Null
}
Write-Host "Installed 6.4.0 to $destination"
Write-Host 'Open Illustrator > Window > Extensions (Legacy) > Yousufweiji Hall Map Toolkit.'
Write-Host 'Use File > Scripts > Other Script for jsx\standalone\00_MASTER_PANEL.jsx.'
