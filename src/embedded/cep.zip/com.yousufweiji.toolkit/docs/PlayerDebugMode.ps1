# PlayerDebugMode.ps1
# Enables CEP debug mode for unsigned extensions in Adobe Illustrator.
# Run as Administrator, then restart Illustrator.
#
# Yousufweiji Toolkit v1.0
# Bundle: com.yousufweiji.toolkit

$regPath = "HKCU:\Software\Adobe\CSXS.9"

if (-not (Test-Path $regPath)) {
    New-Item -Path $regPath -Force | Out-Null
}

Set-ItemProperty -Path $regPath -Name "PlayerDebugMode" -Value "1" -Type String

# Also set for CSXS.10, CSXS.11, CSXS.12 (future-proofing)
foreach ($ver in @("10", "11", "12")) {
    $p = "HKCU:\Software\Adobe\CSXS.$ver"
    if (-not (Test-Path $p)) { New-Item -Path $p -Force | Out-Null }
    Set-ItemProperty -Path $p -Name "PlayerDebugMode" -Value "1" -Type String
}

Write-Host ""
Write-Host "=== CEP Debug Mode ENABLED ===" -ForegroundColor Green
Write-Host "Registry keys set for CSXS.9 through CSXS.12"
Write-Host ""
Write-Host "Next steps:"
Write-Host "  1. Close Illustrator completely"
Write-Host "  2. Copy the panel folder to:"
Write-Host "     Windows: %APPDATA%\Adobe\CEP\extensions\"
Write-Host "     macOS:   ~/Library/Application Support/Adobe/CEP/extensions/"
Write-Host "  3. Restart Illustrator"
Write-Host "  4. Window > Extensions > Yousufweiji Toolkit"
Write-Host ""
