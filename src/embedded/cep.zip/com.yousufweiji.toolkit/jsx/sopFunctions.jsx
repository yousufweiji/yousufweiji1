// Shared by the CEP preview and Illustrator ES3 builders. No browser or host APIs.
var YWGeometry = (function () {
    var shapes = ['rect','rounded','ellipse','circle','semicircle','arch','trapezoid','thrust','tstage','ustage','runway','hexagon'];
    var layouts = ['normal','fan','amphitheatre','oval','arena','thrust','club','tiered'];
    function has(a,v){for(var i=0;i<a.length;i++)if(a[i]===v)return true;return false;}
    function number(v,def,min,max,label){var n=(v===undefined||v===null||v==='')?def:Number(v);if(!isFinite(n)||n<min||n>max)throw new Error(label+' must be between '+min+' and '+max+'.');return n;}
    function integer(v,def,min,max,label){var n=number(v,def,min,max,label);if(n!==Math.floor(n))throw new Error(label+' must be a whole number.');return n;}
    function bounds(pts){var b=[Infinity,Infinity,-Infinity,-Infinity];for(var i=0;i<pts.length;i++){var q=pts[i];b[0]=Math.min(b[0],q[0]);b[1]=Math.min(b[1],q[1]);b[2]=Math.max(b[2],q[0]);b[3]=Math.max(b[3],q[1]);}return b;}
    function rect(x,y,w,h){return [[x,y],[x+w,y],[x+w,y+h],[x,y+h]];}
    function stage(type,w,h,r){
        if(type==='rounded10'){type='rounded';r=10;}if(type==='rounded20'){type='rounded';r=20;}
        if(type==='ellipse3d')type='ellipse';if(type==='platform')type='thrust';if(type==='simple')type='rect';
        if(!has(shapes,type))throw new Error('Unknown stage shape: '+type);
        w=number(w,400,20,10000,'Stage width');h=number(h,80,10,10000,'Stage height');
        r=Math.min(number(r,12,0,5000,'Corner radius'),w/2,h/2);
        var pts=[],i,t,cx=w/2,cy=h/2,rx=w/2,ry=h/2;
        if(type==='circle'){rx=ry=Math.min(w,h)/2;}
        if(type==='rect')pts=rect(0,0,w,h);
        else if(type==='rounded'){
            var corners=[[w-r,r,-90],[w-r,h-r,0],[r,h-r,90],[r,r,180]];
            for(var c=0;c<4;c++)for(i=0;i<=8;i++){t=(corners[c][2]+i*90/8)*Math.PI/180;pts.push([corners[c][0]+r*Math.cos(t),corners[c][1]+r*Math.sin(t)]);}
        }else if(type==='ellipse'||type==='circle')for(i=0;i<64;i++){t=2*Math.PI*i/64;pts.push([cx+rx*Math.cos(t),cy+ry*Math.sin(t)]);}
        else if(type==='semicircle'||type==='arch'){
            var base=type==='arch'?h*0.65:h;
            for(i=0;i<=48;i++){t=Math.PI+i*Math.PI/48;pts.push([cx+rx*Math.cos(t),base+base*Math.sin(t)]);}
            if(type==='arch'){pts.push([w,h]);pts.push([0,h]);}
        }else if(type==='trapezoid')pts=[[w*.15,0],[w*.85,0],[w,h],[0,h]];
        else if(type==='thrust')pts=[[w*.12,0],[w*.88,0],[w*.88,h*.25],[w,h*.25],[w,h*.75],[w*.88,h*.75],[w*.88,h],[w*.12,h],[w*.12,h*.75],[0,h*.75],[0,h*.25],[w*.12,h*.25]];
        else if(type==='tstage')pts=[[0,0],[w,0],[w,h*.35],[w*.65,h*.35],[w*.65,h],[w*.35,h],[w*.35,h*.35],[0,h*.35]];
        else if(type==='ustage')pts=[[0,0],[w*.25,0],[w*.25,h*.65],[w*.75,h*.65],[w*.75,0],[w,0],[w,h],[0,h]];
        else if(type==='runway')pts=[[0,0],[w,0],[w,h*.35],[w*.57,h*.35],[w*.57,h],[w*.43,h],[w*.43,h*.35],[0,h*.35]];
        else if(type==='hexagon')pts=[[w*.2,0],[w*.8,0],[w,h*.5],[w*.8,h],[w*.2,h],[0,h*.5]];
        return pts;
    }
    function transform(pts,x,y,rotation){var b=bounds(pts),cx=(b[0]+b[2])/2,cy=(b[1]+b[3])/2,a=rotation*Math.PI/180,out=[];for(var i=0;i<pts.length;i++){var dx=pts[i][0]-cx,dy=pts[i][1]-cy;out.push([cx+dx*Math.cos(a)-dy*Math.sin(a)+x,cy+dx*Math.sin(a)+dy*Math.cos(a)+y]);}return out;}
    function hull(points){
        points.sort(function(a,b){return a[0]-b[0]||a[1]-b[1];});
        function cross(o,a,b){return (a[0]-o[0])*(b[1]-o[1])-(a[1]-o[1])*(b[0]-o[0]);}
        var lo=[],hi=[],i;for(i=0;i<points.length;i++){while(lo.length>=2&&cross(lo[lo.length-2],lo[lo.length-1],points[i])<=0)lo.pop();lo.push(points[i]);}
        for(i=points.length-1;i>=0;i--){while(hi.length>=2&&cross(hi[hi.length-2],hi[hi.length-1],points[i])<=0)hi.pop();hi.push(points[i]);}lo.pop();hi.pop();return lo.concat(hi);
    }
    function sectionFor(seats){var pts=[];for(var i=0;i<seats.length;i++){var s=seats[i];pts=pts.concat(rect(s.x-6,s.y-6,19,19));}return hull(pts);}
    function map(p){
        p=p||{};var type=String(p.type||'normal');if(!has(layouts,type))throw new Error('Unknown map layout: '+type);
        var nz=integer(p.zones,4,1,12,'Zones'),ns=integer(p.seatsPerZone,80,1,5000,'Seats per zone'),nr=integer(p.rowsPerZone,8,1,200,'Rows per zone');
        if(nr>ns)throw new Error('Rows cannot exceed the seat count.');if(nz*ns>20000)throw new Error('Limit each generated map to 20,000 seats.');
        var cols=Math.ceil(ns/nr),pitch=9,gap=70,pad=6,w=(cols-1)*pitch+7,h=(nr-1)*pitch+7,stageW=number(p.stageWidth,220,20,2000,'Stage width'),stageH=number(p.stageHeight,70,10,2000,'Stage height');
        var font=number(p.labelSize,24,8,120,'Zone label size'),labelGap=number(p.labelGap,10,0,100,'Label gap'),names=p.prefixes||[],seen={},zones=[],all=[],i,j,z;
        var gridCols=Math.min(4,nz),span=type==='fan'?110:160,slot=span/nz,inner=Math.max(stageW/2+80,(cols*13+30)/(slot*Math.PI/180)*1.3),outer=inner+(nr-1)*13;
        var ringSlot=360/nz,ringInner=Math.max(stageW/2+100,stageH/2+100,(cols*13+50)/(ringSlot*Math.PI/180)*1.3);
        var stageType=p.stageType||((type==='oval')?'ellipse':type==='thrust'?'tstage':'rect');
        var sp=stage(stageType,stageW,stageH,p.cornerRadius),stageX=-stageW/2,stageY=-stageH/2;
        for(z=0;z<nz;z++){
            var name=String(names[z]||String.fromCharCode(65+z)).replace(/^\s+|\s+$/g,'').toUpperCase();
            if(!/^[A-Z0-9]+$/.test(name))throw new Error('Zone names must use letters and numbers only: '+name);
            if(seen['$'+name])throw new Error('Duplicate zone name: '+name);seen['$'+name]=true;
            var seats=[],x0=0,y0=0,ang=0,radius=0,section=null,table=null;
            if(type==='normal'||type==='tiered'){
                var row=Math.floor(z/gridCols),col=z%gridCols;
                x0=(col-(gridCols-1)/2)*(w+gap)-w/2+(type==='tiered'?row*(w+gap)*.22:0);
                y0=stageH/2+80+row*(h+gap);
            }else if(type==='arena'||type==='thrust'){
                var sides=type==='arena'?4:3,side=z%sides,rank=Math.floor(z/sides),per=Math.ceil(nz/sides),step=Math.max(w,h)+gap;
                var dist=Math.max(stageW,stageH)/2+Math.max(w,h)/2+100+per*step/2;
                var off=(rank-(per-1)/2)*step;
                if(side===0){x0=-dist-w/2;y0=off-h/2;}
                else if(side===1){x0=off-w/2;y0=dist-h/2;}
                else if(side===2){x0=dist-w/2;y0=off-h/2;}
                else{x0=off-w/2;y0=-dist-h/2;}
            }else if(type==='club'){
                radius=Math.max(30,cols*13/(2*Math.PI));var rr=radius+(nr-1)*13;
                var clubCols=Math.ceil(Math.sqrt(nz)),clubStep=2*rr+gap;
                x0=(z%clubCols-(clubCols-1)/2)*clubStep;y0=stageH/2+100+rr+Math.floor(z/clubCols)*clubStep;
                table={x:x0,y:y0,r:Math.max(10,radius-15)};
            }
            for(i=0;i<ns;i++){
                var rowIndex=Math.floor(i/cols),c=i%cols,inRow=Math.min(cols,ns-rowIndex*cols),x,y;
                if(type==='amphitheatre'||type==='oval'){
                    var sl=type==='oval'?ringSlot:slot,mid=(type==='oval'?-90:90-span/2)+(z+.5)*sl;
                    var rad=(type==='oval'?ringInner:inner)+rowIndex*13;
                    ang=(mid+(c-(inRow-1)/2)*13/rad*180/Math.PI)*Math.PI/180;
                    x=rad*Math.cos(ang)-3.5;y=rad*Math.sin(ang)-3.5;
                }else if(type==='fan'){
                    ang=(90-span/2+(z+.5)*slot)*Math.PI/180;var depth=inner+rowIndex*13,tangent=(c-(inRow-1)/2)*13;
                    x=depth*Math.cos(ang)-tangent*Math.sin(ang)-3.5;y=depth*Math.sin(ang)+tangent*Math.cos(ang)-3.5;
                }else if(type==='club'){
                    ang=(c/inRow*360-90)*Math.PI/180;var cr=radius+rowIndex*13;
                    x=x0+cr*Math.cos(ang)-3.5;y=y0+cr*Math.sin(ang)-3.5;
                }else{x=x0+c*pitch+(type==='tiered'?rowIndex*3:0);y=y0+rowIndex*pitch;}
                seats.push({x:x,y:y,row:rowIndex,col:c,number:c+1});
            }
            if(type==='amphitheatre'||type==='oval'){
                var sl2=type==='oval'?ringSlot:slot,mid2=(type==='oval'?-90:90-span/2)+(z+.5)*sl2,ri=type==='oval'?ringInner:inner;
                var half=Math.min(sl2/2-0.2,(cols*13/2+14)/ri*180/Math.PI),outerR=ri+(nr-1)*13+10,innerR=ri-10;section=[];
                for(j=0;j<=40;j++){ang=(mid2-half+j*2*half/40)*Math.PI/180;section.push([innerR*Math.cos(ang),innerR*Math.sin(ang)]);}
                for(j=40;j>=0;j--){ang=(mid2-half+j*2*half/40)*Math.PI/180;section.push([outerR*Math.cos(ang),outerR*Math.sin(ang)]);}
            }else section=sectionFor(seats);
            var b=bounds(section),size=Math.min(font,Math.max(8,(b[2]-b[0]-8)/(name.length*.65)));
            var label={x:(b[0]+b[2])/2,y:b[1]-labelGap,size:size,text:name};
            zones.push({name:name,seats:seats,section:section,label:label,table:table});all=all.concat(section,[[label.x-name.length*size*.35,label.y-size],[label.x+name.length*size*.35,label.y]]);
        }
        sp=transform(sp,stageX,stageY,0);all=all.concat(sp);var b=bounds(all),dx=60-b[0],dy=60-b[1],width=Math.ceil(b[2]-b[0]+120),height=Math.ceil(b[3]-b[1]+120);
        if(width>15000||height>15000)throw new Error('Layout exceeds 15,000 px. Reduce rows or seats per zone.');
        function shift(pts){for(var k=0;k<pts.length;k++){pts[k][0]+=dx;pts[k][1]+=dy;}}
        shift(sp);for(z=0;z<zones.length;z++){var zone=zones[z];shift(zone.section);zone.label.x+=dx;zone.label.y+=dy;for(i=0;i<zone.seats.length;i++){zone.seats[i].x+=dx;zone.seats[i].y+=dy;}if(zone.table){zone.table.x+=dx;zone.table.y+=dy;}}
        return {type:type,width:width,height:height,zones:zones,totalSeats:nz*ns,stage:{points:sp,label:{x:stageX+stageW/2+dx,y:stageY+stageH/2+dy,text:'STAGE'}},overlayFill:p.overlayFill==='white'?'white':'outline'};
    }
    return {shapes:shapes,layouts:layouts,number:number,stage:stage,transform:transform,bounds:bounds,map:map};
})();

// jsx/sopFunctions.jsx
// Yousuf Weiji â€” Hall Map Toolkit  |  ExtendScript ES3
// Version: 6.5.1  |  Ultimate SOP Edition Â· April 2026
// Targets: Illustrator 2020 â€“ 2026+
//
// SOP sublayer names (NO numeric suffixes â€” never _1_, _2_, _n_):
//   SECTION, UNDERSEATDECORATION, SEAT, SEATDECORATION, SECTIONDECORATION
//
// PUBLIC FUNCTIONS
//  testCEP()
//  runFullChecklist()          31-item SOP Â§12
//  validateGeometry()
//  findDuplicates()
//  generateSeatIDs(prefix)
//  fixSectionFills()
//  fixSeatStrokes()
//  fixLabelColors()
//  fixStageGroup()
//  cleanHiddenLayers()
//  addSEATLABELS()
//  buildSOPHierarchy(zoneLabel)
//  stripAndExport()
//  platinumlistSave()
//  quickSeatCount()
//  detailedSeatCount()
//  fixAllSOP()                Enhanced 50+ op recovery (SOP Ultimate)
//  renameGroupPrefix(oldPfx, newPfx)
//  renumberSelectedSeats()
//  resequenceSeatNumbers()
//  preBuildMap(paramsJSON)
//  autoGenerateSectionShapes()     Â§36  Auto-gen section fills from seat bounds
//  snapshotVersion()               Â§38  Timestamped version snapshot
//  splitByLevel(levelSpec)         Â§39  Multi-level venue splitter
//  hashRegistryCheck()             Â§40  Cross-file hash collision scan
//  venueStatusReport()             Â§41  Production readiness report

// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
//  SECTION 1  â€“  SHARED HELPERS
// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

var SOP_COLORS = {
    sectionFill   : [0.945, 0.945, 0.945],
    sectionStroke : [209/255, 210/255, 212/255],
    decorFill     : [1,     1,     1    ],
    decorStroke   : [209/255, 210/255, 212/255],
    labelText     : [0.42745, 0.43137, 0.43922],   // #6d6e70 (CSS-confirmed: text.section-decoration.p)
    stageFill     : [0.878, 0.878, 0.878],
    stageStroke   : [0.800, 0.800, 0.800],
    seatDefault   : [0.800, 0.800, 0.800]    // #CCCCCC
};

// ES3-safe string trim (String.prototype.trim absent in older ExtendScript)
function sopTrim(s) {
    s = String(s === undefined || s === null ? "" : s);
    var i = 0, j = s.length - 1;
    while (i <= j && (s.charAt(i) === " " || s.charAt(i) === "\t" ||
                      s.charAt(i) === "\n" || s.charAt(i) === "\r")) { i++; }
    while (j >= i && (s.charAt(j) === " " || s.charAt(j) === "\t" ||
                      s.charAt(j) === "\n" || s.charAt(j) === "\r")) { j--; }
    return s.substring(i, j + 1);
}

function makeColor(rgb) {
    var c = new RGBColor();
    c.red   = rgb[0] * 255;
    c.green = rgb[1] * 255;
    c.blue  = rgb[2] * 255;
    return c;
}

function colorToHex(color) {
    if (!color || color.typename !== "RGBColor") return "?";
    function h(v) { return ("0" + Math.round(v).toString(16)).slice(-2); }
    return "#" + h(color.red) + h(color.green) + h(color.blue);
}

function isSeatElement(item) {
    // FIX 15: Also accept CompoundPathItem; require minimum name length so
    // a stub "seatData-" name can't be mistaken for a real seat.
    if (!item) return false;
    if (typeof item.name !== "string") return false;
    if (item.name.indexOf("seatData-") !== 0) return false;
    if (item.name.length < 20) return false;
    var tn = item.typename;
    return tn === "Rectangle" ||
           tn === "PathItem"  ||
           tn === "CompoundPathItem";
}

function collectSeats(container, arr) {
 if(!container)return;
 // Illustrator document collections include descendants. Visit each direct child once.
 if(container.layers)for(var l=0;l<container.layers.length;l++)collectSeats(container.layers[l],arr);
 if(container.pageItems)for(var i=0;i<container.pageItems.length;i++){
  var item=container.pageItems[i];
  if(item.parent!==container)continue;
  if(isSeatElement(item))arr.push(item);else if(item.pageItems)collectSeats(item,arr);
 }
}

function getAllSeatNames(doc) {
    var seats = [];
    collectSeats(doc, seats);
    var names = [];
    for (var i = 0; i < seats.length; i++) names.push(seats[i].name);
    return names;
}

// Find ONE group by exact name (recursive)
function findGroupByName(container, name) {
    if (!container) return null;
    if (container.name === name) return container;
    if (container.layers) {
        for (var i = 0; i < container.layers.length; i++) {
            var r = findGroupByName(container.layers[i], name);
            if (r) return r;
        }
    }
    if (container.pageItems) {
        for (var i = 0; i < container.pageItems.length; i++) {
            var r = findGroupByName(container.pageItems[i], name);
            if (r) return r;
        }
    }
    return null;
}

// Collect ALL groups with EXACT name match (no prefix matching)
function findGroupsByExactName(container, name, arr) {
    if (!container) return;
    if (container.name === name) arr.push(container);
    if (container.layers) {
        for (var i = 0; i < container.layers.length; i++)
            findGroupsByExactName(container.layers[i], name, arr);
    }
    if (container.pageItems) {
        for (var i = 0; i < container.pageItems.length; i++)
            findGroupsByExactName(container.pageItems[i], name, arr);
    }
}

// Collect groups whose name STARTS WITH prefix (used for ZONE_ prefix)
function collectGroupsByPrefix(container, prefix, arr) {
    if (!container) return;
    if (container.name && container.name.indexOf(prefix) === 0) arr.push(container);
    if (container.layers) {
        for (var i = 0; i < container.layers.length; i++)
            collectGroupsByPrefix(container.layers[i], prefix, arr);
    }
    if (container.pageItems) {
        for (var i = 0; i < container.pageItems.length; i++)
            collectGroupsByPrefix(container.pageItems[i], prefix, arr);
    }
}

// Deterministic 13-char lowercase hex hash (SOP Â§6.4)
function makeHash(group, seatNum, seed) {
    if (!seed) seed = 0;
    var raw = group + "-" + seatNum + "-" + seed;
    var h1 = 5381;
    for (var i = 0; i < raw.length; i++)
        h1 = (((h1 << 5) + h1) + raw.charCodeAt(i)) >>> 0;
    var h2 = 52711;
    for (var j = raw.length - 1; j >= 0; j--)
        h2 = (((h2 << 5) + h2) ^ raw.charCodeAt(j)) >>> 0;
    return ("00000000" + h1.toString(16)).slice(-8) +
           ("00000"    + h2.toString(16)).slice(-5);
}

function collectNumericGroups(obj, saved) {
    if (!obj) return;
    if ((obj.typename === "Layer" || obj.typename === "GroupItem") &&
        obj.name && /^\d/.test(obj.name)) {
        saved.push({ item: obj, originalName: obj.name });
        obj.name = "Z" + obj.name;
    }
    if (obj.layers)    for (var i = 0; i < obj.layers.length; i++)
        collectNumericGroups(obj.layers[i], saved);
    if (obj.pageItems) for (var i = 0; i < obj.pageItems.length; i++)
        collectNumericGroups(obj.pageItems[i], saved);
}

function restoreNumericGroups(saved) {
    for (var i = 0; i < saved.length; i++) {
        try { saved[i].item.name = saved[i].originalName; } catch (e) {}
    }
}


// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
//  SECTION 2  â€“  BRIDGE TEST
// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

function getCEPHostDiagnostics() {
    try {
        return "AI=" + app.version +
               " | JSX engine=" + $.engineName +
               " | file=" + $.fileName +
               " | testCEP=" + (typeof testCEP);
    } catch (e) {
        return "DIAG_ERROR: " + e + " line=" + (e.line || "?");
    }
}

function testCEP() {
    try {
        return "Bridge fully operational â€“ Illustrator " +
               app.version + " / ExtendScript responding";
    } catch (e) {
        return "testCEP error: " + e;
    }
}


// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
//  SECTION 3  â€“  FULL 31-ITEM CHECKLIST  (SOP Â§12)
// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

function runFullChecklist() {
    try {
        if (app.documents.length === 0) return "ERROR:\nNo document open.";
        var doc   = app.activeDocument;
        var seats = [];
        collectSeats(doc, seats);
        var names = getAllSeatNames(doc);
        var lines = ["=== SOP \u00a712 Export Safety Checklist  (31 + 15b items) ===",
                     "April 2026 (Final) + direction attr  |  Seats found: " + seats.length, ""];
        var pass = 0, fail = 0, manual = 0;

        function row(num, label, result, detail) {
            // NOTE: ES3/Rhino chained ternary across lines is unreliable in
            // some ExtendScript builds â€” use explicit if/else for both display
            // prefix and counter to guarantee correctness.
            var pre;
            if      (result === "PASS") { pre = "\u2705 PASS"; pass++;   }
            else if (result === "FAIL") { pre = "\u274C FAIL"; fail++;   }
            else if (result === "MAN")  { pre = "\u270D MAN "; manual++; }
            else                        { pre = "\u26A0 WARN";           }
            var line = "#" + ("0" + num).slice(-2) + " " + pre + "  " + label;
            if (detail) line += "\n       \u21B3 " + detail;
            lines.push(line);
        }

        // â”€â”€ #01 Forbidden elements â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
        var FORB = ["ClipPathItem","RasterItem","PlacedItem","SymbolItem","MeshItem"];
        var forbFound = [];
        function inFORB(tn) {
            for (var fi = 0; fi < FORB.length; fi++) { if (FORB[fi] === tn) return true; }
            return false;
        }
        function scanF(obj) {
            if (inFORB(obj.typename)) forbFound.push(obj.typename);
            if (obj.pageItems) for (var i = 0; i < obj.pageItems.length; i++) scanF(obj.pageItems[i]);
        }
        scanF(doc);
        row(1, "No forbidden elements (clipPath/mask/symbol/image/use/filter/circle/ellipse/polygon)",
            forbFound.length === 0 ? "PASS" : "FAIL",
            forbFound.length > 0 ? forbFound.join(", ") + " found" : "");

        // â”€â”€ #02 Unique seat IDs â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
        var seen = {}, dupes = [];
        for (var i = 0; i < names.length; i++) {
            if (seen[names[i]]) { var _dup=names[i]; var _found=false; for(var _di=0;_di<dupes.length;_di++){if(dupes[_di]===_dup){_found=true;break;}} if(!_found) dupes.push(_dup); }
            else seen[names[i]] = true;
        }
        row(2, "Every seat has a unique seatData ID",
            dupes.length === 0 ? "PASS" : "FAIL",
            dupes.length > 0 ? dupes.length + " duplicate(s)" : "");

        // â”€â”€ #03 5 fields â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
        var bad5 = [];
        for (var i = 0; i < names.length; i++) {
            if (names[i].split("-").length !== 6) bad5.push(names[i]);
        }
        row(3, "Each seatData ID has exactly 5 fields after prefix",
            bad5.length === 0 ? "PASS" : "FAIL",
            bad5.length > 0 ? bad5.length + " malformed" : "");

        // â”€â”€ #04 SEAT fields identical â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
        var badSeat = [];
        for (var i = 0; i < names.length; i++) {
            var p = names[i].split("-");
            if (p.length === 6 && p[2] !== p[3]) badSeat.push(names[i]);
        }
        row(4, "Two SEAT fields identical (-5-5-)",
            badSeat.length === 0 ? "PASS" : "FAIL",
            badSeat.length > 0 ? badSeat.length + " mismatch(es)" : "");

        // â”€â”€ #05 Field 4 = 1 â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
        var badF4 = [];
        for (var i = 0; i < names.length; i++) {
            var p = names[i].split("-");
            if (p.length === 6 && p[4] !== "1") badF4.push(names[i]);
        }
        row(5, "Field 4 in every ID is literal digit 1",
            badF4.length === 0 ? "PASS" : "FAIL",
            badF4.length > 0 ? badF4.length + " wrong" : "");

        // â”€â”€ #06 GROUP no hyphens â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
        var badGrp = [];
        for (var i = 0; i < names.length; i++) {
            var p = names[i].split("-");
            if (p.length >= 2 && /[^A-Za-z0-9]/.test(p[1])) badGrp.push(names[i]);
        }
        row(6, "GROUP field contains no internal hyphens",
            badGrp.length === 0 ? "PASS" : "FAIL",
            badGrp.length > 0 ? badGrp.length + " bad GROUP(s)" : "");

        // â”€â”€ #07 Unique hashes â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
        var hSeen = {}, hDupes = [];
        for (var i = 0; i < names.length; i++) {
            var p = names[i].split("-");
            if (p.length === 6) {
                var h = p[5];
                if (hSeen[h]) { var _hf=false; for(var _hi=0;_hi<hDupes.length;_hi++){if(hDupes[_hi]===h){_hf=true;break;}} if(!_hf) hDupes.push(h); }
                else hSeen[h] = true;
            }
        }
        row(7, "All hash suffixes unique",
            hDupes.length === 0 ? "PASS" : "FAIL",
            hDupes.length > 0 ? hDupes.length + " duplicate hash(es)" : "");

        // â”€â”€ #08 No spaces in IDs â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
        var spIDs = [];
        for (var i = 0; i < names.length; i++) {
            if (names[i].indexOf(" ") !== -1) spIDs.push(names[i]);
        }
        row(8, "No spaces in any seat ID",
            spIDs.length === 0 ? "PASS" : "FAIL",
            spIDs.length > 0 ? spIDs.length + " contain spaces" : "");

        // â”€â”€ #09 rect/path only â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
        var badType = [];
        for (var i = 0; i < seats.length; i++) {
            if (seats[i].typename !== "Rectangle" && seats[i].typename !== "PathItem")
                badType.push(seats[i].name);
        }
        row(9, "All seat elements are rect or path only",
            badType.length === 0 ? "PASS" : "FAIL",
            badType.length > 0 ? badType.length + " wrong type(s)" : "");

        // â”€â”€ #10 7Ã—7px â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
        var badSz = 0;
        for (var i = 0; i < seats.length; i++) {
            if (Math.abs(seats[i].width - 7) > 0.25 || Math.abs(seats[i].height - 7) > 0.25) badSz++;
        }
        row(10, "Every seat is exactly 7x7 px",
            badSz === 0 ? "PASS" : "FAIL",
            badSz > 0 ? badSz + " wrong-size seat(s)" : "");

        // â”€â”€ #11 SEATLABELS â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
        var sl = findGroupByName(doc, "SEATLABELS");
        var sl11_st, sl11_dt;
        if (!sl) { sl11_st="FAIL"; sl11_dt="Not found"; }
        else if (sl.pageItems && sl.pageItems.length > 0) { sl11_st="FAIL"; sl11_dt="Has "+sl.pageItems.length+" child(ren)"; }
        else { sl11_st="PASS"; sl11_dt=""; }
        row(11, "SEATLABELS group present and empty", sl11_st, sl11_dt);

        // â”€â”€ #12 Section fills not white â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
        var secs = [];
        findGroupsByExactName(doc, "SECTION", secs);
        var wSec = 0;
        for (var i = 0; i < secs.length; i++) {
            if (secs[i].pageItems && secs[i].pageItems.length > 0) {
                var sh = secs[i].pageItems[0];
                if (sh.filled && sh.fillColor && sh.fillColor.typename === "RGBColor") {
                    if (Math.round(sh.fillColor.red)   === 255 &&
                        Math.round(sh.fillColor.green) === 255 &&
                        Math.round(sh.fillColor.blue)  === 255) wSec++;
                }
            }
        }
        row(12, "Section fills use #F1F1F1 not pure white",
            wSec === 0 ? "PASS" : "FAIL",
            wSec > 0 ? wSec + " using #FFFFFF" : "");

        // â”€â”€ #13 z-order (manual) â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
        row(13, "SECTION fill behind SEAT in z-order", "MAN",
            "Verify: SECTION below SEAT in Layers panel (bottom=back)");

        // â”€â”€ #14 No rotation â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
        var rot = 0;
        for (var i = 0; i < seats.length; i++) {
            if (Math.abs(seats[i].rotation) > 0.01) rot++;
        }
        row(14, "No rotation on seat elements",
            rot === 0 ? "PASS" : "FAIL",
            rot > 0 ? rot + " rotated seat(s)" : "");

        // â”€â”€ #15 STAGE one shape â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
        var stg = findGroupByName(doc, "STAGE");
        var stg_status, stg_detail;
        if (!stg) {
            stg_status = "FAIL"; stg_detail = "STAGE not found";
        } else if (!stg.pageItems || stg.pageItems.length !== 1) {
            stg_status = "FAIL"; stg_detail = "Has " + (stg.pageItems ? stg.pageItems.length : 0) + " items";
        } else {
            stg_status = "PASS"; stg_detail = "";
        }
        row(15, "STAGE group has exactly one shape", stg_status, stg_detail);

        // â”€â”€ #16 DECORATION exists â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
        var dec = findGroupByName(doc, "DECORATION");
        row(16, "DECORATION group exists", dec ? "PASS" : "FAIL", dec ? "" : "Not found");

        // â”€â”€ #17 SECTIONDECORATION no nested groups â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
        var sdecs = [];
        findGroupsByExactName(doc, "SECTIONDECORATION", sdecs);
        var nest = 0;
        for (var i = 0; i < sdecs.length; i++) {
            if (sdecs[i].pageItems) {
                for (var j = 0; j < sdecs[i].pageItems.length; j++) {
                    if (sdecs[i].pageItems[j].typename === "GroupItem") nest++;
                }
            }
        }
        // #17: nested groups in SECTIONDECORATION do NOT block Constructor loading.
        // Demoted to WARN â€” use the standalone Flatten button only if labels look wrong.
        row(17, "SECTIONDECORATION has no nested groups",
            nest === 0 ? "PASS" : "WARN",
            nest > 0 ? nest + " nested group(s) â€” Constructor still loads. " +
                       "Use Fix Tab \u2192 Flatten SECTIONDECORATION only if label text is missing." : "");

        // â”€â”€ #18 SECTION one shape â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
        var wSc = 0;
        for (var i = 0; i < secs.length; i++) {
            if (!secs[i].pageItems || secs[i].pageItems.length !== 1) wSc++;
        }
        row(18, "Each SECTION has exactly one shape",
            wSc === 0 ? "PASS" : "FAIL",
            wSc > 0 ? wSc + " wrong count" : "");

        row(19, "SVG < 5 MB, target <= 500 KB", "MAN", "Run Export to check size");
        row(20, "Seat count matches manifest",   "MAN", "Cross-check " + seats.length + " seats");
        row(21, "Aisle gaps = missing seat numbers in manifest", "MAN", "Verify visually");

        // â”€â”€ #22 No hidden layers â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
        var hid = 0;
        function chkHid(obj) {
            if (obj.visible === false) hid++;
            if (obj.layers)    for (var i = 0; i < obj.layers.length; i++)    chkHid(obj.layers[i]);
            if (obj.pageItems) for (var i = 0; i < obj.pageItems.length; i++) chkHid(obj.pageItems[i]);
        }
        chkHid(doc);
        row(22, "No hidden layers remain",
            hid === 0 ? "PASS" : "FAIL",
            hid > 0 ? hid + " hidden item(s)" : "");

        row(23, "Rename IDs on Export is disabled", "MAN", "Check SVG Export Options dialog");

        // â”€â”€ #24 Sublayer names have no _n_ numeric suffix â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
        // SOP (April 2026): sublayers must be SECTION, SEAT, SECTIONDECORATION
        // (never SECTION, SEAT, etc.) and no leftover temp __ names
        var badSubNames = [];
        function scanSubNames(container) {
            if (!container) return;
            var n = container.name || "";
            // Bad if has _n_ suffix  (SECTION, SEAT, etc.)
            if (/^(SECTION|SEAT|SECTIONDECORATION|SEATDECORATION|UNDERSEATDECORATION)_\d+_?$/.test(n)) {
                badSubNames.push(n + " \u2192 should be " + n.replace(/_\d+_?$/, ""));
            }
            // Bad if bare trailing digit â€” Illustrator appends these when multiple
            // zones share the same sublayer name (root cause of SECTION1/SEAT1 errors).
            // Longest match first to avoid SECTIONDECORATION matching SECTION rule.
            if (/^(SECTIONDECORATION|UNDERSEATDECORATION|SEATDECORATION|SEATLABELS|DECORATION|SECTION|SEAT|STAGE)\d+$/i.test(n)) {
                badSubNames.push(n + " \u2192 should be " + n.replace(/\d+$/, "") + "  (\u26A0 run Fix Everything before export)");
            }
            // Bad if leftover temp __name__
            if (/^__[A-Z_]+__/.test(n)) {
                badSubNames.push(n + " \u2192 WRONG (temp name not renamed â€” re-run PreBuild or Fix All)");
            }
            if (container.pageItems) {
                for (var i = 0; i < container.pageItems.length; i++)
                    scanSubNames(container.pageItems[i]);
            }
            if (container.layers) {
                for (var i = 0; i < container.layers.length; i++)
                    scanSubNames(container.layers[i]);
            }
        }
        scanSubNames(doc);
        row(24, "Sublayer names correct â€” no _n_ suffix, no temp names (April 2026 Final)",
            badSubNames.length === 0 ? "PASS" : "FAIL",
            badSubNames.length > 0 ?
                badSubNames.slice(0, 5).join(" | ") +
                (badSubNames.length > 5 ? " ...+" + (badSubNames.length - 5) + " more" : "") +
                "\n       Run Fix Tab \u2192 Fix Everything to auto-rename." : "");

        // â”€â”€ #25-31 Manual checks â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
        row(25, "Hash seeds include coordinates or group+seat", "MAN",
            "Verify hash generation includes zone, row, seat indices");
        row(26, "Hash collision handled by attempt counter", "MAN",
            "Verify while(usedHash[hash]) attempt loop present");
        row(27, "Seats placed at exact source position (visual overlay)", "MAN",
            "Do not snap to grid if curved â€” compare with source plan");
        row(28, "Curved rows use <path> template in exported SVG", "MAN",
            "Verify exported SVG: curved seats should be <path> not <rect>");
        row(29, "Row sort direction matches arena bowl orientation", "MAN",
            "Check nearest-to-stage vs furthest row ordering");
        row(30, "Seat numbering is stage-facing L to R", "MAN",
            "Seat 1 at left when viewed from stage, highest at right");
        row(31, "Final overlay comparison with source plan signed off", "MAN",
            "Check exported SVG against original venue plan before upload");

        lines.push("");
        lines.push("â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€");
        lines.push("PASS: " + pass + "  |  FAIL: " + fail + "  |  MANUAL: " + manual);
        lines.push(fail === 0 ? "\u2705 All automated checks passed." :
                                "\u26A0 " + fail + " failure(s) â€“ fix before export.");
        lines.push("Manual items require human verification.");
        return lines.join("\n");

    } catch (e) {
        return "runFullChecklist CRASH:\n" + e + "\n(line " + (e.line || "?") + ")";
    }
}


// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
//  SECTION 4  â€“  VALIDATE GEOMETRY
// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

function validateGeometry() {
    try {
        if (app.documents.length === 0) return "ERROR:\nNo document open.";
        var doc   = app.activeDocument;
        var seats = [];
        collectSeats(doc, seats);
        var report = ["=== SOP Geometry + ID Validation  (April 2026 Final) ===",
                      "Seats found: " + seats.length];

        if (seats.length === 0) {
            return report.join("\n") + "\n\nNo seatData-* elements found.\n" +
                   "Seats must be named  seatData-{GROUP}-{N}-{N}-1-{HASH}";
        }

        var badSize = 0, rotated = 0, centers = [];
        var idRx  = /^seatData-[A-Za-z0-9]+-([0-9]+)-\1-1-[a-f0-9]{6,13}$/;
        var badIDs = [];

        for (var i = 0; i < seats.length; i++) {
            var s = seats[i];
            if (Math.abs(s.width - 7) > 0.25 || Math.abs(s.height - 7) > 0.25) badSize++;
            if (Math.abs(s.rotation) > 0.01) rotated++;
            var b = s.geometricBounds;
            centers.push({ x: (b[0] + b[2]) / 2, y: (b[1] + b[3]) / 2 });
            if (!idRx.test(s.name)) badIDs.push(s.name);
        }

        // Overlap check
        var CELL = 9, grid = {}, closePairs = 0;
        for (var gi = 0; gi < centers.length; gi++) {
            var gk = Math.floor(centers[gi].x / CELL) + "," + Math.floor(centers[gi].y / CELL);
            if (!grid[gk]) grid[gk] = [];
            grid[gk].push(gi);
        }
        for (var a = 0; a < centers.length; a++) {
            var agx = Math.floor(centers[a].x / CELL), agy = Math.floor(centers[a].y / CELL);
            for (var dx = -1; dx <= 1; dx++) {
                for (var dy = -1; dy <= 1; dy++) {
                    var cell = grid[(agx + dx) + "," + (agy + dy)];
                    if (!cell) continue;
                    for (var ni = 0; ni < cell.length; ni++) {
                        var bi = cell[ni]; if (bi <= a) continue;
                        var ddx = centers[a].x - centers[bi].x,
                            ddy = centers[a].y - centers[bi].y;
                        if (Math.sqrt(ddx * ddx + ddy * ddy) < 8.9) closePairs++;
                    }
                }
            }
        }

        if (badSize    > 0) report.push("\u26A0 " + badSize    + " seat(s) wrong size â€“ must be 7x7 px");
        if (rotated    > 0) report.push("\u26A0 " + rotated    + " seat(s) rotated â€“ axis-aligned only");
        if (closePairs > 0) report.push("\u26A0 " + closePairs + " pair(s) < 9 px apart (overlapping)");
        if (badIDs.length > 0) {
            report.push("\u26A0 " + badIDs.length + " malformed ID(s):");
            var show = badIDs.length > 6 ? badIDs.slice(0, 6) : badIDs;
            for (var k = 0; k < show.length; k++) report.push("  " + show[k]);
            if (badIDs.length > 6) report.push("  ...+" + (badIDs.length - 6) + " more");
        }

        var sl = findGroupByName(doc, "SEATLABELS");
        if (!sl) report.push("\u26A0 SEATLABELS group missing");
        else if (sl.pageItems && sl.pageItems.length > 0) report.push("\u26A0 SEATLABELS not empty");

        // ES3-safe forbidden check
        var FORB2 = ["ClipPathItem","RasterItem","PlacedItem","SymbolItem","MeshItem"];
        var hasFb = false;
        function inFORB2(tn) {
            for (var fi = 0; fi < FORB2.length; fi++) { if (FORB2[fi] === tn) return true; }
            return false;
        }
        function scanFb(obj) {
            if (inFORB2(obj.typename)) hasFb = true;
            if (obj.pageItems) for (var i = 0; i < obj.pageItems.length; i++) scanFb(obj.pageItems[i]);
        }
        scanFb(doc);
        if (hasFb) report.push("\u26A0 Forbidden element type(s) found");

        var warns = 0;
        for (var ri = 0; ri < report.length; ri++) if (report[ri].charAt(0) === "\u26A0") warns++;
        report.push(warns === 0 ? "\n\u2705 All geometry checks passed â€“ " + seats.length + " seats" :
                                  "\n" + warns + " warning(s) â€“ resolve before export");
        return report.join("\n");

    } catch (e) { return "validateGeometry CRASH:\n" + e; }
}


// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
//  SECTION 5  â€“  DUPLICATE CHECK
// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

function findDuplicates() {
    try {
        if (app.documents.length === 0) return "ERROR:\nNo document open.";
        var names = getAllSeatNames(app.activeDocument);
        var seen = {}, dups = [];
        for (var i = 0; i < names.length; i++) {
            if (seen[names[i]]) { var _d=names[i]; var _fd=false; for(var _ddi=0;_ddi<dups.length;_ddi++){if(dups[_ddi]===_d){_fd=true;break;}} if(!_fd) dups.push(_d); }
            else seen[names[i]] = true;
        }
        if (dups.length > 0) {
            var out = "DUPLICATES FOUND: " + dups.length + "\n";
            var show = dups.length > 8 ? dups.slice(0, 8) : dups;
            for (var k = 0; k < show.length; k++) out += "  " + show[k] + "\n";
            if (dups.length > 8) out += "  ...+" + (dups.length - 8) + " more\n";
            return out + "\nFix: run Generate Seat IDs to assign fresh unique hashes.";
        }
        return "\u2705 Clean â€“ " + names.length + " unique seatData IDs.";
    } catch (e) { return "findDuplicates error:\n" + e; }
}


// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
//  SECTION 6  â€“  GENERATE SEAT IDs
// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

function generateSeatIDs(prefix) {
    try {
        if (app.documents.length === 0) return "ERROR:\nNo document open.";
        if (!prefix) return "ERROR:\nNo GROUP prefix â€“ type it in the panel field first.";
        if (/[-]/.test(prefix))         return "ERROR:\nGROUP prefix must NOT contain hyphens (SOP Â§6.1).";
        if (!/^[A-Za-z0-9]+$/.test(prefix)) return "ERROR:\nGROUP prefix must be alphanumeric only.";

        var doc = app.activeDocument;
        var sel = doc.selection;
        if (!sel || sel.length === 0) return "ERROR:\nNothing selected â€“ select seat shapes first.";

        var seats = [];
        for (var i = 0; i < sel.length; i++) {
            var item = sel[i];
            if (item.typename === "Rectangle" || item.typename === "PathItem") seats.push(item);
            else if (item.pageItems) collectSeats(item, seats);
        }
        if (seats.length === 0) return "ERROR:\nNo rect/path shapes in selection.";

        seats.sort(function (a, b) {
            var ay = a.geometricBounds[1], by = b.geometricBounds[1];
            if (Math.abs(ay - by) > 4) return by - ay;
            return a.geometricBounds[0] - b.geometricBounds[0];
        });

        var existing = getAllSeatNames(doc), changed = 0;
        for (var j = 0; j < seats.length; j++) {
            var sn = j + 1, seed = 0;
            var hash  = makeHash(prefix, sn, seed);
            var newID = "seatData-" + prefix + "-" + sn + "-" + sn + "-1-" + hash;
            while ((function(){for(var _ei=0;_ei<existing.length;_ei++){if(existing[_ei]===newID)return true;}return false;})()) {
                seed++;
                hash  = makeHash(prefix, sn, seed);
                newID = "seatData-" + prefix + "-" + sn + "-" + sn + "-1-" + hash;
            }
            seats[j].name = newID;
            existing.push(newID);
            changed++;
        }
        return "\u2705 Assigned " + changed + " SOP IDs\nPrefix: " + prefix +
               "\nRange: " + prefix + "-1 to " + prefix + "-" + changed +
               "\nRun Validate + Duplicates to confirm.";
    } catch (e) { return "generateSeatIDs error:\n" + e; }
}


// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
//  SECTION 7  â€“  FIX SECTION FILLS
// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

function fixSectionFills() {
    try {
        if (app.documents.length === 0) return "ERROR:\nNo document open.";
        var doc        = app.activeDocument;
        var secFill    = makeColor(SOP_COLORS.sectionFill);
        var secStroke  = makeColor(SOP_COLORS.sectionStroke);
        var decorFill  = makeColor(SOP_COLORS.decorFill);
        var stageFill  = makeColor(SOP_COLORS.stageFill);
        var stageStroke= makeColor(SOP_COLORS.stageStroke);
        var fixed      = 0;

        // Fix SECTION groups (exact name)
        var sections = [];
        findGroupsByExactName(doc, "SECTION", sections);
        for (var i = 0; i < sections.length; i++) {
            if (!sections[i].pageItems) continue;
            for (var j = 0; j < sections[i].pageItems.length; j++) {
                var sh = sections[i].pageItems[j];
                if (sh.typename === "PathItem" || sh.typename === "CompoundPathItem" ||
                    sh.typename === "Rectangle") {
                    sh.filled      = true; sh.fillColor   = secFill;
                    sh.stroked     = true; sh.strokeColor = secStroke; sh.strokeWidth = 1;
                    fixed++;
                }
            }
        }

        // Fix SECTIONDECORATION badge paths (exact name)
        var sdecs = [];
        findGroupsByExactName(doc, "SECTIONDECORATION", sdecs);
        for (var i = 0; i < sdecs.length; i++) {
            if (!sdecs[i].pageItems) continue;
            for (var j = 0; j < sdecs[i].pageItems.length; j++) {
                var sh = sdecs[i].pageItems[j];
                if ((sh.typename === "PathItem" || sh.typename === "Rectangle") &&
                    sh.typename !== "TextFrame") {
                    sh.filled = true; sh.fillColor   = decorFill;
                    sh.stroked= true; sh.strokeColor = secStroke;
                    fixed++;
                }
            }
        }

        // Fix STAGE
        var stg = findGroupByName(doc, "STAGE");
        if (stg && stg.pageItems && stg.pageItems.length > 0) {
            var s0 = stg.pageItems[0];
            if (s0.typename !== "TextFrame") {
                s0.filled = true; s0.fillColor   = stageFill;
                s0.stroked= true; s0.strokeColor = stageStroke; s0.strokeWidth = 1;
                fixed++;
            }
        }

        return "\u2705 Fixed " + fixed + " shape(s).\n" +
               "Section: #F1F1F1 / #D1D2D4\nBadge: #FFFFFF / #D1D2D4\nStage: #E0E0E0 / #CCCCCC";
    } catch (e) { return "fixSectionFills error:\n" + e; }
}


// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
//  SECTION 8  â€“  FIX SEAT STROKES
// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

function fixSeatStrokes() {
    try {
        if (app.documents.length === 0) return "ERROR:\nNo document open.";
        var seats = []; collectSeats(app.activeDocument, seats);
        if (seats.length === 0) return "No seatData-* elements found.";
        for (var i = 0; i < seats.length; i++) seats[i].stroked = false;
        return "\u2705 Set stroke=none on " + seats.length + " seat(s).";
    } catch (e) { return "fixSeatStrokes error:\n" + e; }
}


// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
//  SECTION 9  â€“  FIX LABEL COLORS
// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

function fixLabelColors() {return healTextColors();}


// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
//  SECTION 10  â€“  FIX STAGE GROUP
// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

function fixStageGroup() {
    try {
        if (app.documents.length === 0) return "ERROR:\nNo document open.";
        var doc = app.activeDocument;
        var stg = findGroupByName(doc, "STAGE");
        if (!stg) return "ERROR:\nSTAGE group not found.";

        var dec = findGroupByName(doc, "DECORATION");
        var moved = 0, report = [];

        if (stg.pageItems) {
            for (var i = stg.pageItems.length - 1; i >= 0; i--) {
                var item = stg.pageItems[i];
                if (item.typename === "TextFrame" || item.typename === "GroupItem") {
                    if (dec) item.move(dec, ElementPlacement.PLACEATBEGINNING);
                    else     item.move(doc.layers[0], ElementPlacement.PLACEATBEGINNING);
                    moved++;
                    report.push("Moved: " + item.typename + " \u2192 DECORATION");
                }
            }
        }

        var rem = stg.pageItems ? stg.pageItems.length : 0;
        var dirMsg = "";

        // â”€â”€ direction attribute (SOP Technical Appendix Â§A1.4) â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
        // The JS reads primitive.attr("direction") on the stage shape at runtime.
        // We can't set arbitrary SVG attrs in ExtendScript; the stripAI2026Suffixes
        // post-processor injects direction="up" automatically on export.
        // Here we just report status so user knows to run Yousuf Weiji Save.
        if (stg.pageItems && stg.pageItems.length === 1) {
            dirMsg = "\n\n\u2139 direction=\"up\" will be injected automatically\n" +
                     "   when you run Yousuf Weiji Save / Export.";
        }

        if (moved === 0 && rem === 1) return "\u2705 STAGE already clean â€“ 1 shape." + dirMsg;
        if (moved === 0)              return "\u26A0 STAGE has " + rem + " item(s) â€“ manually ensure exactly 1.";
        return "\u2705 Moved " + moved + " item(s) from STAGE.\n" + report.join("\n") +
               "\nSTAGE now has " + rem + " item(s)." + dirMsg;
    } catch (e) { return "fixStageGroup error:\n" + e; }
}


// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
//  SECTION 11  â€“  CLEAN HIDDEN LAYERS
// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

function cleanHiddenLayers() {
    try {
        if (app.documents.length === 0) return "ERROR:\nNo document open.";
        var doc = app.activeDocument, deleted = 0;

        function delHidden(container) {
            if (!container) return;
            if (container.layers) {
                for (var i = container.layers.length - 1; i >= 0; i--) {
                    if (container.layers[i].visible === false) {
                        container.layers[i].remove(); deleted++;
                    } else { delHidden(container.layers[i]); }
                }
            }
            if (container.pageItems) {
                for (var i = container.pageItems.length - 1; i >= 0; i--) {
                    var item = container.pageItems[i];
                    if (item.hidden === true || item.visible === false) {
                        try { item.remove(); deleted++; } catch (re) {}
                    } else if (item.pageItems) { delHidden(item); }
                }
            }
        }
        delHidden(doc);
        return deleted === 0 ? "\u2705 No hidden layers found." :
               "\u2705 Deleted " + deleted + " hidden item(s). Re-export for accurate size.";
    } catch (e) { return "cleanHiddenLayers error:\n" + e; }
}


// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
//  SECTION 12  â€“  ADD SEATLABELS
// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

function addSEATLABELS() {
    try {
        if (app.documents.length === 0) return "ERROR:\nNo document open.";
        var doc = app.activeDocument;
        var sl  = findGroupByName(doc, "SEATLABELS");
        if (sl) {
            sl.zOrder(ZOrderMethod.SENDTOBACK);
            var empty = sl.pageItems.length === 0;
            return (empty ? "\u2705" : "\u26A0") +
                   " SEATLABELS exists â€“ moved to last position.\n" +
                   (empty ? "Empty (correct)." : "WARNING: has " + sl.pageItems.length + " child(ren) â€“ must be empty.");
        }
        var ng = doc.groupItems.add();
        ng.name = "SEATLABELS";
        ng.zOrder(ZOrderMethod.SENDTOBACK);
        return "\u2705 Created empty SEATLABELS as last element.";
    } catch (e) { return "addSEATLABELS error:\n" + e; }
}


// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
//  SECTION 13  â€“  BUILD SOP HIERARCHY
//
//  SOP April 2026 (Final) sublayer names â€” NO numeric suffixes:
//    SECTION, UNDERSEATDECORATION, SEAT, SEATDECORATION, SECTIONDECORATION
//
//  Z-order inside ZONE (backâ†’front in SVG / bottomâ†’top in AI panel):
//    SECTION (back)
//    UNDERSEATDECORATION
//    SEAT
//    SEATDECORATION
//    SECTIONDECORATION (front)
// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

function buildSOPHierarchy(zoneLabel) {
    try {
        if (app.documents.length === 0) return "ERROR:\nNo document open.";
        var doc = app.activeDocument;
        if (!zoneLabel || zoneLabel === "") zoneLabel = "A";
        zoneLabel = sopTrim(zoneLabel).toUpperCase().replace(/[^A-Z0-9]/g, "") || "A";

        var created = [];
        var layer   = doc.layers[0];

        function ensureGroup(name, parent) {
            // Scope search to direct children of parent ONLY.
            // Using findGroupByName(doc, name) caused cross-zone sharing:
            // buildSOPHierarchy("GOLD") would find SECTION from ZONE_A and
            // return it, leaving ZONE_GOLD without its own SECTION sublayer.
            // Illustrator then auto-appended numeric suffixes on export (SECTION1).
            if (parent.pageItems) {
                for (var _ei = 0; _ei < parent.pageItems.length; _ei++) {
                    if (parent.pageItems[_ei].typename === "GroupItem" &&
                        parent.pageItems[_ei].name === name) {
                        return parent.pageItems[_ei];
                    }
                }
            }
            var g = parent.groupItems.add();
            g.name = name;
            created.push(name);
            return g;
        }

        // â”€â”€ SEATLABELS (front = top of Layers panel) â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
        var sl = ensureGroup("SEATLABELS", layer);
        // Will stay at front; other groups pushed to back below

        // â”€â”€ ZONE group â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
        var zoneName = "ZONE_" + zoneLabel;
        var zone     = ensureGroup(zoneName, layer);
        zone.zOrder(ZOrderMethod.SENDTOBACK);

        // â”€â”€ Zone sublayers â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
        // v6.3: canonical SOP names; legacy numeric suffixes are input only.
        // later by the SVG-export step where Illustrator's serializer needs it
        // to preserve the id. Working in the layers panel stays uncluttered.
        var sec = ensureGroup("SECTION", zone);
        sec.zOrder(ZOrderMethod.SENDTOBACK);
        // Each subsequent add() goes to front, so order becomes:
        // SECTION(back), UNDERSEATDECORATION, SEAT, SEATDECORATION, SECTIONDECORATION(front)
        ensureGroup("UNDERSEATDECORATION", zone);
        ensureGroup("SEAT",                zone);
        ensureGroup("SEATDECORATION",      zone);
        ensureGroup("SECTIONDECORATION",   zone);

        // â”€â”€ DECORATION (behind zones) â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
        var dec = ensureGroup("DECORATION", layer);
        dec.zOrder(ZOrderMethod.SENDTOBACK);

        // â”€â”€ STAGE (very back) â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
        var stg = ensureGroup("STAGE", layer);
        stg.zOrder(ZOrderMethod.SENDTOBACK);

        var msg = created.length === 0
            ? "\u2705 All SOP groups already exist."
            : "\u2705 Created " + created.length + " group(s):\n" + created.join("\n");

        msg += "\n\nZ-order (back\u2192front):\n" +
               "  STAGE\n  DECORATION\n  " + zoneName + "\n" +
               "    SECTION\n    UNDERSEATDECORATION\n    SEAT\n" +
               "    SEATDECORATION\n    SECTIONDECORATION\n  SEATLABELS\n\n" +
               "Next:\n" +
               "  1. Draw section fill shape inside SECTION\n" +
               "  2. Place seat rects inside SEAT\n" +
               "  3. Add badge+text inside SECTIONDECORATION\n" +
               "  4. Run Generate Seat IDs on seat shapes\n" +
               "  5. Run Yousuf Weiji Save (auto-injects direction=up on STAGE shape)";
        return msg;
    } catch (e) { return "buildSOPHierarchy error:\n" + e; }
}


// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
//  SECTION 14  â€“  SAFE SVG EXPORT OPTIONS
// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

function safeSOPExportOpts() {
    var opts = new ExportOptionsSVG();
    try      { opts.documentEncoding = SVGDocumentEncoding.UTF8; }
    catch(e) { try { opts.documentEncoding = SVGDocumentEncoding.UTF_8; }
               catch(e2) { opts.documentEncoding = 3; } }
    try      { opts.cssProperties = SVGCSSPropertyLocation.PRESENTATIONATTRIBUTES; }
    catch(e) { try { opts.cssProperties = SVGCSSPropertyLocation.PRESENTATIONATTRIBUTE; }
               catch(e2) { opts.cssProperties = 4; } }
    try      { opts.fontType = SVGFontType.SVG; }
    catch(e) { try { opts.fontType = SVGFontType.SVGFONT; }
               catch(e2) { opts.fontType = 0; } }
    try      { opts.fontSubsetting = SVGFontSubsetting.NONE; }
    catch(e) { try { opts.fontSubsetting = SVGFontSubsetting.None; }
               catch(e2) { opts.fontSubsetting = 0; } }
    opts.embedRasterImages   = false;
    opts.coordinatePrecision = 2;
    opts.preserveEditability = false;
    return opts;
}


// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
//  SECTION 15  â€“  AI 2026 SUFFIX STRIPPER
//
//  Illustrator appends numeric suffixes to group IDs on export.
//  Process LONGER names FIRST to avoid partial matches:
//    SECTIONDECORATION before SECTION
//    SEATDECORATION before SEAT
//    UNDERSEATDECORATION before DECORATION
//    DECORATION last (among DECORATION variants)
// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

function stripAI2026Suffixes(svgFile) {
    if (!svgFile.open("r")) return -1;
    svgFile.encoding = "UTF-8";
    var content = svgFile.read();
    svgFile.close();
    if (!content) return -1;

    var before = content, fixCount = 0;

    // â”€â”€ Inject direction="up" on stage shape if missing â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    // Required by runtime JS: _initStage(primitiveNode, primitive.attr("direction"))
    // Targets the first <rect> or <path> directly inside the STAGE group.
    // Illustrator cannot set arbitrary SVG attrs, so we inject post-export.
    if (content.indexOf('id="STAGE"') !== -1 && content.indexOf('direction=') === -1) {
        var dc = content.replace(
            /(id="STAGE"[\s\S]{0,300}?)(<(?:rect|path)\b)/,
            '$1$2 direction="up"'
        );
        if (dc !== content) { content = dc; fixCount++; }
    }

    var rules = [
        // Longer/specific names first to avoid partial match
        [/id="SECTIONDECORATION[0-9]+"/g,       'id="SECTIONDECORATION"'],
        [/id="UNDERSEATDECORATION[0-9]+"/g,      'id="UNDERSEATDECORATION"'],
        [/id="SEATDECORATION[0-9]+"/g,           'id="SEATDECORATION"'],
        [/id="SEATLABELS[0-9]+"/g,               'id="SEATLABELS"'],
        [/id="DECORATION[0-9]+"/g,               'id="DECORATION"'],
        [/id="SECTION[0-9]+"/g,                  'id="SECTION"'],
        [/id="SEAT[0-9]+"/g,                     'id="SEAT"'],
        [/id="STAGE[0-9]+"/g,                    'id="STAGE"'],
        // Legacy _n_ suffix strip (files from older versions)
        [/id="SECTION_[0-9]+_"/g,              'id="SECTION"'],
        [/id="SEAT_[0-9]+_"/g,                 'id="SEAT"'],
        [/id="SECTIONDECORATION_[0-9]+_"/g,    'id="SECTIONDECORATION"']
    ];
    for (var ri = 0; ri < rules.length; ri++) {
        var after = content.replace(rules[ri][0], rules[ri][1]);
        if (after !== content) { fixCount++; content = after; }
    }
    if (content === before) return 0;
    if (!svgFile.open("w")) return -1;
    svgFile.encoding = "UTF-8";
    svgFile.write(content);
    svgFile.close();
    return fixCount;
}


// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

// PRODUCTION GUARD 6.2 — sanitize exported SVG before upload.
// Security: strips DOCTYPE / ENTITY declarations so external XML entities can never survive.
// SOP: canonicalizes Illustrator-renamed sublayers and converts simple circle/ellipse/polygon
// primitives to <path>, while refusing unsafe constructs that cannot be losslessly repaired.
function sanitizeSOPSVG(svgFile) {
    try {
        if (!svgFile || !svgFile.exists) return {ok:false, message:"SVG file missing", fixes:0};
        if (!svgFile.open("r")) return {ok:false, message:"Cannot read exported SVG", fixes:0};
        svgFile.encoding = "UTF-8";
        var content = svgFile.read();
        svgFile.close();
        if (!content) return {ok:false, message:"SVG is empty", fixes:0};
        var fixes = 0, before;

        before = content;
        content = content.replace(/<!DOCTYPE(?:[^>"'\[]|"[^"]*"|'[^']*')*(?:\[[\s\S]*?\]\s*)?>/gi, "");
        content = content.replace(/<!ENTITY[\s\S]*?>/gi, "");
        if (/&(?!(?:amp|lt|gt|quot|apos);|#\d+;|#x[0-9a-f]+;)[A-Za-z_][\w.-]*;/i.test(content)) return {ok:false, message:"Unresolved XML entity reference", fixes:fixes};
        if (content !== before) fixes++;

        // Canonical SOP names — NO _n_ suffixes.
        var canon = [
            [/id="SECTIONDECORATION(?:_\d+_|\d+)"/gi, 'id="SECTIONDECORATION"'],
            [/id="UNDERSEATDECORATION(?:_\d+_|\d+)"/gi, 'id="UNDERSEATDECORATION"'],
            [/id="SEATDECORATION(?:_\d+_|\d+)"/gi, 'id="SEATDECORATION"'],
            [/id="SECTION(?:_\d+_|\d+)"/gi, 'id="SECTION"'],
            [/id="SEAT(?:_\d+_|\d+)"/gi, 'id="SEAT"'],
            [/id="SEATLABELS(?:_\d+_|\d+)"/gi, 'id="SEATLABELS"'],
            [/id="DECORATION(?:_\d+_|\d+)"/gi, 'id="DECORATION"'],
            [/id="STAGE(?:_\d+_|\d+)"/gi, 'id="STAGE"']
        ];
        for (var ci=0; ci<canon.length; ci++) { before=content; content=content.replace(canon[ci][0], canon[ci][1]); if(content!==before) fixes++; }

        function attrsWithout(tag, names) {
            var a = tag.replace(/<\/(?:circle|ellipse|polygon)\s*>$/i, "");
            for (var ni=0; ni<names.length; ni++) {
                var rx = new RegExp('\\s+' + names[ni] + '="[^"]*"', 'ig');
                a = a.replace(rx, '');
            }
            a = a.replace(/^<\w+/, '').replace(/\/?\s*>$/, '');
            return a;
        }
        function numAttr(tag, name, def) {
            var m = new RegExp('\\s' + name + '="([+-]?(?:\\d+\\.?\\d*|\\.\\d+))"','i').exec(tag);
            return m ? parseFloat(m[1]) : def;
        }
        before=content;
        content = content.replace(/<circle\b[^>]*\/?\s*>(?:\s*<\/circle\s*>)?/gi, function(tag){
            var cx=numAttr(tag,'cx',0), cy=numAttr(tag,'cy',0), r=numAttr(tag,'r',0);
            var a=attrsWithout(tag,['cx','cy','r']);
            var d='M '+(cx-r)+' '+cy+' A '+r+' '+r+' 0 1 0 '+(cx+r)+' '+cy+' A '+r+' '+r+' 0 1 0 '+(cx-r)+' '+cy+' Z';
            return '<path'+a+' d="'+d+'"/>';
        });
        content = content.replace(/<ellipse\b[^>]*\/?\s*>(?:\s*<\/ellipse\s*>)?/gi, function(tag){
            var cx=numAttr(tag,'cx',0), cy=numAttr(tag,'cy',0), rx=numAttr(tag,'rx',0), ry=numAttr(tag,'ry',0);
            var a=attrsWithout(tag,['cx','cy','rx','ry']);
            var d='M '+(cx-rx)+' '+cy+' A '+rx+' '+ry+' 0 1 0 '+(cx+rx)+' '+cy+' A '+rx+' '+ry+' 0 1 0 '+(cx-rx)+' '+cy+' Z';
            return '<path'+a+' d="'+d+'"/>';
        });
        content = content.replace(/<polygon\b[^>]*\/?\s*>(?:\s*<\/polygon\s*>)?/gi, function(tag){
            var pm=/\spoints="([^"]+)"/i.exec(tag); if(!pm) return tag;
            var pts=sopTrim(pm[1]).replace(/,/g,' ').replace(/\s+/g,' ').split(' ');
            if(pts.length<4) return tag;
            var d='M '+pts[0]+' '+pts[1]; for(var pi=2;pi+1<pts.length;pi+=2) d+=' L '+pts[pi]+' '+pts[pi+1]; d+=' Z';
            var a=attrsWithout(tag,['points']); return '<path'+a+' d="'+d+'"/>';
        });
        if(content!==before) fixes++;


        content=content.replace(/(<g\b[^>]*\bid="STAGE"[^>]*>)(\s*)(<(?:rect|path)\b[^>]*>)/g,function(all,gap,space,shape){
            if(/\bdirection=/.test(gap)||/\bdirection=/.test(shape))return all;
            return gap+space+shape.replace(/^<(rect|path)\b/,'<$1 direction="up"');
        });

        // Unsafe constructs are not auto-deleted: failing is safer than silently changing artwork.
        var unsafe = [];
        var checks = ['clipPath','mask','symbol','image','use','filter','circle','ellipse','polygon','script','foreignObject'];
        for(var ui=0;ui<checks.length;ui++) if(new RegExp('<'+checks[ui]+'\\b','i').test(content)) unsafe.push(checks[ui]);
        if(unsafe.length) return {ok:false, message:'Unsafe SVG element(s) remain: '+unsafe.join(', '), fixes:fixes};

        if (!svgFile.open("w")) return {ok:false, message:"Cannot rewrite sanitized SVG", fixes:fixes};
        svgFile.encoding="UTF-8"; svgFile.write(content); svgFile.close();
        return {ok:true, message:"Sanitized", fixes:fixes};
    } catch(e) { try{svgFile.close();}catch(_e){} return {ok:false, message:String(e), fixes:0}; }
}

//  SECTION 16  â€“  STRIP AND EXPORT
// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

function stripAndExport() {
    var saved = [];
    try {
        if (app.documents.length === 0) return "ERROR:\nNo document open.";
        var doc    = app.activeDocument;
        var folder = Folder.selectDialog("Choose export folder");
        if (!folder) return "Export cancelled.";

        var base = doc.name
            .replace(/\.ai$/i,  "")
            .replace(/\.svg$/i, "")
            .replace(/(_svg)?_SOP(_svg_SOP)*/i, "")
            .replace(/[^a-zA-Z0-9_-]/g, "_");

        var svgPath = folder.fsName + "/" + base + "_SOP.svg";
        var svgFile = new File(svgPath);

        collectNumericGroups(doc, saved);
        var opts = safeSOPExportOpts();
        safeExportSVG(doc, svgFile, opts);
        var strip     = stripAI2026Suffixes(svgFile);
        var guard     = sanitizeSOPSVG(svgFile);
        if (!guard.ok) return "EXPORT BLOCKED BY SOP GUARD:\n" + guard.message + "\n\nFix the source artwork, then export again.";
        var freshFile = new File(svgPath);
        var sizeKB    = freshFile.length / 1024;

        if (sizeKB <= 0) {
            return "CRITICAL ERROR:\nExported SVG is 0 bytes â€” file write failed!\n" +
                   "Path: " + svgPath + "\n\n" +
                   "Causes:\n" +
                   "  \u2022 Destination folder is read-only\n" +
                   "  \u2022 File is locked in another app\n" +
                   "  \u2022 Illustrator SVG export silently failed\n\n" +
                   "Fix: choose a different export folder.";
        }

        var msg = "Exported:\n" + svgPath + "\nSize: " + sizeKB.toFixed(1) + " KB";
        if      (strip > 0)  msg += "\n\u2705 AI suffix fix: " + strip + " pattern(s) cleaned";
        else if (strip === 0) msg += "\n\u2705 No AI suffix corruption";
        else                  msg += "\n\u26A0 Could not post-process â€“ check folder permissions";
        if (guard && guard.fixes) msg += "\n\u2705 SOP Guard: " + guard.fixes + " sanitization pass(es)";
        if (sizeKB > 5000) msg += "\n\nCRITICAL: > 5 MB â€“ Constructor will reject!";
        else if (sizeKB > 500) msg += "\n\n\u26A0 > 500 KB â€“ stray objects likely remain";

        if (svgFile.open("r")) {
            var head = svgFile.read(8192); svgFile.close();
            if (head && /_x[0-9a-fA-F]{2}_/.test(head))
                msg += "\n\u26A0 _xNN_ escaped IDs remain";
            if (head && /<(clipPath|mask|symbol|image|use|filter|circle|ellipse|polygon)/.test(head))
                msg += "\n\u26A0 Forbidden element(s) in output";
        }
        if (saved.length > 0) msg += "\n" + saved.length + " numeric group(s) restored.";
        msg += "\n\nReminder: 'Rename IDs on Export' must be DISABLED.";
        return msg;
    } catch (e) {
        return "stripAndExport error:\n" + e + "\n(line " + (e.line || "?") + ")";
    } finally { restoreNumericGroups(saved); }
}


// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
//  SECTION 17  â€“  PLATINUMLIST QUICK SAVE
// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

function platinumlistSave() {
    var saved = [];
    try {
        if (app.documents.length === 0) return "ERROR:\nNo document open.";
        var doc = app.activeDocument;

        var docFile   = doc.fullName;
        var docFolder = docFile.parent;
        if (!docFolder || !docFolder.exists) {
            docFolder = Folder.selectDialog("Document not saved yet â€“ choose folder:");
            if (!docFolder) return "Save cancelled.";
        }

        // If the open document IS an SVG (not a .ai file), Illustrator cannot
        // write back to the same path â€” the file is locked while open.
        // Tell the user to save as .ai first.
        if (/\.svg$/i.test(doc.name)) {
            return "ERROR:\nYou are editing an SVG file directly.\n\n" +
                   "Illustrator locks the source SVG while it is open, so\n" +
                   "Yousuf Weiji Save cannot overwrite it.\n\n" +
                   "Fix:\n" +
                   "  1. File \u2192 Save As\u2026 \u2192 save as .ai in any folder\n" +
                   "  2. Then run Yousuf Weiji Save again.\n\n" +
                   "The .ai file will be your working source; the _SOP.svg\n" +
                   "export will be a clean separate file.";
        }

        // Strip .ai/.svg extension, then strip any chained _SOP/_svg_SOP tails
        // from previous saves so we never get 2026_svg_SOP_svg_SOP.svg etc.
        var base = doc.name
            .replace(/\.ai$/i,  "")
            .replace(/\.svg$/i, "")
            .replace(/(_svg)?_SOP(_svg_SOP)*/i, "")
            .replace(/[^a-zA-Z0-9_-]/g, "_");

        var svgPath = docFolder.fsName + "/" + base + "_SOP.svg";
        var svgFile = new File(svgPath);

        collectNumericGroups(doc, saved);
        var opts = safeSOPExportOpts();
        safeExportSVG(doc, svgFile, opts);
        var strip = stripAI2026Suffixes(svgFile);
        var guard = sanitizeSOPSVG(svgFile);
        if (!guard.ok) return "SAVE BLOCKED BY SOP GUARD:\n" + guard.message + "\n\nNo unsafe SVG was approved for upload.";

        // Use a FRESH File reference â€” the original object caches a stale length
        // of 0 after stripAI2026Suffixes rewrites it (shows as "-0.0 KB").
        var freshFile = new File(svgPath);
        var sizeKB = freshFile.length / 1024;

        // Guard: 0-byte output means the Illustrator export silently failed.
        if (sizeKB <= 0) {
            return "CRITICAL ERROR:\nExported SVG is 0 bytes â€” file write failed!\n" +
                   "Path: " + svgPath + "\n\n" +
                   "Causes:\n" +
                   "  \u2022 Destination folder is read-only\n" +
                   "  \u2022 File is locked in another app\n" +
                   "  \u2022 Illustrator SVG export silently failed\n\n" +
                   "Fix: File \u2192 Save As to a different folder, then run Yousuf Weiji Save again.";
        }

        var lines = [
            "\u2705 YOUSUF WEIJI SAVE COMPLETE",
            "File: " + svgPath,
            "Size: " + sizeKB.toFixed(1) + " KB",
            "",
            "Settings locked:",
            "  Encoding        : UTF-8",
            "  Font Subsetting : None",
            "  Decimal Places  : 2",
            "  Responsive      : OFF",
            "  CSS Properties  : Presentation",
            "  Embed Raster    : OFF"
        ];
        if      (strip > 0)  lines.push("\n\u2705 AI suffix fix: " + strip + " suffix(es) cleaned");
        else if (strip === 0) lines.push("\n\u2705 AI suffix: no corruption found");
        else                  lines.push("\n\u26A0 AI suffix post-process failed");
        if (guard && guard.fixes) lines.push("\u2705 SOP Guard: " + guard.fixes + " sanitization pass(es)");
        if (sizeKB > 5000) lines.push("\nCRITICAL: > 5 MB â€“ Constructor will reject!");
        else if (sizeKB > 500) lines.push("\n\u26A0 > 500 KB â€“ delete stray objects");

        if (svgFile.open("r")) {
            var head = svgFile.read(8192); svgFile.close();
            if (head && /_x[0-9a-fA-F]{2}_/.test(head))
                lines.push("\u26A0 _xNN_ escaped IDs â€“ rename digit-starting groups");
            if (head && /<(clipPath|mask|symbol|image|use|filter|circle|ellipse|polygon)/.test(head))
                lines.push("\u26A0 Forbidden element(s) found");
            if (head && head.indexOf('encoding="UTF-8"') !== -1)
                lines.push("\u2705 UTF-8 confirmed in SVG header");
            // Post-strip verification: SECTION1 / SEAT1 / SECTIONDECORATION1 patterns
            // mean stripAI2026Suffixes ran but failed to write, or file is being
            // read before the write completed.
            if (head && /id="(SECTION|SEAT|SECTIONDECORATION|DECORATION|STAGE)\d+"/i.test(head)) {
                lines.push("\u274C CRITICAL: Numbered sublayer IDs still present after strip!");
                lines.push("   Run Fix Tab \u2192 Fix Everything, then save again.");
                lines.push("   If this persists, the SVG file may be write-locked.");
            }
        }
        if (saved.length > 0) lines.push(saved.length + " numeric group(s) restored.");
        return lines.join("\n");

    } catch (e) {
        if (String(e).indexOf("fullName") !== -1)
            return "ERROR:\nSave the .ai file first (File \u2192 Save), then run Yousuf Weiji Save.";
        return "platinumlistSave error:\n" + e + "\n(line " + (e.line || "?") + ")";
    } finally { restoreNumericGroups(saved); }
}


// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
//  SECTION 18  â€“  QUICK SEAT COUNT
// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

// quickSeatCount — lightweight badge refresh (CEP header).
// Returns plain integer string or "" if no document open. Must stay fast.
function quickSeatCount() {
    try {
        if (app.documents.length === 0) return "";
        var seats = [];
        collectSeats(app.activeDocument, seats);
        return String(seats.length);
    } catch (e) { return ""; }
}


// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
//  SECTION 19  â€“  DETAILED SEAT COUNT
// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
// detailedSeatCount — zone-by-zone breakdown for the Validate tab.
function detailedSeatCount() {
    try {
        if (app.documents.length === 0) return "ERROR:\nNo document open.";
        var doc   = app.activeDocument;
        var seats = [];
        collectSeats(doc, seats);
        var total = seats.length;
        var byGroup = {};
        for (var i = 0; i < seats.length; i++) {
            var parts = seats[i].name.split("-");
            var grp   = (parts.length >= 2) ? parts[1] : "UNKNOWN";
            byGroup[grp] = (byGroup[grp] || 0) + 1;
        }
        var lines = ["Seat count by group  |  Total: " + total, ""];
        var groups = [];
        for (var g in byGroup) { if (byGroup.hasOwnProperty(g)) groups.push(g); }
        groups.sort();
        for (var j = 0; j < groups.length; j++) {
            lines.push("  " + groups[j] + "  :  " + byGroup[groups[j]]);
        }
        lines.push("\n\u2705 Total: " + total + " seat(s) across " + groups.length + " group(s).");
        return lines.join("\n");
    } catch (e) {
        return "detailedSeatCount error:\n" + e + "\n(line " + (e.line || "?") + ")";
    }
}



// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
//  SECTION 20  â€“  FIX ALL
// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

// (Use fixAllSOPFull — the legacy single-pass fixAllSOP was retired.)


// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
//  SECTION 20b  â€“  FIX SUBLAYER NAMES
//
//  Renames any sublayer that:
//   (a) has an _n_ numeric suffix  e.g. SECTION, SEAT
//   (b) is a leftover temp name    e.g. __SEC__Z0__, __STAGE__
//  to the correct SOP April 2026 name (no suffix).
//
//  Correct SOP sublayer names:
//    SECTION, UNDERSEATDECORATION, SEAT,
//    SEATDECORATION, SECTIONDECORATION,
//    STAGE, DECORATION, SEATLABELS
// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

function fixSubLayerNames() {
    try {
        if (app.documents.length === 0) return "ERROR:\nNo document open.";
        var doc = app.activeDocument;
        var fixed = 0;

        // Map: bad name pattern â†’ correct SOP name
        // Patterns checked in order; first match wins.
        var REMAP = [
            // Bare trailing digits â€” Illustrator auto-appends when names clash
            // e.g. SECTION67, SEAT65, SECTIONDECORATION64  â†’  clean SOP name
            // Must be listed longest-first so SECTIONDECORATION matches before SECTION
            { test: /^SECTIONDECORATION\d+$/i,   name: "SECTIONDECORATION" },
            { test: /^UNDERSEATDECORATION\d+$/i, name: "UNDERSEATDECORATION" },
            { test: /^SEATDECORATION\d+$/i,      name: "SEATDECORATION" },
            { test: /^SEATLABELS\d+$/i,          name: "SEATLABELS" },
            { test: /^DECORATION\d+$/i,          name: "DECORATION" },
            { test: /^SECTION\d+$/i,             name: "SECTION" },
            { test: /^SEAT\d+$/i,                name: "SEAT" },
            { test: /^STAGE\d+$/i,               name: "STAGE" },
            // _n_ suffix patterns (SECTION, SEAT, etc.)
            { test: /^SECTION_\d+_$/i,           name: "SECTION" },
            { test: /^UNDERSEATDECORATION_\d+_$/i,name: "UNDERSEATDECORATION" },
            { test: /^SEAT_\d+_$/i,              name: "SEAT" },
            { test: /^SEATDECORATION_\d+_$/i,    name: "SEATDECORATION" },
            { test: /^SECTIONDECORATION_\d+_$/i, name: "SECTIONDECORATION" },
            { test: /^SEATLABELS_\d+_$/i, name: "SEATLABELS" },
            // Leftover temp names from failed preBuildMap.
            // Match BOTH legacy (__SEC__Z0__) and session-ID form (__SEC_K8XYZ_0__).
            { test: /^__SEC(__Z|_[A-Z0-9]+_)\d+__$/i,  name: "SECTION" },
            { test: /^__UD(__Z|_[A-Z0-9]+_)\d+__$/i,   name: "UNDERSEATDECORATION" },
            { test: /^__SEAT(__Z|_[A-Z0-9]+_)\d+__$/i, name: "SEAT" },
            { test: /^__SDEC(__Z|_[A-Z0-9]+_)\d+__$/i, name: "SEATDECORATION" },
            { test: /^__SD(__Z|_[A-Z0-9]+_)\d+__$/i,   name: "SECTIONDECORATION" },
            { test: /^__STAGE(_[A-Z0-9]+_\d+)?__$/i,         name: "STAGE" },
            { test: /^__DECORATION(_[A-Z0-9]+_\d+)?__$/i,    name: "DECORATION" },
            { test: /^__SEATLABELS(_[A-Z0-9]+_\d+)?__$/i,    name: "SEATLABELS" }
        ];

        function renameItem(item) {
            if (!item) return;
            if (item.name) {
                for (var ri = 0; ri < REMAP.length; ri++) {
                    if (REMAP[ri].test.test(item.name)) {
                        item.name = REMAP[ri].name;
                        fixed++;
                        break;
                    }
                }
            }
            if (item.pageItems) {
                for (var i = 0; i < item.pageItems.length; i++)
                    renameItem(item.pageItems[i]);
            }
            if (item.layers) {
                for (var i = 0; i < item.layers.length; i++)
                    renameItem(item.layers[i]);
            }
        }
        renameItem(doc);

        if (fixed === 0) return "\u2705 All sublayer names are correct â€“ nothing to fix.";
        return "\u2705 Fixed " + fixed + " sublayer name(s).\n" +
               "Old _n_ suffixes and temp __ names renamed to SOP names.";
    } catch (e) { return "fixSubLayerNames error:\n" + e; }
}


// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
//  SECTION 21  â€“  RENAME GROUP PREFIX
// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

function renameGroupPrefix(oldPfx, newPfx) {
    try {
        if (!oldPfx || !newPfx)           return "ERROR:\nBoth old and new GROUP prefix required.";
        if (app.documents.length === 0)   return "ERROR:\nNo document open.";
        oldPfx = sopTrim(oldPfx).toUpperCase();
        newPfx = sopTrim(newPfx).toUpperCase();
        if (oldPfx.indexOf("-") !== -1 || newPfx.indexOf("-") !== -1)
            return "ERROR:\nGROUP prefix must not contain hyphens (SOP \u00a76.1).";

        var seats  = [];
        collectSeats(app.activeDocument, seats);
        var match  = "seatData-" + oldPfx + "-";
        var changed = 0, used = {};

        for (var i = 0; i < seats.length; i++) {
            if (seats[i].name.indexOf(match) !== 0) continue;
            var rest = seats[i].name.slice(match.length).split("-");
            var sn   = rest[0];
            var hash = makeHash(newPfx, parseInt(sn, 10), changed);
            var att  = 0;
            while (used[hash]) { att++; hash = makeHash(newPfx, parseInt(sn, 10), changed + att + 9999); }
            used[hash] = true;
            seats[i].name = "seatData-" + newPfx + "-" + sn + "-" + sn + "-1-" + hash;
            changed++;
        }
        if (changed === 0) return "No seats matched GROUP \"" + oldPfx + "\".";
        return "\u2705 Renamed " + changed + " seat ID(s): " + oldPfx + " \u2192 " + newPfx;
    } catch (e) { return "renameGroupPrefix error:\n" + e + "\n(line " + (e.line || "?") + ")"; }
}


// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
//  SECTION 22  â€“  RENUMBER SELECTED SEATS
// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

function renumberSelectedSeats() {
    try {
        if (app.documents.length === 0)    return "ERROR:\nNo document open.";
        var doc = app.activeDocument;
        if (!doc.selection || doc.selection.length === 0)
            return "ERROR:\nNothing selected â€“ select seat shapes first.";

        var seats = [];
        for (var i = 0; i < doc.selection.length; i++)
            if (isSeatElement(doc.selection[i])) seats.push(doc.selection[i]);
        if (seats.length === 0) return "ERROR:\nNo seatData-* elements in selection.";

        seats.sort(function (a, b) { return a.left - b.left; });
        var grp  = seats[0].name.split("-")[1] || "UNKNOWN";
        var used = {};

        for (var i = 0; i < seats.length; i++) {
            var sn   = i + 1;
            var hash = makeHash(grp, sn, i);
            var att  = 0;
            while (used[hash]) { att++; hash = makeHash(grp, sn, i + att * 10007); }
            used[hash]    = true;
            seats[i].name = "seatData-" + grp + "-" + sn + "-" + sn + "-1-" + hash;
        }
        return "\u2705 Renumbered " + seats.length + " seat(s) in GROUP \"" + grp + "\" (1\u2013" + seats.length + ")";
    } catch (e) { return "renumberSelectedSeats error:\n" + e + "\n(line " + (e.line || "?") + ")"; }
}


// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
//  SECTION 23  â€“  RESEQUENCE SEAT NUMBERS
// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

function resequenceSeatNumbers() {
    try {
        if (app.documents.length === 0) return "ERROR:\nNo document open.";
        var seats = [];
        collectSeats(app.activeDocument, seats);

        var buckets = {};
        for (var i = 0; i < seats.length; i++) {
            var p = seats[i].name.split("-");
            if (p.length < 6) continue;
            if (!buckets[p[1]]) buckets[p[1]] = [];
            buckets[p[1]].push(seats[i]);
        }

        var fixed = 0, used = {};
        for (var grp in buckets) {
            var arr = buckets[grp];
            arr.sort(function (a, b) { return a.left - b.left; });
            for (var j = 0; j < arr.length; j++) {
                var sn   = j + 1;
                var hash = makeHash(grp, sn, j);
                var att  = 0;
                while (used[hash]) { att++; hash = makeHash(grp, sn, j + att * 9999); }
                used[hash] = true;
                var nn = "seatData-" + grp + "-" + sn + "-" + sn + "-1-" + hash;
                if (arr[j].name !== nn) { arr[j].name = nn; fixed++; }
            }
        }
        var gc = 0; for (var k in buckets) gc++;
        return "\u2705 Re-sequence complete\n  Groups: " + gc + "\n  IDs updated: " + fixed;
    } catch (e) { return "resequenceSeatNumbers error:\n" + e + "\n(line " + (e.line || "?") + ")"; }
}


// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
//  SECTION 24  â€“  PREBUILD MAP  v3.3
//
//  SOP April 2026 (Final) sublayer names â€” NO _n_ suffix:
//    SECTION, UNDERSEATDECORATION, SEAT, SEATDECORATION, SECTIONDECORATION
//
//  Zone internal z-order (backâ†’front):
//    SECTION, UNDERSEATDECORATION, SEAT, SEATDECORATION, SECTIONDECORATION
//
//  Build strategy to avoid Illustrator auto-rename collision:
//    Use temp unique names (__SEC__Z0__, __SEAT__Z0__, etc.)
//    Populate content, then rename to SOP names at the very end.
//    UNDERSEATDECORATION and SEATDECORATION are empty â€” created with
//    temp names and renamed. Collision risk is low for empty groups
//    but we keep the pattern for consistency.
// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

function preBuildMap(paramsJSON) {
    var doc=null;
    try{
        var p=eval('('+paramsJSON+')'),plan=YWGeometry.map(p);
        // A fresh document avoids silently clearing artwork from an existing map.
        doc=app.documents.add(DocumentColorSpace.RGB,plan.width,plan.height);doc.rulerUnits=RulerUnits.Pixels;
        var layer=doc.layers[0];layer.name='HALL_MAP';var ab=doc.artboards[0].artboardRect,origin=[ab[0],ab[1]];
        function group(parent,name){var g=parent.groupItems.add();g.name=name;return g;}
        var stage=group(layer,'STAGE'),deco=group(layer,'DECORATION');
        ywBuildPath(stage,plan.stage.points,origin,makeColorSafe(224,224,224),makeColorSafe(204,204,204)).name='stage_shape';
        var st=plan.stage.label;var title=ywBuildLabel(deco,'STAGE',origin[0]+st.x,origin[1]-st.y,24,false);title.name='stage_label';
        var colors=[[143,199,255],[143,230,178],[204,158,255],[255,194,112],[255,148,148],[112,220,220]],used={};
        for(var z=0;z<plan.zones.length;z++){
            var data=plan.zones[z],zone=group(layer,'ZONE_'+data.name),sec=group(zone,'SECTION');
            var background=ywBuildPath(sec,data.section,origin,makeColorSafe(241,241,241),makeColorSafe(209,210,212));background.name='section_path';
            var under=group(zone,'UNDERSEATDECORATION'),seats=group(zone,'SEAT'),seatDecor=group(zone,'SEATDECORATION'),overlay=group(zone,'SECTIONDECORATION');
            if(data.table){var tb=data.table;var tablePts=YWGeometry.transform(YWGeometry.stage('circle',tb.r*2,tb.r*2,0),tb.x-tb.r,tb.y-tb.r,0);ywBuildPath(under,tablePts,origin,makeColorSafe(245,245,245),makeColorSafe(209,210,212)).name='table';}
            var color=colors[z%colors.length];
            for(var i=0;i<data.seats.length;i++){
                var s=data.seats[i],row=s.row<26?String.fromCharCode(65+s.row):'R'+(s.row+1),groupId=data.name+row;
                var hash=makeHash(groupId,s.number,z*100000+i),salt=0;while(used[hash]){salt++;hash=makeHash(groupId,s.number,z*100000+i+salt*999983);}used[hash]=true;
                var seat=seats.pathItems.roundedRectangle(origin[1]-s.y,origin[0]+s.x,7,7,1.5,1.5);
                seat.name='seatData-'+groupId+'-'+s.number+'-'+s.number+'-1-'+hash;seat.filled=true;seat.fillColor=makeColorSafe(color[0],color[1],color[2]);seat.stroked=false;
            }
            // A direct duplicate guarantees identical path anchors and geometry.
            var outline=background.duplicate(overlay,ElementPlacement.PLACEATBEGINNING);outline.name='section_overlay';
            outline.filled=plan.overlayFill==='white';if(outline.filled)outline.fillColor=makeColorSafe(255,255,255);
            outline.stroked=true;outline.strokeColor=makeColorSafe(209,210,212);outline.strokeWidth=1;
            ywBuildLabel(overlay,data.name,origin[0]+data.label.x,origin[1]-data.label.y,data.label.size,true);
            sec.zOrder(ZOrderMethod.SENDTOBACK);overlay.zOrder(ZOrderMethod.BRINGTOFRONT);
        }
        group(layer,'SEATLABELS');stage.zOrder(ZOrderMethod.SENDTOBACK);
        try{app.executeMenuCommand('fitall');}catch(ignore){}app.redraw();
        return 'PreBuild complete — '+plan.type+'\n'+plan.zones.length+' zones / '+plan.totalSeats+' seats\nSECTIONDECORATION matches each SECTION path. Zone names are above the upper edge.\nCreated a new document; existing documents are unchanged.\nDecoration style: '+plan.overlayFill+'.';
    }catch(e){return 'ERROR: PreBuild: '+e+' (line '+(e.line||'?')+')'+(doc?'\nA partially built new document remains open for inspection.':'');}
}

// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
//  SECTION 25  â€“  CONVERT SHAPES TO SOP SEATS  (Â§5.4 / Â§5.5)
//
//  Converts selected shapes to SOP-compliant 7Ã—7px roundedRect
//  seats, placed at each shape's centroid. Assigns temp IDs.
//  User can then run Generate Seat IDs to assign final IDs.
// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

function replaceWithSOPSeats() {
    try {
        if (app.documents.length === 0) return "ERROR:\nNo document open.";
        var doc = app.activeDocument;
        var sel = doc.selection;
        if (!sel || sel.length === 0)
            return "ERROR:\nSelect shapes to convert first.";

        // SOP Â§7: seat fill colour â€” use decorStroke (#D1D2D4) as neutral default
        var sCol = makeColor(SOP_COLORS.seatDefault);   // #CCCCCC SOP seat default
        var count = 0;
        var usedH = {};

        // Collect first so we can iterate without mutating live selection
        var itemsToConvert = [];
        for (var i = 0; i < sel.length; i++) {
            itemsToConvert.push(sel[i]);
        }

        // Try to find SEAT group to place seats in
        var targetParent = null;
        var seatGrp = findGroupByName(doc, "SEAT") || findGroupByName(doc, "SEAT");
        if (seatGrp) targetParent = seatGrp;

        for (var j = 0; j < itemsToConvert.length; j++) {
            var item = itemsToConvert[j];
            try {
                var b  = item.geometricBounds; // [left, top, right, bottom] AI coords
                var cx = (b[0] + b[2]) / 2;
                var cy = (b[1] + b[3]) / 2;    // already in AI doc coords (Y up)
                // parent for new seat: SEAT group if found, else same parent as item
                var par = targetParent || item.parent;
                // roundedRectangle(top, left, width, height, hRadius, vRadius)
                // In AI coords: top = cy + 3.5 (seat is 7px tall, centre + half)
                var r = par.pathItems.roundedRectangle(cy + 3.5, cx - 3.5, 7, 7, 1.5, 1.5);
                r.filled    = true;
                r.fillColor = sCol;
                r.stroked   = false;
                // Assign temp ID â€” user will run Generate Seat IDs to assign final
                var hash = makeHash("TMP", count, count);
                while (usedH[hash]) { count++; hash = makeHash("TMP", count, count); }
                usedH[hash] = true;
                r.name = "seatData-TMP-" + (j + 1) + "-" + (j + 1) + "-1-" + hash;
                item.remove();
                count++;
            } catch (ie) { /* skip items that can't be converted */ }
        }

        if (count === 0) return "ERROR:\nNo shapes could be converted.\nSelect valid shape objects.";

        var msg = "\u2705 Converted " + count + " shape(s) to 7\u00d77px SOP seats.\n\n";
        if (targetParent) {
            msg += "Placed in: SEAT group\n";
        } else {
            msg += "Note: No SEAT group found â€” seats placed in original parent.\n" +
                   "Run Build SOP Hierarchy first, then move seats into SEAT group.\n";
        }
        msg += "\nTemp IDs assigned (seatData-TMP-N-N-1-hash).\n" +
               "Next: select seats \u2192 Generate Seat IDs with correct GROUP prefix.";
        return msg;
    } catch (e) { return "replaceWithSOPSeats error:\n" + e + "\n(line " + (e.line || "?") + ")"; }
}


// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
//  SECTION 28  â€“  ARENA AUTO-NUMBER + SCALE RULE + CATEGORY MAP
//  (April 2026 Final  â€” merged from v4.5)
// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•



// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
//  NEW SECTION â€” ARENA AUTOMATION + SCALE RULE + CATEGORY MAP
//  Added from v4.5 | April 2026 (Final)
// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•


// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
// ARENA AUTO-NUMBERING (Â§8.3 & Â§8.5)
// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
function autoNumberArena(prefix) {
    try {
        if (app.documents.length === 0) return "ERROR:\nNo document open.";
        var doc = app.activeDocument;
        var sel = doc.selection;
        if (!sel || sel.length === 0) return "ERROR:\nSelect seats first.";
        
        var seats =[];
        for (var i=0; i<sel.length; i++) {
            if (sel[i].typename==="PathItem" || sel[i].typename==="Rectangle") seats.push(sel[i]);
        }
        if (seats.length === 0) return "ERROR:\nNo seats in selection.";
        
        var centers =[];
        var sMinX=99999, sMaxX=-99999, sMinY=99999, sMaxY=-99999;
        for (var j=0; j<seats.length; j++) {
            var b = seats[j].geometricBounds;
            var cx = (b[0]+b[2])/2; var cy = (b[1]+b[3])/2;
            centers.push({seat: seats[j], x: cx, y: cy});
            if (cx<sMinX) sMinX=cx; if (cx>sMaxX) sMaxX=cx;
            if (cy<sMinY) sMinY=cy; if (cy>sMaxY) sMaxY=cy;
        }
        var secCX = (sMinX+sMaxX)/2; var secCY = (sMinY+sMaxY)/2;
        
        var ab = doc.artboards[0].artboardRect;
        var arenaCX = (ab[0]+ab[2])/2; var arenaCY = (ab[1]+ab[3])/2;
        
        centers.sort(function(a,b){ return b.y - a.y; }); // Top to Bottom
        var rows = [], currentRow =[], lastY = centers[0].y;
        for (var k=0; k<centers.length; k++) {
            if (Math.abs(centers[k].y - lastY) > 8) {
                rows.push(currentRow); currentRow = []; lastY = centers[k].y;
            }
            currentRow.push(centers[k]);
        }
        if (currentRow.length > 0) rows.push(currentRow);
        
        // SOP 8.3: Furthest from stage = Row A. Assume stage at bottom.
        var isTopSection = (secCY > arenaCY);
        if (isTopSection) { rows.sort(function(a,b){ return b[0].y - a[0].y; }); } 
        else { rows.sort(function(a,b){ return a[0].y - b[0].y; }); }
        
        // SOP 8.5: Left section -> L to R. Right section -> R to L.
        var isStageRight = (secCX > arenaCX);
        var changed = 0; var ROW_ABC = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        
        for (var r=0; r<rows.length; r++) {
            var rowLtr = (r < 26) ? ROW_ABC.charAt(r) : ("R" + (r+1));
            var grp = prefix + rowLtr;
            var rowSeats = rows[r];
            
            rowSeats.sort(function(a,b){ return isStageRight ? (b.x - a.x) : (a.x - b.x); });
            
            for (var s=0; s<rowSeats.length; s++) {
                var sn = s+1;
                var hash = makeHash(grp, sn, changed);
                rowSeats[s].seat.name = "seatData-" + grp + "-" + sn + "-" + sn + "-1-" + hash;
                changed++;
            }
        }
        return "\u2705 Arena Auto-Numbered: " + changed + " seats.\nPosition: " + (isTopSection?"TOP":"BOTTOM") + " / " + (isStageRight?"RIGHT":"LEFT");
    } catch(e) { return "ERROR:\n" + e; }
}



// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
// SCALE RULE (Â§5.4)
// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
function applyScaleRule(sourceWidthStr) {
    try {
        var doc = app.activeDocument;
        var sel = doc.selection;
        if (!sel || sel.length === 0) return "ERROR:\nSelect items to scale.";
        var sw = parseFloat(sourceWidthStr);
        if (isNaN(sw) || sw <= 0) return "ERROR:\nInvalid source width.";
        
        var scale = 7.0 / sw;
        var scalePct = scale * 100.0;
        
        for(var i=0; i<sel.length; i++) {
            sel[i].resize(scalePct, scalePct, true, true, true, true, scalePct, Transformation.CENTER);
        }
        return "\u2705 Scaled " + sel.length + " items by " + scalePct.toFixed(2) + "%\n(Scale factor: " + scale.toFixed(2) + "x).";
    } catch(e) { return "ERROR:\n" + e; }
}



// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
// GENERATE CATEGORY MAP (Guidelines)
// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
function generateCategoryMap(dataStr) {
    try {
        if (!dataStr) return "ERROR:\nEnter category names comma separated.";
        var doc = app.documents.add(DocumentColorSpace.RGB, 1150, 950);
        doc.rulerUnits = RulerUnits.Pixels;
        var cats = dataStr.split(",");
        var cols = 3;
        if (cats.length > 9) cols = 4;
        if (cats.length <= 4) cols = 2;
        var rows = Math.ceil(cats.length / cols);
        var boxW = 250; var boxH = 60;
        var gapX = 30; var gapY = 30;
        var totalW = (cols * boxW) + ((cols - 1) * gapX);
        var startX = (1150 - totalW) / 2;
        var startY = 950 - 150;
        
        var cWhite = new RGBColor(); cWhite.red=255; cWhite.green=255; cWhite.blue=255;
        var cStroke = new RGBColor(); cStroke.red=209; cStroke.green=210; cStroke.blue=212; // d1d2d4
        var cText = new RGBColor(); cText.red=109; cText.green=110; cText.blue=112; // #6d6e70 (CSS-confirmed, was #808284)
        
        for(var i=0; i<cats.length; i++) {
            var c = i % cols;
            var r = Math.floor(i / cols);
            var x = startX + (c * (boxW + gapX));
            var y = startY - (r * (boxH + gapY));
            
            var rect = doc.pathItems.roundedRectangle(y, x, boxW, boxH, 3, 3);
            rect.filled = true; rect.fillColor = cWhite;
            rect.stroked = true; rect.strokeColor = cStroke; rect.strokeWidth = 1;
            
            var tf = doc.textFrames.add();
            tf.contents = sopTrim(cats[i]).toUpperCase();
            var attr = tf.textRange.characterAttributes;
            attr.size = 18;
            attr.fillColor = cText;
            try { attr.textFont = app.textFonts.getByName("ProximaNova-Regular"); } catch(e) {
                try { attr.textFont = app.textFonts.getByName("ArialMT"); } catch(e2){}
            }
            tf.top = y - (boxH/2) + 6;
            tf.left = x + (boxW/2) - (tf.width/2);
        }
        
        var sw = 600, sh = 80;
        var sx = (1150 - sw)/2;
        var sy = 120;
        var sRect = doc.pathItems.roundedRectangle(sy, sx, sw, sh, 10, 10);
        sRect.filled = true; sRect.fillColor = new RGBColor(); sRect.fillColor.red=241; sRect.fillColor.green=241; sRect.fillColor.blue=241;
        sRect.stroked = true; sRect.strokeColor = cStroke; sRect.strokeWidth = 1;
        
        var stf = doc.textFrames.add();
        stf.contents = "STAGE";
        stf.textRange.characterAttributes.size = 24;
        stf.textRange.characterAttributes.fillColor = cText;
        stf.top = sy - (sh/2) + 8;
        stf.left = sx + (sw/2) - (stf.width/2);
        
        return "\u2705 Category Map Generated Successfully! Fits 1150x950px.";
    } catch(e) { return "ERROR:\n" + e; }
}


// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
//  SECTION 29  â€“  FIX EXISTING SVG FILE  (post-export repair)
//
//  Use when you exported via File â†’ Export â†’ Export As (bypassing
//  platinumlistSave) and the SVG on disk still has SECTION1 etc.
//  Opens a file picker, strips all numbered IDs, overwrites in place.
// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

function fixSVGFile() {
    try {
        var f = File.openDialog("Select the SVG to repair", "SVG Files:*.svg,All Files:*");
        if (!f) return "Cancelled.";

        if (!f.open("r")) return "ERROR:\nCannot read file:\n" + f.fsName;
        f.encoding = "UTF-8";
        var content = f.read();
        f.close();
        if (!content) return "ERROR:\nFile is empty or unreadable.";

        var original = content;

        var rules = [
            [/id="SECTIONDECORATION[0-9]+"/g,           'id="SECTIONDECORATION"'],
            [/id="UNDERSEATDECORATION[0-9]+"/g,          'id="UNDERSEATDECORATION"'],
            [/id="SEATDECORATION[0-9]+"/g,               'id="SEATDECORATION"'],
            [/id="SEATLABELS[0-9]+"/g,                   'id="SEATLABELS"'],
            [/id="DECORATION[0-9]+"/g,                   'id="DECORATION"'],
            [/id="SECTION[0-9]+"/g,                      'id="SECTION"'],
            [/id="SEAT[0-9]+"/g,                         'id="SEAT"'],
            [/id="STAGE[0-9]+"/g,                        'id="STAGE"'],
            [/id="SECTION_[0-9]+_"/g,                    'id="SECTION"'],
            [/id="SEAT_[0-9]+_"/g,                       'id="SEAT"'],
            [/id="SECTIONDECORATION_[0-9]+_"/g,          'id="SECTIONDECORATION"'],
            [/id="SEATDECORATION_[0-9]+_"/g,             'id="SEATDECORATION"'],
            [/id="UNDERSEATDECORATION_[0-9]+_"/g,        'id="UNDERSEATDECORATION"']
        ];

        var fixCount = 0;
        for (var ri = 0; ri < rules.length; ri++) {
            var after = content.replace(rules[ri][0], rules[ri][1]);
            if (after !== content) { fixCount++; content = after; }
        }

        // Inject direction="up" if missing
        if (content.indexOf('id="STAGE"') !== -1 && content.indexOf('direction=') === -1) {
            var dc = content.replace(/(id="STAGE"[\s\S]{0,300}?)(<(?:rect|path)\b)/, '$1$2 direction="up"');
            if (dc !== content) { content = dc; fixCount++; }
        }

        if (content === original) {
            return "\u2705 No issues found â€” all sublayer IDs already clean:\n" + f.fsName;
        }

        if (!f.open("w")) return "ERROR:\nCannot write file â€” close it in any other app:\n" + f.fsName;
        f.encoding = "UTF-8";
        f.write(content);
        f.close();

        // Verify: scan for any remaining numbered IDs
        var remain = [];
        var checkRe = /id="(SECTION|SEAT|SECTIONDECORATION|SEATDECORATION|DECORATION|STAGE|SEATLABELS)\d+"/ig;
        var m;
        while ((m = checkRe.exec(content)) !== null) remain.push(m[0]);

        var msg = "\u2705 SVG repaired:\n" + f.fsName +
                  "\nRule passes applied: " + fixCount +
                  "\nFile size: " + (f.length / 1024).toFixed(1) + " KB";

        if (remain.length > 0) {
            msg += "\n\n\u274C STILL BROKEN â€” " + remain.length + " numbered ID(s) remain:\n" +
                   remain.slice(0, 8).join("\n") +
                   (remain.length > 8 ? "\n...+" + (remain.length - 8) + " more" : "") +
                   "\n\nDuplicate group names inside same parent zone." +
                   "\nFix: Run Fix Everything in Fix tab, then re-export with Yousuf Weiji Save.";
        } else {
            msg += "\n\n\u2705 Verification PASSED â€” zero numbered IDs remain." +
                   "\nSafe to upload to Hall Map Constructor.";
        }
        return msg;

    } catch (e) { return "fixSVGFile error:\n" + e + "\n(line " + (e.line || "?") + ")"; }
}


// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
//  SECTION 30  â€“  FIX SEAT SIZES
//  Resizes every seat element to exactly 7Ã—7 px, preserving
//  centre position.  Fixes checklist #10.
// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

function fixSeatSizes() {
    try {
        if (app.documents.length === 0) return "ERROR:\nNo document open.";
        var doc = app.activeDocument;
        var seats = [];
        collectSeats(doc, seats);
        if (seats.length === 0) return "ERROR:\nNo seatData-* elements found.";

        var fixed = 0;
        for (var i = 0; i < seats.length; i++) {
            var s = seats[i];
            try {
                var b = s.geometricBounds; // [left, top, right, bottom]
                var cx = (b[0] + b[2]) / 2;
                var cy = (b[1] + b[3]) / 2;
                var needsFix = (Math.abs(s.width - 7) > 0.25 || Math.abs(s.height - 7) > 0.25);
                if (needsFix) {
                    // Resize to 7Ã—7 from centre
                    s.width  = 7;
                    s.height = 7;
                    // Recentre â€” geometricBounds is [left, top, right, bottom] in AI coords
                    // After resize AI may have shifted position; reposition by centre
                    var b2 = s.geometricBounds;
                    var dx = cx - (b2[0] + b2[2]) / 2;
                    var dy = cy - (b2[1] + b2[3]) / 2;
                    s.translate(dx, dy);
                    // Set rx/ry via appearance if it's a path (can't set rx on PathItem directly)
                    fixed++;
                }
            } catch (se) { /* skip items that can't be resized */ }
        }
        if (fixed === 0)
            return "\u2705 All " + seats.length + " seats already 7\u00d77 px â€” nothing to fix.";
        return "\u2705 Resized " + fixed + " of " + seats.length + " seat(s) to 7\u00d77 px.\n" +
               "Note: Path seats retain their path shape but bounding box is now 7\u00d77.\n" +
               "Re-run checklist to verify #10.";
    } catch (e) { return "fixSeatSizes error:\n" + e + "\n(line " + (e.line || "?") + ")"; }
}


// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
//  SECTION 31  â€“  FIX SECTIONDECORATION NESTING
//  Flattens nested GroupItems inside every SECTIONDECORATION
//  group by moving their children up one level.
//  Fixes checklist #17.
// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

function fixSectionDecorationNesting() {
    // âš  MANUAL USE ONLY â€” NOT called by Fix All.
    // Flattens nested GroupItems inside SECTIONDECORATION.
    // SAFE ONLY when the groups contain plain paths (badge shapes).
    // SKIPS any nested group that contains a TextFrame â€” ungrouping
    // text in Illustrator can shift positions and lose SVG export visibility.
    try {
        if (app.documents.length === 0) return "ERROR:\nNo document open.";
        var doc = app.activeDocument;
        var sdecs = [];
        findGroupsByExactName(doc, "SECTIONDECORATION", sdecs);
        if (sdecs.length === 0)
            return "\u2705 No SECTIONDECORATION groups found â€” nothing to fix.";

        var flattened = 0, skipped = 0;
        for (var i = 0; i < sdecs.length; i++) {
            var sd = sdecs[i];
            var again = true;
            while (again) {
                again = false;
                if (!sd.pageItems) break;
                for (var j = sd.pageItems.length - 1; j >= 0; j--) {
                    var child = sd.pageItems[j];
                    if (child.typename !== "GroupItem") continue;
                    // SAFETY: skip groups that contain text â€” ungrouping can break label positions
                    var hasText = false;
                    if (child.pageItems) {
                        for (var t = 0; t < child.pageItems.length; t++) {
                            if (child.pageItems[t].typename === "TextFrame") {
                                hasText = true; break;
                            }
                        }
                    }
                    if (hasText) { skipped++; continue; }
                    // Safe to flatten â€” pure shape group
                    for (var k = child.pageItems.length - 1; k >= 0; k--) {
                        child.pageItems[k].move(sd, ElementPlacement.PLACEATBEGINNING);
                    }
                    try { child.remove(); } catch(re) {}
                    flattened++;
                    again = true;
                    break;
                }
            }
        }
        var msg = "";
        if (flattened === 0 && skipped === 0)
            return "\u2705 No nested groups in SECTIONDECORATION â€” already clean.";
        if (flattened > 0)
            msg += "\u2705 Flattened " + flattened + " shape group(s).\n";
        if (skipped > 0)
            msg += "\u26A0 Skipped " + skipped + " group(s) containing text â€” " +
                   "these must be ungrouped manually in Illustrator\n" +
                   "  (Object \u2192 Ungroup) to avoid label text position loss.\n";
        return msg + "Re-run checklist to verify #17.";
    } catch (e) {
        return "fixSectionDecorationNesting error:\n" + e + "\n(line " + (e.line || "?") + ")";
    }
}


// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
//  SECTION 32  â€“  AUTO-FIX SEAT IDs
//
//  Walks every zone in the document, finds its SEAT sublayer,
//  sorts seats by row (Y) then column (X), assigns row letters
//  A, B, Câ€¦ and seat numbers 1, 2, 3â€¦ then writes proper
//  seatData-{ZONE}{ROW}-{N}-{N}-1-{HASH} IDs.
//
//  Fixes checklist #02 #04 #05 #07 all at once.
//
//  Zone group names recognised:
//    ZONE_* prefix  (SOP standard)
//    Any direct child group of Layer 1 whose name does NOT
//    match a reserved name (STAGE, DECORATION, SEATLABELS)
// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

function autoFixSeatIDs() {
    try {
        if (app.documents.length === 0) return "ERROR:\nNo document open.";
        var doc = app.activeDocument;

        var RESERVED = { "STAGE":1, "DECORATION":1, "SEATLABELS":1 };
        var ROW_ABC = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        var ROW_TOLERANCE = 8; // px â€” seats within this Y range = same row

        // Collect zone groups
        var zoneGroups = [];
        var layer = doc.layers[0];
        if (layer.pageItems) {
            for (var i = 0; i < layer.pageItems.length; i++) {
                var g = layer.pageItems[i];
                if (g.typename !== "GroupItem") continue;
                if (RESERVED[g.name]) continue;
                zoneGroups.push(g);
            }
        }
        // Also catch ZONE_ prefix groups at root
        collectGroupsByPrefix(doc, "ZONE_", zoneGroups);
        // Deduplicate by reference
        var seen = [];
        var uniq = [];
        for (var i = 0; i < zoneGroups.length; i++) {
            var found = false;
            for (var k = 0; k < seen.length; k++) {
                if (seen[k] === zoneGroups[i]) { found = true; break; }
            }
            if (!found) { seen.push(zoneGroups[i]); uniq.push(zoneGroups[i]); }
        }
        zoneGroups = uniq;

        if (zoneGroups.length === 0)
            return "ERROR:\nNo zone groups found.\nExpected groups named ZONE_X or zone-level groups\nunder Layer 1.";

        var globalUsedHashes = {};
        var totalFixed = 0;
        var report = [];

        for (var z = 0; z < zoneGroups.length; z++) {
            var zone = zoneGroups[z];
            // Derive zone name: strip ZONE_ prefix if present
            var zoneName = zone.name;
            if (zoneName.indexOf("ZONE_") === 0) zoneName = zoneName.substring(5);
            zoneName = zoneName.toUpperCase().replace(/[^A-Z0-9]/g, "");
            if (!zoneName) zoneName = "Z" + z;

            // Find SEAT sublayer inside this zone
            var seatGroup = null;
            if (zone.pageItems) {
                for (var j = 0; j < zone.pageItems.length; j++) {
                    if (zone.pageItems[j].typename === "GroupItem" &&
                        zone.pageItems[j].name === "SEAT") {
                        seatGroup = zone.pageItems[j];
                        break;
                    }
                }
            }
            if (!seatGroup) {
                report.push("SKIP " + zone.name + ": no SEAT sublayer found");
                continue;
            }

            // Collect seat elements from SEAT group
            var seats = [];
            collectSeats(seatGroup, seats);
            if (seats.length === 0) {
                report.push("SKIP " + zone.name + ": SEAT group is empty");
                continue;
            }

            // Build centroid list
            var centers = [];
            for (var s = 0; s < seats.length; s++) {
                var b = seats[s].geometricBounds;
                centers.push({
                    seat: seats[s],
                    x: (b[0] + b[2]) / 2,
                    y: (b[1] + b[3]) / 2
                });
            }

            // Sort by Y descending (top of canvas = highest Y in AI coords)
            centers.sort(function(a, b) { return b.y - a.y; });

            // Group into rows by Y tolerance
            var rows = [];
            var currentRow = [centers[0]];
            var rowRefY = centers[0].y;
            for (var c = 1; c < centers.length; c++) {
                if (Math.abs(centers[c].y - rowRefY) <= ROW_TOLERANCE) {
                    currentRow.push(centers[c]);
                } else {
                    rows.push(currentRow);
                    currentRow = [centers[c]];
                    rowRefY = centers[c].y;
                }
            }
            if (currentRow.length > 0) rows.push(currentRow);

            // Assign IDs
            var zoneFixed = 0;
            for (var r = 0; r < rows.length; r++) {
                var rowLetter = (r < 26) ? ROW_ABC.charAt(r) : ("R" + (r + 1));
                var grp = zoneName + rowLetter;
                // Sort row left to right by X
                rows[r].sort(function(a, b) { return a.x - b.x; });

                for (var n = 0; n < rows[r].length; n++) {
                    var seatNum = n + 1;
                    var hash = makeHash(grp, seatNum, 0);
                    var attempt = 0;
                    while (globalUsedHashes[hash]) {
                        attempt++;
                        hash = makeHash(grp, seatNum, attempt);
                    }
                    globalUsedHashes[hash] = true;
                    rows[r][n].seat.name =
                        "seatData-" + grp + "-" + seatNum + "-" + seatNum + "-1-" + hash;
                    zoneFixed++;
                }
            }
            totalFixed += zoneFixed;
            report.push("\u2705 " + zone.name + " \u2192 " + rows.length + " rows, " +
                        zoneFixed + " seats ID'd as " + zoneName + "A\u2013" +
                        ((rows.length < 26) ? ROW_ABC.charAt(rows.length - 1) : "R" + rows.length));
        }

        if (totalFixed === 0)
            return "ERROR:\nNo seats were re-ID'd.\n" + report.join("\n");

        return "\u2705 Auto-Fix Seat IDs complete\n" +
               "Total seats re-ID'd: " + totalFixed + "\n\n" +
               report.join("\n") + "\n\n" +
               "Next: run Full Checklist to verify #02 #04 #05 #07.";
    } catch (e) {
        return "autoFixSeatIDs error:\n" + e + "\n(line " + (e.line || "?") + ")";
    }
}

// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
//  SECTION 33  â€“  CURVED ROW PLACER  (SOP Â§5.2 / Â§11.3)
//  Ported from curvedRowPlacer v4.8 for CEP integration
// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

function _nextRowLabel(label) {
    var num = parseInt(label, 10);
    if (!isNaN(num) && String(num) === label) return String(num + 1);
    var chars = label.toUpperCase().split("");
    var idx = chars.length - 1;
    while (idx >= 0) {
        if (chars[idx] === "Z") { chars[idx] = "A"; idx--; }
        else {
            chars[idx] = String.fromCharCode(chars[idx].charCodeAt(0) + 1);
            return chars.join("");
        }
    }
    return "A" + chars.join("");
}

function placeCurvedRow(paramsJSON) {
    var p;
    try { p = eval("(" + paramsJSON + ")"); }
    catch (pe) { return "ERROR:\nCould not parse params: " + pe; }

    try {
        if (app.documents.length === 0) return "ERROR:\nNo document open.";
        var doc = app.activeDocument;
        doc.rulerUnits = RulerUnits.Pixels;

        var zone      = String(p.zone || "ZONE").toUpperCase().replace(/[^A-Z0-9]/g, "");
        var firstRow  = String(p.firstRow || "A").toUpperCase();
        var seatsStr  = String(p.seats || "21");
        var cx        = parseFloat(p.cx);
        var cy        = parseFloat(p.cy);
        var radius    = parseFloat(p.radius || 360);
        var totalDeg  = parseFloat(p.arcDeg || 85);
        var curvePct  = Math.max(0, Math.min(200, parseFloat(p.curvePct || 75)));
        var numRows   = parseInt(p.numRows || "1", 10);
        var radStep   = parseFloat(p.radStep || 9);
        var stagger   = parseFloat(p.stagger || 0);

        // Auto-detect center: Selection â†’ STAGE group â†’ error
        var centerSource = "manual";
        if (isNaN(cx) || isNaN(cy)) {
            if (doc.selection.length > 0) {
                // Use selection center
                var b = doc.selection[0].geometricBounds;
                cx = Math.round((b[0] + b[2]) / 2);
                cy = Math.round(-(b[1] + b[3]) / 2);
                centerSource = "selection";
            } else {
                // Auto-detect from STAGE group
                var stageFound = false;
                for (var li = 0; li < doc.layers.length; li++) {
                    if (doc.layers[li].name === "STAGE") {
                        var stgBounds = doc.layers[li].geometricBounds;
                        // [left, top, right, bottom] in AI coords (top > bottom)
                        cx = Math.round((stgBounds[0] + stgBounds[2]) / 2);
                        // Use bottom-center of STAGE (audience faces stage, arc radiates downward)
                        cy = Math.round(-stgBounds[3]);
                        centerSource = "STAGE";
                        stageFound = true;
                        break;
                    }
                }
                if (!stageFound) {
                    // Try looking inside groupItems on any layer
                    for (var li2 = 0; li2 < doc.layers.length; li2++) {
                        for (var gi = 0; gi < doc.layers[li2].groupItems.length; gi++) {
                            if (doc.layers[li2].groupItems[gi].name === "STAGE") {
                                var stgB2 = doc.layers[li2].groupItems[gi].geometricBounds;
                                cx = Math.round((stgB2[0] + stgB2[2]) / 2);
                                cy = Math.round(-stgB2[3]);
                                centerSource = "STAGE group";
                                stageFound = true;
                                break;
                            }
                        }
                        if (stageFound) break;
                    }
                }
                if (!stageFound) {
                    // Last resort: use artboard center
                    var ab = doc.artboards[0].artboardRect;
                    cx = Math.round((ab[0] + ab[2]) / 2);
                    cy = Math.round((-ab[1] + -ab[3]) / 2);
                    centerSource = "artboard center (no STAGE found)";
                }
            }
        }

        // Parse seats-per-row (comma list or single value)
        var seatCounts = [];
        var parts = seatsStr.split(",");
        for (var i = 0; i < parts.length; i++) {
            var v = parseInt(sopTrim(parts[i]), 10);
            if (!isNaN(v) && v > 0) seatCounts.push(v);
        }
        if (seatCounts.length === 0) return "ERROR:\nSeats per row must be >= 1.";
        while (seatCounts.length < numRows) seatCounts.push(seatCounts[seatCounts.length - 1]);

        var targetLayer = doc.activeLayer;
        var aiCx = cx;
        var aiCy = -cy;
        var totalSeats = 0;
        var rowLabel = firstRow;
        var usedHash = {};

        for (var r = 0; r < numRows; r++) {
            var thisRad   = radius + r * radStep;
            var thisN     = seatCounts[r];
            var effectDeg = totalDeg * (curvePct / 100);
            var halfDeg   = effectDeg / 2;
            var stepDeg   = (thisN > 1) ? effectDeg / (thisN - 1) : 0;
            var grpName   = zone + rowLabel;

            for (var s = 0; s < thisN; s++) {
                var angDeg = -halfDeg + s * stepDeg;
                var angRad = angDeg * Math.PI / 180;
                var sx = aiCx + thisRad * Math.sin(angRad);
                var sy = aiCy + thisRad * Math.cos(angRad);

                if (isNaN(sx) || isNaN(sy)) continue;

                // Stagger: odd seats shift horizontally
                if (Math.abs(stagger) > 0.01 && (s % 2 === 1)) sx += stagger;

                var seatNum = s + 1;
                var hash = makeHash(grpName, seatNum, r * 10000 + s);
                var att = 0;
                while (usedHash[hash]) {
                    att++;
                    hash = makeHash(grpName, seatNum, att * 99991 + r * 10000 + s);
                }
                usedHash[hash] = true;
                var seatId = "seatData-" + grpName + "-" + seatNum + "-" + seatNum + "-1-" + hash;

                // SOP Â§5: axis-aligned 7Ã—7 roundedRectangle, no rotation
                var seat = targetLayer.pathItems.roundedRectangle(
                    sy + 3.5, sx - 3.5, 7, 7, 1.5, 1.5
                );
                seat.name = seatId;
                seat.filled = true;
                seat.fillColor = makeColor([0.56, 0.78, 1.0]);
                seat.stroked = false;
                totalSeats++;
            }
            rowLabel = _nextRowLabel(rowLabel);
        }

        app.redraw();
        return "\u2705 Curved Row Placer complete\n" +
               numRows + " row(s), " + totalSeats + " seats\n" +
               "Zone: " + zone + " | Radius: " + radius + " | Arc: " + totalDeg + "\u00b0\n" +
               "Center: (" + cx + ", " + cy + ") \u2190 " + centerSource + "\n" +
               "Rows " + firstRow + "\u2013" + _nextRowLabel(rowLabel) +
               " | Curve: " + curvePct + "%" +
               (curvePct === 0 ? " (flat)" : curvePct > 100 ? " (tight)" : "");
    } catch (e) {
        return "placeCurvedRow error:\n" + e + "\n(line " + (e.line || "?") + ")";
    }
}

function getSelectionCenter() {
    try {
        if (app.documents.length === 0) return "ERROR:\nNo document open.";
        var doc = app.activeDocument;
        if (doc.selection.length === 0) return "ERROR:\nNo object selected.";
        var b = doc.selection[0].geometricBounds;
        var cx = Math.round((b[0] + b[2]) / 2);
        var cy = Math.round(-(b[1] + b[3]) / 2);
        return cx + "," + cy;
    } catch (e) { return "ERROR:\n" + e; }
}


// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
//  SECTION 34  â€“  TABLE / BANQUET LAYOUT CREATOR  (SOP Â§11.4)
//  Hierarchy (bottomâ†’top): SECTION â†’ UNDERSEATDECORATION (table)
//    â†’ SEAT (bookable) â†’ SEATDECORATION (table#) â†’ SECTIONDECORATION (outline+name)
// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

function createTableLayout(paramsJSON) {
    var p;
    try { p = eval("(" + paramsJSON + ")"); }
    catch (pe) { return "ERROR:\nCould not parse params: " + pe; }

    try {
        if (app.documents.length === 0) return "ERROR:\nNo document open.";
        var doc = app.activeDocument;
        doc.rulerUnits = RulerUnits.Pixels;

        var numTables     = parseInt(p.numTables || "8", 10);
        var seatsPerTable = parseInt(p.seatsPerTable || "8", 10);
        var tableShape    = String(p.tableShape || "circle");
        var seatStyle     = String(p.seatStyle || "standard");
        var tableDiam     = parseFloat(p.tableDiam || 60);
        var tableSpacing  = parseFloat(p.tableSpacing || 120);
        var gridCols      = parseInt(p.gridCols || "4", 10);
        var startNum      = parseInt(p.startNum || "1", 10);
        var naming        = String(p.naming || "number");
        var startX        = parseFloat(p.startX || 200);
        var startY        = parseFloat(p.startY || 200);
        var tableBookable = !!p.tableBookable;

        if (numTables < 1 || numTables > 200) return "ERROR:\nTables: 1\u2013200.";
        if (seatsPerTable < 1 || seatsPerTable > 24) return "ERROR:\nSeats/table: 1\u201324.";
        if (gridCols < 1) gridCols = 4;

        var AB_TOP = doc.artboards[0].artboardRect[1];
        function docY(cy) { return AB_TOP - cy; }
        function mkRGB(r, g, b) {
            var c = new RGBColor(); c.red = r; c.green = g; c.blue = b; return c;
        }

        var C_SEC_FILL  = mkRGB(241,241,241);
        var C_SEC_STR   = mkRGB(209,210,212);
        var C_DECO_FILL = mkRGB(255,255,255);
        var C_DECO_STR  = mkRGB(209,209,210);
        var C_TBL_FILL  = mkRGB(200,200,200);
        var C_LABEL     = mkRGB(109,110,112);
        var C_SEAT      = mkRGB(143,199,255);

        // Seat dimensions by style
        var seatDims = {
            standard: { w: 7,  h: 7,  rx: 1.5, ry: 1.5 },
            small:    { w: 5,  h: 5,  rx: 1,   ry: 1   },
            wide:     { w: 12, h: 7,  rx: 1.5, ry: 1.5 },
            large:    { w: 10, h: 10, rx: 2,   ry: 2   },
            couch:    { w: 20, h: 10, rx: 3,   ry: 3   }
        };
        var sd = seatDims[seatStyle] || seatDims.standard;

        var layer = doc.activeLayer;
        var usedHash = {};
        var totalSeats = 0;
        var gridRows = Math.ceil(numTables / gridCols);
        var tableR = tableDiam / 2;
        var tableRH = (tableShape === "rect" || tableShape === "oval") ? tableR * 0.6 : tableR;
        var seatOrbitR = Math.max(tableR, tableRH) + Math.max(sd.w, sd.h) / 2 + 5;
        var ABC = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

        for (var t = 0; t < numTables; t++) {
            var col = t % gridCols;
            var row = Math.floor(t / gridCols);
            var tcx = startX + col * tableSpacing;
            var tcy = startY + row * tableSpacing;

            var tableName;
            if (naming === "letter") {
                if (t < 26) tableName = ABC.charAt(t);
                else tableName = ABC.charAt(Math.floor(t / 26) - 1) + ABC.charAt(t % 26);
            } else {
                tableName = String(startNum + t);
            }

            var zoneGrp = layer.groupItems.add();
            zoneGrp.name = "ZONE_" + tableName;

            // â•â•â• SECTION (bottom â€” background fill) â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
            var secGrp = zoneGrp.groupItems.add();
            secGrp.name = "SECTION";
            var bgPad = 22;
            var bgW = tableDiam + bgPad * 2 + 16;
            var bgH = (tableShape === "rect" ? tableDiam * 0.6 : tableDiam) + bgPad * 2 + 16;
            var bgR = secGrp.pathItems.roundedRectangle(
                docY(tcy - bgH / 2), tcx - bgW / 2, bgW, bgH, 4, 4
            );
            bgR.filled = true; bgR.fillColor = C_SEC_FILL;
            bgR.stroked = true; bgR.strokeColor = C_SEC_STR; bgR.strokeWidth = 1;

            // â•â•â• UNDERSEATDECORATION (table shape â€” grey) â•â•â•â•â•â•â•â•â•
            var udGrp = zoneGrp.groupItems.add();
            udGrp.name = "UNDERSEATDECORATION";
            var tblItem;
            if (tableShape === "circle") {
                tblItem = udGrp.pathItems.ellipse(
                    docY(tcy - tableR), tcx - tableR, tableDiam, tableDiam
                );
            } else if (tableShape === "oval") {
                tblItem = udGrp.pathItems.ellipse(
                    docY(tcy - tableRH), tcx - tableR, tableDiam, tableRH * 2
                );
            } else if (tableShape === "square") {
                tblItem = udGrp.pathItems.roundedRectangle(
                    docY(tcy - tableR), tcx - tableR, tableDiam, tableDiam, 3, 3
                );
            } else {
                // rect
                tblItem = udGrp.pathItems.roundedRectangle(
                    docY(tcy - tableRH), tcx - tableR, tableDiam, tableRH * 2, 3, 3
                );
            }
            tblItem.filled = true; tblItem.fillColor = C_TBL_FILL;
            tblItem.stroked = false;

            // â•â•â• SEAT (bookable items) â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
            var seatGrp = zoneGrp.groupItems.add();
            seatGrp.name = "SEAT";

            if (tableBookable) {
                // TABLE-BOOKABLE: table shape is the bookable seat
                var hash = makeHash(tableName, 1, t * 10000);
                var att = 0;
                while (usedHash[hash]) { att++; hash = makeHash(tableName, 1, att * 99991 + t * 10000); }
                usedHash[hash] = true;
                var seatId = "seatData-" + tableName + "-1-1-1-" + hash;
                var tblSeat;
                if (tableShape === "circle" || tableShape === "oval") {
                    var tw2 = tableBookable ? tableDiam : sd.w;
                    var th2 = tableBookable ? (tableShape === "oval" ? tableRH * 2 : tableDiam) : sd.h;
                    tblSeat = seatGrp.pathItems.ellipse(
                        docY(tcy - th2 / 2), tcx - tw2 / 2, tw2, th2
                    );
                } else {
                    var tw2 = tableDiam;
                    var th2 = (tableShape === "rect") ? tableRH * 2 : tableDiam;
                    tblSeat = seatGrp.pathItems.roundedRectangle(
                        docY(tcy - th2 / 2), tcx - tw2 / 2, tw2, th2, 3, 3
                    );
                }
                tblSeat.name = seatId;
                tblSeat.filled = true; tblSeat.fillColor = C_SEAT;
                tblSeat.stroked = false;
                totalSeats++;
            } else {
                // SEATS-BOOKABLE: chairs around table
                for (var s = 0; s < seatsPerTable; s++) {
                    var angle = (2 * Math.PI / seatsPerTable) * s - Math.PI / 2;
                    var sx = tcx + seatOrbitR * Math.cos(angle) - sd.w / 2;
                    var sy = tcy + seatOrbitR * Math.sin(angle) - sd.h / 2;
                    var seatNum = s + 1;
                    var hash = makeHash(tableName, seatNum, t * 10000 + s);
                    var att = 0;
                    while (usedHash[hash]) { att++; hash = makeHash(tableName, seatNum, att * 99991 + t * 10000 + s); }
                    usedHash[hash] = true;
                    var seatId = "seatData-" + tableName + "-" + seatNum + "-" + seatNum + "-1-" + hash;
                    var seat = seatGrp.pathItems.roundedRectangle(
                        docY(sy), sx, sd.w, sd.h, sd.rx, sd.ry
                    );
                    seat.name = seatId;
                    seat.filled = true; seat.fillColor = C_SEAT;
                    seat.stroked = false;
                    totalSeats++;
                }
            }

            // â•â•â• SEATDECORATION (table number label) â•â•â•â•â•â•â•â•â•â•â•â•â•â•
            var sdecGrp = zoneGrp.groupItems.add();
            sdecGrp.name = "SEATDECORATION";
            var numLbl = sdecGrp.textFrames.add();
            numLbl.contents = tableName;
            numLbl.textRange.characterAttributes.fillColor = C_LABEL;
            try { numLbl.textRange.characterAttributes.textFont = app.textFonts.getByName("ArialMT"); }
            catch (fe) {}
            numLbl.textRange.characterAttributes.size = (tableDiam < 40) ? 10 : 16;
            var nlW = tableName.length * ((tableDiam < 40) ? 3.5 : 5);
            numLbl.position = [tcx - nlW, docY(tcy + ((tableDiam < 40) ? 4 : 6))];

            // â•â•â• SECTIONDECORATION (zone outline + zone name) â•â•â•â•â•
            var sdGrp = zoneGrp.groupItems.add();
            sdGrp.name = "SECTIONDECORATION";

            // Outline (same size as SECTION bg)
            var outline = sdGrp.pathItems.roundedRectangle(
                docY(tcy - bgH / 2), tcx - bgW / 2, bgW, bgH, 4, 4
            );
            outline.filled = false;
            outline.stroked = true; outline.strokeColor = C_DECO_STR; outline.strokeWidth = 0.5;

            // Zone name label (outside or at top of zone)
            var znLbl = sdGrp.textFrames.add();
            znLbl.contents = tableName;
            znLbl.textRange.characterAttributes.fillColor = C_LABEL;
            try { znLbl.textRange.characterAttributes.textFont = app.textFonts.getByName("ArialMT"); }
            catch (fe2) {}
            znLbl.textRange.characterAttributes.size = 10;
            znLbl.position = [tcx + bgW / 2 + 4, docY(tcy - bgH / 2 + 4)];
        }

        app.redraw();

        return "\u2705 Table Layout created\n" +
               numTables + " tables \u00d7 " + seatsPerTable + " " +
               (tableBookable ? "deco chairs" : "bookable seats") +
               " = " + totalSeats + " bookable item" + (totalSeats === 1 ? "" : "s") + "\n" +
               "Mode: " + (tableBookable ? "TABLE is bookable" : "SEATS are bookable") + "\n" +
               "Table: " + tableShape + " | Seat: " + seatStyle + " | \u00d8 " + tableDiam + "px\n" +
               "Hierarchy: SECTION \u2192 UNDERSEATDECO(table) \u2192 SEAT \u2192 SEATDECO(#) \u2192 SECTIONDECO(outline)";

    } catch (e) {
        return "createTableLayout error:\n" + e + "\n(line " + (e.line || "?") + ")";
    }
}


// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
//  SECTION 35  â€“  STAGE BUILDER  (SOP Â§4.1 / Â§7 / Â§12 #15)
//  8 stage styles matching production venue samples
// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

function buildStage(paramsJSON) {
    try{return ywBuildStage(eval('('+paramsJSON+')'));}catch(e){return 'ERROR: Invalid stage parameters: '+e;}
}


// \u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550
//  SECTION 36  \u2013  AUTO-GENERATE SECTION SHAPES  (\u00a718.7 / 19.2.7)
// \u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550
//
// For each ZONE group, finds the SEAT sublayer, computes bounding box
// of all seats, and creates/replaces a section fill rectangle in the
// SECTION sublayer with SOP-compliant fill/stroke and padding.

function autoGenerateSectionShapes() {
    try {
        if (!app.documents.length) return "ERROR: No document open.";
        var doc = app.activeDocument;
        var PAD = 6;  // px padding around seats
        var created = 0;
        var updated = 0;

        for (var z = 0; z < doc.layers.length; z++) {
            var layer = doc.layers[z];
            var nm = layer.name;
            if (nm.indexOf("ZONE") !== 0 && nm.indexOf("_x") !== 0) continue;

            // Find SEAT sublayer
            var seatLayer = null;
            var sectionLayer = null;
            for (var s = 0; s < layer.layers.length; s++) {
                var sub = layer.layers[s];
                var sn = sub.name.replace(/_\d+_$/, "");
                if (sn === "SEAT") seatLayer = sub;
                if (sn === "SECTION") sectionLayer = sub;
            }
            if (!seatLayer) continue;

            // Count seats and compute bounds
            var allItems = seatLayer.pageItems;
            if (allItems.length === 0) continue;

            var minX = 999999, minY = -999999, maxX = -999999, maxY = 999999;
            var seatCount = 0;
            for (var i = 0; i < allItems.length; i++) {
                var item = allItems[i];
                if (item.typename !== "PathItem") continue;
                var gb = item.geometricBounds; // [left, top, right, bottom] (AI coords: top > bottom)
                if (gb[0] < minX) minX = gb[0];
                if (gb[1] > minY) minY = gb[1];
                if (gb[2] > maxX) maxX = gb[2];
                if (gb[3] < maxY) maxY = gb[3];
                seatCount++;
            }
            if (seatCount === 0) continue;

            // Create SECTION sublayer if missing
            if (!sectionLayer) {
                sectionLayer = layer.layers.add();
                sectionLayer.name = "SECTION";
                sectionLayer.zOrder(ZOrderMethod.SENDTOBACK);
            }

            // Remove existing section shape(s)
            while (sectionLayer.pathItems.length > 0) {
                sectionLayer.pathItems[0].remove();
                updated++;
            }

            // Create new section fill with padding (AI coords: y-up)
            var rx = minX - PAD;
            var ry = minY + PAD;  // top in AI coords
            var rw = (maxX - minX) + PAD * 2;
            var rh = (minY - maxY) + PAD * 2;

            var rect = sectionLayer.pathItems.rectangle(ry, rx, rw, rh);
            rect.filled = true;
            rect.fillColor = makeColor(SOP_COLORS.sectionFill);
            rect.stroked = true;
            rect.strokeColor = makeColor(SOP_COLORS.sectionStroke);
            rect.strokeWidth = 1;
            rect.name = "section_fill";
            created++;
        }

        if (created === 0) return "\u26a0 No ZONE groups with SEAT sublayers found.\nBuild SOP hierarchy first (BUILD tab).";
        return "\u2705 Section shapes auto-generated\n" +
               "Zones processed: " + created + "\n" +
               (updated > 0 ? "Old shapes replaced: " + updated + "\n" : "") +
               "Fill: #F1F1F1 \u00b7 Stroke: #D1D2D4 \u00b7 Padding: " + PAD + "px\n" +
               "Checklist #12: \u2714 #F1F1F1 (not white)\n" +
               "Checklist #18: \u2714 one shape per SECTION";

    } catch (e) {
        return "autoGenerateSectionShapes error:\n" + e + "\n(line " + (e.line || "?") + ")";
    }
}


// \u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550
//  SECTION 37  \u2013  MANIFEST CSV GENERATOR  (\u00a718.3)
// \u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550
//
// Opens a file picker for a CSV manifest. Parses rows and generates
// a complete SOP-compliant Illustrator document with all zones,
// seats, hierarchy, IDs, section fills, labels, and SEATLABELS.
//
// CSV expected columns (fuzzy match): Zone, Row, SeatCount (or FirstSeat, LastSeat)

function manifestCSVGenerate() {
    try {
        var csvFile = File.openDialog("Select CSV Manifest", "CSV files:*.csv,All files:*.*");
        if (!csvFile) return "Cancelled \u2014 no file selected.";
        csvFile.open("r");
        var raw = csvFile.read();
        csvFile.close();

        // Parse CSV
        var lines = raw.split(/\r?\n/);
        if (lines.length < 2) return "ERROR: CSV has no data rows.";

        // Find column indices (fuzzy header match)
        var hdr = lines[0].split(",");
        var colZone = -1, colRow = -1, colCount = -1, colFirst = -1, colLast = -1;
        for (var h = 0; h < hdr.length; h++) {
            var hl = sopTrim(hdr[h]).toLowerCase().replace(/[^a-z0-9]/g, "");
            if (hl === "zone" || hl === "zonename" || hl === "zoneid" || hl === "section") colZone = h;
            else if (hl === "row" || hl === "rowlabel" || hl === "rowletter") colRow = h;
            else if (hl === "seatcount" || hl === "seats" || hl === "count" || hl === "numseats") colCount = h;
            else if (hl === "firstseat" || hl === "first" || hl === "startseat") colFirst = h;
            else if (hl === "lastseat" || hl === "last" || hl === "endseat") colLast = h;
        }
        if (colZone < 0) return "ERROR: Could not find Zone column in CSV header.\nExpected: Zone, ZoneName, or Section";
        if (colRow < 0) return "ERROR: Could not find Row column.\nExpected: Row, RowLabel, or RowLetter";
        if (colCount < 0 && (colFirst < 0 || colLast < 0))
            return "ERROR: Need SeatCount column, or both FirstSeat and LastSeat columns.";

        // Parse data into zone/row structure
        var zones = {};  // { zoneName: [ { row: "A", count: 10, first: 1, last: 10 }, ... ] }
        var zoneOrder = [];
        var totalSeats = 0;

        for (var li = 1; li < lines.length; li++) {
            var line = sopTrim(lines[li]);
            if (line === "") continue;
            var cols = line.split(",");
            var zName = sopTrim(cols[colZone] || "").toUpperCase().replace(/[^A-Z0-9]/g, "");
            var rName = sopTrim(cols[colRow] || "").toUpperCase().replace(/[^A-Z0-9]/g, "");
            if (!zName || !rName) continue;

            var seatCount = 0;
            var firstSeat = 1;
            var lastSeat = 0;
            if (colCount >= 0) {
                seatCount = parseInt(sopTrim(cols[colCount] || "0"), 10) || 0;
                firstSeat = 1;
                lastSeat = seatCount;
            } else {
                firstSeat = parseInt(sopTrim(cols[colFirst] || "1"), 10) || 1;
                lastSeat = parseInt(sopTrim(cols[colLast] || "1"), 10) || 1;
                seatCount = lastSeat - firstSeat + 1;
            }
            if (seatCount <= 0) continue;

            if (!zones[zName]) { zones[zName] = []; zoneOrder.push(zName); }
            zones[zName].push({ row: rName, count: seatCount, first: firstSeat, last: lastSeat });
            totalSeats += seatCount;
        }

        if (zoneOrder.length === 0) return "ERROR: No valid data rows found in CSV.";

        // Calculate canvas size
        var maxRowSeats = 0;
        var maxRows = 0;
        for (var zz = 0; zz < zoneOrder.length; zz++) {
            var zRows = zones[zoneOrder[zz]];
            if (zRows.length > maxRows) maxRows = zRows.length;
            for (var rr = 0; rr < zRows.length; rr++) {
                if (zRows[rr].count > maxRowSeats) maxRowSeats = zRows[rr].count;
            }
        }
        var zoneWidth = maxRowSeats * 9 + 40;
        var zoneHeight = maxRows * 9 + 60;
        var canvasW = zoneOrder.length * (zoneWidth + 30) + 60;
        var canvasH = zoneHeight + 200;

        // Create new document
        var preset = new DocumentPreset();
        preset.width = canvasW;
        preset.height = canvasH;
        preset.units = RulerUnits.Pixels;
        preset.colorMode = DocumentColorSpace.RGB;
        var doc = app.documents.addDocument("", preset);

        // â”€â”€ STAGE group â”€â”€
        var stageLayer = doc.layers.add();
        stageLayer.name = "STAGE";
        var stageW = Math.min(canvasW * 0.4, 500);
        var stageH = 60;
        var stageCX = canvasW / 2;
        var stageTop = canvasH - 30;
        var stageRect = stageLayer.pathItems.rectangle(
            -stageTop + stageH, stageCX - stageW/2, stageW, stageH
        );
        stageRect.filled = true; stageRect.fillColor = makeColor(SOP_COLORS.stageFill);
        stageRect.stroked = true; stageRect.strokeColor = makeColor(SOP_COLORS.stageStroke);
        stageRect.strokeWidth = 1;

        // â”€â”€ DECORATION group â”€â”€
        var decoLayer = doc.layers.add();
        decoLayer.name = "DECORATION";
        var stageLbl = decoLayer.textFrames.add();
        stageLbl.contents = "STAGE";
        var sa = stageLbl.textRange.characterAttributes;
        sa.fillColor = makeColor(SOP_COLORS.labelText);
        sa.size = 30;
        try { sa.textFont = app.textFonts.getByName("ArialMT"); } catch(e2){}
        app.redraw();
        stageLbl.position = [stageCX - stageLbl.width/2, -(stageTop - stageH/2 + stageLbl.height/2)];

        // â”€â”€ Generate ZONE groups â”€â”€
        var zoneStartX = 30;
        var zoneStartY = 80;
        var zonesSummary = [];

        for (var zi = 0; zi < zoneOrder.length; zi++) {
            var zoneName = zoneOrder[zi];
            var zoneRows = zones[zoneName];
            var zLabel = (zoneName.match(/^[0-9]/)) ? "_x" + zoneName.charCodeAt(0).toString(16) + "_" + zoneName.substring(1) : "ZONE_" + zoneName;

            var zLayer = doc.layers.add();
            zLayer.name = zLabel;

            // Create sublayers
            var secLayer = zLayer.layers.add(); secLayer.name = "SECTION";
            zLayer.layers.add().name = "UNDERSEATDECORATION";
            var seatLayer = zLayer.layers.add(); seatLayer.name = "SEAT";
            zLayer.layers.add().name = "SEATDECORATION";
            var sdLayer = zLayer.layers.add(); sdLayer.name = "SECTIONDECORATION";

            // Reorder: SECTION at back, SECTIONDECORATION at front
            secLayer.zOrder(ZOrderMethod.SENDTOBACK);

            // Place seats
            var ox = zoneStartX + zi * (zoneWidth + 30);
            var zoneSeatTotal = 0;

            for (var ri = 0; ri < zoneRows.length; ri++) {
                var rowData = zoneRows[ri];
                var rowY = zoneStartY + ri * 9;
                var group = zoneName + rowData.row;

                // Detect aisle gaps from first/last
                var seatPositions = [];
                for (var si = rowData.first; si <= rowData.last; si++) {
                    seatPositions.push(si);
                }

                var xOffset = 0;
                for (var pi = 0; pi < seatPositions.length; pi++) {
                    var seatNum = seatPositions[pi];
                    // Check for gap (aisle) before this seat
                    if (pi > 0 && seatPositions[pi] - seatPositions[pi-1] > 1) {
                        var gapSlots = seatPositions[pi] - seatPositions[pi-1] - 1;
                        xOffset += gapSlots * 9; // aisle gap
                    }

                    var sx = ox + xOffset;
                    var sy = rowY;

                    // AI coords: y is negative downward from top-left
                    var aiTop = -sy;
                    var aiLeft = sx;

                    var seat = seatLayer.pathItems.rectangle(aiTop, aiLeft, 7, 7, false, false);
                    seat.filled = true;
                    seat.fillColor = makeColor([0.8, 0.8, 0.8]); // default grey
                    seat.stroked = false;

                    // Round corners
                    try {
                        // ES3-safe: pathPoints manipulation for rounded rect
                        // Simpler: just set name and let fixSeatSizes handle rx/ry
                    } catch(e3){}

                    // Generate seatData ID
                    var hashRaw = group + "-" + seatNum + "-0";
                    var hash = sopMD5(hashRaw).substring(0, 13);
                    seat.name = "seatData-" + group + "-" + seatNum + "-" + seatNum + "-1-" + hash;
                    zoneSeatTotal++;
                    xOffset += 9;
                }
            }

            // Section fill shape
            var secW = (maxRowSeats * 9) + 12;
            var secH = (zoneRows.length * 9) + 12;
            var secRect = secLayer.pathItems.rectangle(
                -(zoneStartY - 6), ox - 6, secW, secH
            );
            secRect.filled = true; secRect.fillColor = makeColor(SOP_COLORS.sectionFill);
            secRect.stroked = true; secRect.strokeColor = makeColor(SOP_COLORS.sectionStroke);
            secRect.strokeWidth = 1;
            secRect.name = "section_fill";

            // Section decoration label
            var sdBg = sdLayer.pathItems.rectangle(
                -(zoneStartY + zoneRows.length * 9 + 8), ox + secW/2 - 25, 50, 22
            );
            sdBg.filled = true; sdBg.fillColor = makeColor(SOP_COLORS.decorFill);
            sdBg.stroked = true; sdBg.strokeColor = makeColor(SOP_COLORS.sectionStroke);
            sdBg.strokeWidth = 0.5;

            var sdTxt = sdLayer.textFrames.add();
            sdTxt.contents = zoneName;
            var ta = sdTxt.textRange.characterAttributes;
            ta.fillColor = makeColor(SOP_COLORS.labelText);
            ta.size = 14;
            try { ta.textFont = app.textFonts.getByName("ArialMT"); } catch(e4){}
            app.redraw();
            sdTxt.position = [ox + secW/2 - sdTxt.width/2, -(zoneStartY + zoneRows.length * 9 + 10)];

            zonesSummary.push(zoneName + ": " + zoneSeatTotal + " seats (" + zoneRows.length + " rows)");
        }

        // â”€â”€ SEATLABELS (always empty, always last) â”€â”€
        var slLayer = doc.layers.add();
        slLayer.name = "SEATLABELS";

        // Reorder layers: STAGE at back, SEATLABELS at front
        stageLayer.zOrder(ZOrderMethod.SENDTOBACK);
        decoLayer.move(stageLayer, ElementPlacement.PLACEBEFORE);
        slLayer.zOrder(ZOrderMethod.BRINGTOFRONT);

        app.redraw();

        return "\u2705 Manifest-first SVG generated\n" +
               "Source: " + csvFile.name + "\n" +
               "Zones: " + zoneOrder.length + " \u00b7 Total seats: " + totalSeats + "\n" +
               "â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•\n" +
               zonesSummary.join("\n") + "\n" +
               "â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•\n" +
               "Hierarchy: STAGE \u2192 DECO \u2192 ZONES \u2192 SEATLABELS\n" +
               "All seatData IDs valid + unique.\n" +
               "Next: overlay source plan, reposition seats, run Fix All \u2192 Save.";

    } catch (e) {
        return "manifestCSVGenerate error:\n" + e + "\n(line " + (e.line || "?") + ")";
    }
}

// Simple MD5 for ExtendScript (ES3-safe, for hash generation)
function sopMD5(str) {
    // Lightweight deterministic hash â€” not crypto-grade, but unique enough for seatData
    var h = 0x811c9dc5;
    for (var i = 0; i < str.length; i++) {
        h ^= str.charCodeAt(i);
        h = (h * 0x01000193) & 0xffffffff;
    }
    // Extend to 13 hex chars by iterating
    var out = "";
    var v = Math.abs(h);
    for (var j = 0; j < 4; j++) {
        v = (v * 0x5bd1e995 + 0x6b8b4567) & 0xffffffff;
        out += ("0000" + (Math.abs(v) >>> 0).toString(16)).slice(-4);
    }
    return out.substring(0, 13);
}


// \u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550
//  SECTION 38  \u2013  VERSION SNAPSHOT  (\u00a718.7)
// \u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550
//
// Saves a timestamped copy of the current _SOP.svg (or .ai) next
// to the working file in a /versions/ subfolder.

function snapshotVersion() { return createBackupSnapshot("version"); }

// Helper: count seats recursively in a layer
function countSeatsInLayer(layer) {
    var count = 0;
    for (var i = 0; i < layer.pageItems.length; i++) {
        if (layer.pageItems[i].name && layer.pageItems[i].name.indexOf("seatData-") === 0) count++;
    }
    for (var j = 0; j < layer.layers.length; j++) {
        count += countSeatsInLayer(layer.layers[j]);
    }
    return count;
}


// \u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550
//  SECTION 39  \u2013  MULTI-LEVEL VENUE SPLITTER  (\u00a718.6)
// \u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550
//
// Splits the current multi-level venue into separate SVG files
// based on a comma-separated list of zone prefixes per level.
// Example input: "A,B,C,D|E,F,G,H"  (pipe separates levels)

function splitByLevel(levelSpec) {
    try {
        if (!app.documents.length) return "ERROR: No document open.";
        var doc = app.activeDocument;
        if (!doc.path || !doc.path.fsName) return "ERROR: Save the document first.";

        levelSpec = sopTrim(levelSpec);
        if (!levelSpec) return "ERROR: Provide level spec.\nFormat: A,B,C|D,E,F\n(pipe = level separator, comma = zone list)";

        var levels = levelSpec.split("|");
        if (levels.length < 2) return "ERROR: Need at least 2 levels separated by |.\nExample: A,B,C|D,E,F";

        var docName = doc.name.replace(/\.(ai|svg)$/i, "");
        var outputDir = new Folder(doc.path.fsName + "/split");
        if (!outputDir.exists) outputDir.create();

        var report = [];
        var totalExported = 0;

        for (var lv = 0; lv < levels.length; lv++) {
            var zonePrefixes = levels[lv].split(",");
            for (var zp = 0; zp < zonePrefixes.length; zp++) {
                zonePrefixes[zp] = sopTrim(zonePrefixes[zp]).toUpperCase();
            }

            // Hide all zone layers not in this level
            var visState = [];
            var levelSeats = 0;
            var levelZones = 0;
            for (var i = 0; i < doc.layers.length; i++) {
                var lay = doc.layers[i];
                visState.push(lay.visible);

                var layName = lay.name;
                var isZone = (layName.indexOf("ZONE") === 0 || layName.indexOf("_x") === 0);
                var isUtil = (layName === "STAGE" || layName === "DECORATION" || layName === "SEATLABELS");

                if (isUtil) {
                    lay.visible = true;
                } else if (isZone) {
                    // Check if this zone matches any prefix in current level
                    var match = false;
                    for (var zz = 0; zz < zonePrefixes.length; zz++) {
                        if (layName.indexOf("ZONE_" + zonePrefixes[zz]) === 0 ||
                            layName === "ZONE_" + zonePrefixes[zz]) {
                            match = true;
                            break;
                        }
                    }
                    lay.visible = match;
                    if (match) {
                        levelZones++;
                        levelSeats += countSeatsInLayer(lay);
                    }
                } else {
                    lay.visible = false;
                }
            }

            // Export this level as SVG
            var levelName = docName + "_Level" + (lv + 1) + "_SOP";
            var svgFile = new File(outputDir.fsName + "/" + levelName + ".svg");
            var svgOpts = new ExportOptionsSVG();
            svgOpts.DTD = SVGDTDVersion.SVG1_1;
            svgOpts.cssProperties = SVGCSSPropertyLocation.PRESENTATIONATTRIBUTES;
            svgOpts.coordinatePrecision = 2;
            svgOpts.documentEncoding = SVGDocumentEncoding.UTF8;
            svgOpts.embedRasterImages = false;
            safeExportSVG(doc, svgFile, svgOpts);

            svgFile = new File(outputDir.fsName + "/" + levelName + ".svg");
            var fsize = svgFile.exists ? Math.round(svgFile.length / 1024) : "?";

            report.push("Level " + (lv + 1) + ": " + zonePrefixes.join(", ") +
                         " \u2192 " + levelZones + " zones, " + levelSeats + " seats (" + fsize + " KB)");
            totalExported += levelSeats;

            // Restore visibility
            for (var rv = 0; rv < doc.layers.length; rv++) {
                doc.layers[rv].visible = visState[rv];
            }
        }

        return "\u2705 Multi-level split complete\n" +
               "Levels exported: " + levels.length + "\n" +
               "Total seats across all levels: " + totalExported + "\n" +
               "\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\n" +
               report.join("\n") + "\n" +
               "\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\n" +
               "Output: " + outputDir.fsName;

    } catch (e) {
        return "splitByLevel error:\n" + e + "\n(line " + (e.line || "?") + ")";
    }
}


// \u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550
//  SECTION 40  \u2013  CROSS-FILE HASH REGISTRY CHECK  (\u00a719.1.6)
// \u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550
//
// Opens a folder picker. Scans ALL .svg files in that folder.
// Extracts all seatData hashes and checks for cross-file collisions.

function hashRegistryCheck() {
    try {
        var folder = Folder.selectDialog("Select folder with SVG venue files");
        if (!folder) return "Cancelled.";

        var svgFiles = folder.getFiles("*.svg");
        if (svgFiles.length === 0) return "No .svg files found in " + folder.fsName;

        var hashMap = {};  // hash -> { file, id }
        var collisions = [];
        var totalSeats = 0;
        var filesSummary = [];

        for (var fi = 0; fi < svgFiles.length; fi++) {
            var f = svgFiles[fi];
            f.open("r");
            var content = f.read();
            f.close();

            // Extract seatData IDs
            var idPattern = /id="(seatData-[^"]+)"/g;
            var match;
            var fileSeats = 0;
            var fileHashes = [];

            // ES3-safe regex exec loop
            while ((match = idPattern.exec(content)) !== null) {
                var fullId = match[1];
                var parts = fullId.split("-");
                if (parts.length >= 6) {
                    var hash = parts[parts.length - 1];
                    fileSeats++;
                    totalSeats++;

                    if (hashMap[hash]) {
                        // Collision!
                        collisions.push({
                            hash: hash,
                            file1: hashMap[hash].file,
                            id1: hashMap[hash].id,
                            file2: f.name,
                            id2: fullId
                        });
                    } else {
                        hashMap[hash] = { file: f.name, id: fullId };
                    }
                }
            }

            filesSummary.push(f.name + ": " + fileSeats + " seats");
        }

        var out = "\u2705 Hash Registry Scan Complete\n" +
                  "Files scanned: " + svgFiles.length + "\n" +
                  "Total seats: " + totalSeats + "\n" +
                  "Unique hashes: " + Object.keys(hashMap).length + "\n" +
                  "\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\n";

        if (collisions.length > 0) {
            out += "\u274c CROSS-FILE COLLISIONS FOUND: " + collisions.length + "\n";
            for (var ci = 0; ci < Math.min(collisions.length, 20); ci++) {
                var c = collisions[ci];
                out += "  Hash: " + c.hash + "\n";
                out += "    File 1: " + c.file1 + " \u2192 " + c.id1 + "\n";
                out += "    File 2: " + c.file2 + " \u2192 " + c.id2 + "\n";
            }
            if (collisions.length > 20) out += "  ... and " + (collisions.length - 20) + " more\n";
        } else {
            out += "\u2714 No cross-file hash collisions \u2014 PASS\n";
        }

        out += "\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\nFiles:\n" + filesSummary.join("\n");
        return out;

    } catch (e) {
        return "hashRegistryCheck error:\n" + e + "\n(line " + (e.line || "?") + ")";
    }
}

// ES3-safe Object.keys polyfill
if (typeof Object.keys !== "function") {
    Object.keys = function(obj) {
        var result = [];
        for (var key in obj) {
            if (obj.hasOwnProperty(key)) result.push(key);
        }
        return result;
    };
}


// \u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550
//  SECTION 42  \u2013  LIST DOCUMENT ZONES  (UI scope selector)
// \u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550
//
// Returns a comma-separated list of all ZONE layer/group names
// in the current document for the scope selector panel.

function listDocumentZones() {
    try {
        if (!app.documents.length) return "";
        var doc = app.activeDocument;
        var zones = [];

        for (var i = 0; i < doc.layers.length; i++) {
            var nm = doc.layers[i].name;
            // Match ZONE_ prefixed or _x hex-encoded zone names
            if (nm.indexOf("ZONE_") === 0 || nm.indexOf("_x") === 0) {
                zones.push(nm);
            }
        }
        // Also check groupItems on the default layer
        if (zones.length === 0) {
            for (var li = 0; li < doc.layers.length; li++) {
                for (var gi = 0; gi < doc.layers[li].groupItems.length; gi++) {
                    var gn = doc.layers[li].groupItems[gi].name;
                    if (gn.indexOf("ZONE_") === 0 || gn.indexOf("_x") === 0) {
                        zones.push(gn);
                    }
                }
            }
        }
        return zones.join(",");
    } catch (e) {
        return "";
    }
}


// \u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550
//  SECTION 41  \u2013  VENUE STATUS REPORT  (\u00a720.1 / 20.3)
// \u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550
//
// Generates a production-readiness summary of the current document:
// seat count, file size estimate, QA gate status, and lifecycle stage.

function venueStatusReport() {
    try {
        if (!app.documents.length) return "ERROR: No document open.";
        var doc = app.activeDocument;

        var report = "\u2550\u2550\u2550 VENUE STATUS REPORT \u2550\u2550\u2550\n";
        report += "Document: " + doc.name + "\n";

        // Seat count
        var totalSeats = 0;
        var zoneList = [];
        for (var i = 0; i < doc.layers.length; i++) {
            var lay = doc.layers[i];
            var layName = lay.name;
            if (layName.indexOf("ZONE") === 0 || layName.indexOf("_x") === 0) {
                var zSeats = countSeatsInLayer(lay);
                totalSeats += zSeats;
                zoneList.push(layName + ": " + zSeats);
            }
        }
        report += "Total seats: " + totalSeats + "\n";
        report += "Zones: " + zoneList.length + "\n";

        // File path & size
        if (doc.path && doc.path.fsName) {
            report += "Path: " + doc.path.fsName + "\n";
            // Check for _SOP.svg
            var docBase = doc.name.replace(/\.(ai|svg)$/i, "");
            var sopFile = new File(doc.path.fsName + "/" + docBase + "_SOP.svg");
            if (sopFile.exists) {
                var sizeKB = Math.round(sopFile.length / 1024);
                report += "SVG file: " + docBase + "_SOP.svg (" + sizeKB + " KB)\n";
                if (sizeKB > 5120) report += "\u274c G7 FILE SIZE: FAIL (> 5 MB)\n";
                else if (sizeKB > 500) report += "\u26a0 G7 FILE SIZE: over target (> 500 KB)\n";
                else report += "\u2714 G7 FILE SIZE: PASS (\u2264 500 KB)\n";
            } else {
                report += "SVG file: not exported yet\n";
            }
        } else {
            report += "Path: unsaved\n";
        }

        // Quick gate checks
        report += "\n\u2550\u2550\u2550 QUALITY GATES \u2550\u2550\u2550\n";

        // G1: Structure â€” check for forbidden elements (just STAGE + SEATLABELS presence)
        var hasStage = false, hasSL = false;
        for (var g = 0; g < doc.layers.length; g++) {
            if (doc.layers[g].name === "STAGE") hasStage = true;
            if (doc.layers[g].name === "SEATLABELS") hasSL = true;
        }
        report += (hasStage ? "\u2714" : "\u274c") + " G1 Structure: STAGE group " + (hasStage ? "present" : "MISSING") + "\n";
        report += (hasSL ? "\u2714" : "\u274c") + " G1 Structure: SEATLABELS " + (hasSL ? "present" : "MISSING") + "\n";

        // G2: IDs â€” quick spot check for seatData pattern
        var badIDs = 0;
        var dupeCheck = {};
        var dupeCount = 0;
        checkIDsInLayer(doc, dupeCheck, function(name) {
            if (name.indexOf("seatData-") !== 0) return;
            var parts = name.split("-");
            if (parts.length < 6) badIDs++;
            else if (parts[3] !== parts[4]) badIDs++;
            else if (parts[5] !== "1") badIDs++;
        });

        // Count IDs for dupes
        var allIds = [];
        collectIdsFromDoc(doc, allIds);
        var idSet = {};
        for (var di = 0; di < allIds.length; di++) {
            if (idSet[allIds[di]]) dupeCount++;
            idSet[allIds[di]] = true;
        }

        report += (badIDs === 0 ? "\u2714" : "\u274c") + " G2 IDs: " + (badIDs === 0 ? "all valid" : badIDs + " malformed") + "\n";
        report += (dupeCount === 0 ? "\u2714" : "\u274c") + " G2 Duplicates: " + (dupeCount === 0 ? "none" : dupeCount + " found") + "\n";

        // Peer review gate
        report += "\n\u2550\u2550\u2550 LIFECYCLE \u2550\u2550\u2550\n";
        if (totalSeats > 5000) {
            report += "\u26a0 Venue > 5,000 seats \u2014 PEER REVIEW REQUIRED (G8)\n";
        }
        report += "Run Full 32-Item Checklist for complete gate assessment.\n";

        // Zone breakdown
        report += "\n\u2550\u2550\u2550 ZONES \u2550\u2550\u2550\n";
        for (var zli = 0; zli < zoneList.length; zli++) {
            report += "  " + zoneList[zli] + "\n";
        }

        return report;

    } catch (e) {
        return "venueStatusReport error:\n" + e + "\n(line " + (e.line || "?") + ")";
    }
}

// Helper: collect IDs from entire document
function collectIdsFromDoc(doc, arr) {
    for (var i = 0; i < doc.layers.length; i++) {
        collectIdsFromLayer(doc.layers[i], arr);
    }
}
function collectIdsFromLayer(layer, arr) {
    for (var i = 0; i < layer.pageItems.length; i++) {
        var nm = layer.pageItems[i].name;
        if (nm && nm.indexOf("seatData-") === 0) arr.push(nm);
    }
    for (var j = 0; j < layer.layers.length; j++) {
        collectIdsFromLayer(layer.layers[j], arr);
    }
}

// Helper: iterate IDs with callback
function checkIDsInLayer(doc, obj, cb) {
    for (var i = 0; i < doc.layers.length; i++) {
        checkIDsRecurse(doc.layers[i], obj, cb);
    }
}
function checkIDsRecurse(layer, obj, cb) {
    for (var i = 0; i < layer.pageItems.length; i++) {
        var nm = layer.pageItems[i].name;
        if (nm && nm.indexOf("seatData-") === 0) cb(nm);
    }
    for (var j = 0; j < layer.layers.length; j++) {
        checkIDsRecurse(layer.layers[j], obj, cb);
    }
}


// ═══════════════════════════════════════════════════════════════
//  SECTION 43 – STRAIGHT ROW PLACER  (SOP §5.1 / §5.3)
//  Places straight rows of 7×7px seats on the 9px grid.
//  Aisle support: comma-separated seat numbers after which to
//  insert a 27px (3-slot) gap.
// ═══════════════════════════════════════════════════════════════

function placeStraightRow(paramsJSON) {
    var p;
    try { p = eval("(" + paramsJSON + ")"); }
    catch (pe) { return "ERROR:\nCould not parse params: " + pe; }

    try {
        if (app.documents.length === 0) return "ERROR:\nNo document open.";
        var doc = app.activeDocument;
        doc.rulerUnits = RulerUnits.Pixels;

        var zone     = String(p.zone || "ZONE").toUpperCase().replace(/[^A-Z0-9]/g, "");
        var firstRow = String(p.row  || "A").toUpperCase();
        var numRows  = parseInt(p.rows  || "1", 10);
        var numSeats = parseInt(p.seats || "10", 10);
        var startX   = parseFloat(p.x || 100);
        var startY   = parseFloat(p.y || 100);
        var step     = parseFloat(p.step   || 9);
        var rowStep  = parseFloat(p.rStep  || 9);
        var aisleStr = String(p.aisles || "");
        var aisleW   = parseFloat(p.aisleW || 27);

        if (numRows < 1 || numRows > 200) return "ERROR:\nRows must be 1–200.";
        if (numSeats < 1 || numSeats > 500) return "ERROR:\nSeats per row must be 1–500.";
        if (step < 7) return "ERROR:\nStep must be >= 7 (seat width).";

        // Parse aisle positions (seat numbers after which to insert gap)
        var aisleAfter = {};
        if (aisleStr) {
            var ap = aisleStr.split(",");
            for (var ai = 0; ai < ap.length; ai++) {
                var av = parseInt(sopTrim(ap[ai]), 10);
                if (!isNaN(av) && av > 0) aisleAfter[av] = true;
            }
        }

        // AI Y-axis: top = positive, canvas Y down = negative in AI
        var AB_TOP = doc.artboards[0].artboardRect[1];
        function docY(cy) { return AB_TOP - cy; }

        // Find or use active layer
        var targetLayer = doc.activeLayer;

        // Try to find SEAT group in the zone
        var zoneGrp = findGroupByName(doc, "ZONE_" + zone);
        var seatParent = targetLayer;
        if (zoneGrp) {
            // Look for SEAT sublayer
            if (zoneGrp.pageItems) {
                for (var si = 0; si < zoneGrp.pageItems.length; si++) {
                    if (zoneGrp.pageItems[si].typename === "GroupItem" &&
                        zoneGrp.pageItems[si].name === "SEAT") {
                        seatParent = zoneGrp.pageItems[si];
                        break;
                    }
                }
            }
        }

        var seatColor = makeColor([0.56, 0.78, 1.0]); // default blue
        var totalSeats = 0;
        var usedHash = {};
        var rowLabel = firstRow;

        for (var r = 0; r < numRows; r++) {
            var grpName = zone + rowLabel;
            var xOff = 0;

            for (var s = 0; s < numSeats; s++) {
                var seatNum = s + 1;
                var sx = startX + xOff;
                var sy = startY + r * rowStep;

                var hash = makeHash(grpName, seatNum, r * 10000 + s);
                var att = 0;
                while (usedHash[hash]) {
                    att++;
                    hash = makeHash(grpName, seatNum, att * 99991 + r * 10000 + s);
                }
                usedHash[hash] = true;

                var seatId = "seatData-" + grpName + "-" + seatNum + "-" + seatNum + "-1-" + hash;
                var seat = seatParent.pathItems.roundedRectangle(
                    docY(sy), sx, 7, 7, 1.5, 1.5
                );
                seat.name = seatId;
                seat.filled = true;
                seat.fillColor = seatColor;
                seat.stroked = false;
                totalSeats++;

                xOff += step;
                // Insert aisle gap after this seat number
                if (aisleAfter[seatNum]) {
                    xOff += aisleW;
                }
            }
            rowLabel = _nextRowLabel(rowLabel);
        }

        app.redraw();
        return "\u2705 Straight Row Placer complete\n" +
               numRows + " row(s), " + totalSeats + " seats\n" +
               "Zone: " + zone + " | Step: " + step + "px | Row step: " + rowStep + "px\n" +
               "Start: (" + startX + ", " + startY + ")\n" +
               (aisleStr ? "Aisles after seats: " + aisleStr + " (" + aisleW + "px gap)\n" : "") +
               "Placed in: " + (seatParent.name || "active layer");
    } catch (e) {
        return "placeStraightRow error:\n" + e + "\n(line " + (e.line || "?") + ")";
    }
}


// ═══════════════════════════════════════════════════════════════
//  SECTION 44 – MANUAL SECTION SHAPE CREATOR
//  Creates a SECTION rectangle inside a zone with SOP fill/stroke.
// ═══════════════════════════════════════════════════════════════

function createManualSection(paramsJSON) {
    var p;
    try { p = eval("(" + paramsJSON + ")"); }
    catch (pe) { return "ERROR:\nCould not parse params: " + pe; }

    try {
        if (app.documents.length === 0) return "ERROR:\nNo document open.";
        var doc = app.activeDocument;
        doc.rulerUnits = RulerUnits.Pixels;

        var zone = String(p.zone || "A").toUpperCase().replace(/[^A-Z0-9]/g, "");
        var secNum = String(p.num || "1");
        var sx   = parseFloat(p.x || 50);
        var sy   = parseFloat(p.y || 50);
        var sw   = parseFloat(p.w || 200);
        var sh   = parseFloat(p.h || 100);
        var pad  = parseFloat(p.pad || 0);
        var rx   = parseFloat(p.rx || 0);

        if (sw < 10 || sh < 10) return "ERROR:\nMinimum size: 10×10px.";

        var AB_TOP = doc.artboards[0].artboardRect[1];
        function docY(cy) { return AB_TOP - cy; }

        // Find SECTION sublayer inside ZONE
        var zoneGrp = findGroupByName(doc, "ZONE_" + zone);
        var secParent = null;
        if (zoneGrp && zoneGrp.pageItems) {
            for (var i = 0; i < zoneGrp.pageItems.length; i++) {
                if (zoneGrp.pageItems[i].typename === "GroupItem" &&
                    zoneGrp.pageItems[i].name === "SECTION") {
                    secParent = zoneGrp.pageItems[i];
                    break;
                }
            }
        }
        if (!secParent) {
            // Fall back: create in active layer
            secParent = doc.activeLayer;
        }

        // Apply padding
        var fx = sx - pad;
        var fy = sy - pad;
        var fw = sw + pad * 2;
        var fh = sh + pad * 2;

        var rect;
        if (rx > 0) {
            rect = secParent.pathItems.roundedRectangle(docY(fy), fx, fw, fh, rx, rx);
        } else {
            rect = secParent.pathItems.rectangle(docY(fy), fx, fw, fh);
        }
        rect.filled = true;
        rect.fillColor = makeColor(SOP_COLORS.sectionFill);
        rect.stroked = true;
        rect.strokeColor = makeColor(SOP_COLORS.sectionStroke);
        rect.strokeWidth = 1;
        rect.name = "section_fill_" + zone + "_" + secNum;

        app.redraw();
        return "\u2705 Section shape created\n" +
               "Zone: " + zone + " | Section: " + secNum + "\n" +
               "Position: (" + fx + ", " + fy + ") | Size: " + fw + "×" + fh + "px\n" +
               "Fill: #F1F1F1 | Stroke: #D1D2D4\n" +
               "Placed in: " + (secParent.name || "active layer");
    } catch (e) {
        return "createManualSection error:\n" + e + "\n(line " + (e.line || "?") + ")";
    }
}


// ═══════════════════════════════════════════════════════════════
//  SECTION 45 – SECTION LABEL PLACER
//  Adds a text label to the SECTIONDECORATION sublayer of a zone.
//  SOP §10: Arial 30px #6d6e70 (actual CSS: #6d6e70)
// ═══════════════════════════════════════════════════════════════

function addSectionLabel(paramsJSON) {
    var p;
    try { p = eval("(" + paramsJSON + ")"); }
    catch (pe) { return "ERROR:\nCould not parse params: " + pe; }

    try {
        if (app.documents.length === 0) return "ERROR:\nNo document open.";
        var doc = app.activeDocument;
        doc.rulerUnits = RulerUnits.Pixels;

        var zone  = String(p.zone  || "A").toUpperCase().replace(/[^A-Z0-9]/g, "");
        var label = String(p.label || zone);
        var fontSize = parseFloat(p.font || 30);
        var pos   = String(p.pos || "below");  // below, above, center, custom

        // Find SECTIONDECORATION sublayer
        var zoneGrp = findGroupByName(doc, "ZONE_" + zone);
        var sdParent = null;
        if (zoneGrp && zoneGrp.pageItems) {
            for (var i = 0; i < zoneGrp.pageItems.length; i++) {
                if (zoneGrp.pageItems[i].typename === "GroupItem" &&
                    zoneGrp.pageItems[i].name === "SECTIONDECORATION") {
                    sdParent = zoneGrp.pageItems[i];
                    break;
                }
            }
        }
        if (!sdParent) {
            return "ERROR:\nCould not find SECTIONDECORATION in ZONE_" + zone + ".\n" +
                   "Build SOP hierarchy first.";
        }

        // Find SEAT sublayer bounds for positioning
        var seatGrp = null;
        if (zoneGrp.pageItems) {
            for (var j = 0; j < zoneGrp.pageItems.length; j++) {
                if (zoneGrp.pageItems[j].typename === "GroupItem" &&
                    zoneGrp.pageItems[j].name === "SEAT") {
                    seatGrp = zoneGrp.pageItems[j];
                    break;
                }
            }
        }

        // Calculate position based on seat bounds
        var lx = 0, ly = 0;
        if (seatGrp && seatGrp.pageItems && seatGrp.pageItems.length > 0) {
            var gb = seatGrp.geometricBounds; // [left, top, right, bottom]
            var cx = (gb[0] + gb[2]) / 2;
            var bTop = gb[1];
            var bBot = gb[3];
            if (pos === "below") {
                lx = cx - label.length * 5;
                ly = bBot - 15;
            } else if (pos === "above") {
                lx = cx - label.length * 5;
                ly = bTop + fontSize + 5;
            } else {
                lx = cx - label.length * 5;
                ly = (bTop + bBot) / 2 + fontSize / 2;
            }
        }

        // Create badge background
        var badgeW = Math.max(36, label.length * 11 + 10);
        var badgeH = 22;
        var badge = sdParent.pathItems.roundedRectangle(
            ly + badgeH / 2, lx - 5, badgeW, badgeH, 3, 3
        );
        badge.filled = true;
        badge.fillColor = makeColor(SOP_COLORS.decorFill);
        badge.stroked = true;
        badge.strokeColor = makeColor(SOP_COLORS.sectionStroke);
        badge.strokeWidth = 0.5;

        // Create text
        var txt = sdParent.textFrames.pointText([lx, ly]);
        txt.contents = label;
        var attr = txt.textRange.characterAttributes;
        attr.size = fontSize;
        attr.fillColor = makeColor(SOP_COLORS.labelText);
        try { attr.textFont = app.textFonts.getByName("ArialMT"); } catch (fe) {
            try { attr.textFont = app.textFonts.getByName("Arial"); } catch (fe2) {}
        }

        app.redraw();
        return "\u2705 Section label added\n" +
               "Zone: " + zone + " | Label: '" + label + "'\n" +
               "Font: Arial " + fontSize + "px | Fill: #6d6e70\n" +
               "Position: " + pos;
    } catch (e) {
        return "addSectionLabel error:\n" + e + "\n(line " + (e.line || "?") + ")";
    }
}


// ═══════════════════════════════════════════════════════════════
//  SECTION 46 – DECORATION ELEMENT ADDER
//  Adds text or shape elements to the DECORATION layer.
//  Types: text, stairs, door, barrier, arrow
// ═══════════════════════════════════════════════════════════════

function addDecorationElement(paramsJSON) {
    var p;
    try { p = eval("(" + paramsJSON + ")"); }
    catch (pe) { return "ERROR:\nCould not parse params: " + pe; }

    try {
        if (app.documents.length === 0) return "ERROR:\nNo document open.";
        var doc = app.activeDocument;
        doc.rulerUnits = RulerUnits.Pixels;

        var dtype = String(p.type || "text").toLowerCase();
        var text  = String(p.text || "");
        var dx    = parseFloat(p.x || 100);
        var dy    = parseFloat(p.y || 100);
        var dw    = parseFloat(p.w || 60);

        var AB_TOP = doc.artboards[0].artboardRect[1];
        function docY(cy) { return AB_TOP - cy; }

        // Find DECORATION group
        var dec = findGroupByName(doc, "DECORATION");
        if (!dec) {
            // Create DECORATION group
            dec = doc.groupItems.add();
            dec.name = "DECORATION";
        }

        var C_LABEL = makeColor(SOP_COLORS.labelText);
        var C_STROKE = makeColor(SOP_COLORS.sectionStroke);
        var C_FILL = makeColor([0.878, 0.878, 0.878]); // #E0E0E0

        if (dtype === "text") {
            if (!text) return "ERROR:\nNo text provided.";
            var tf = dec.textFrames.pointText([dx, docY(dy)]);
            tf.contents = text;
            var attr = tf.textRange.characterAttributes;
            attr.size = 30;
            attr.fillColor = C_LABEL;
            try { attr.textFont = app.textFonts.getByName("ArialMT"); } catch (fe) {}

        } else if (dtype === "stairs") {
            // Draw a staircase icon (stepped rectangle)
            var steps = 4;
            var stepW = dw / steps;
            var stepH = dw / (steps * 2);
            for (var st = 0; st < steps; st++) {
                var sr = dec.pathItems.rectangle(
                    docY(dy + st * stepH), dx + st * stepW,
                    stepW, (steps - st) * stepH
                );
                sr.filled = true; sr.fillColor = C_FILL;
                sr.stroked = true; sr.strokeColor = C_STROKE; sr.strokeWidth = 0.5;
            }
            if (text) {
                var stf = dec.textFrames.pointText([dx, docY(dy + steps * stepH + 5)]);
                stf.contents = text || "STAIRS";
                stf.textRange.characterAttributes.size = 10;
                stf.textRange.characterAttributes.fillColor = C_LABEL;
            }

        } else if (dtype === "door") {
            // Draw a door marker (rectangle with gap indication)
            var dr = dec.pathItems.rectangle(docY(dy), dx, dw, 8);
            dr.filled = true; dr.fillColor = C_FILL;
            dr.stroked = true; dr.strokeColor = C_STROKE; dr.strokeWidth = 0.5;
            if (text) {
                var dtf = dec.textFrames.pointText([dx + 2, docY(dy + 12)]);
                dtf.contents = text || "DOOR";
                dtf.textRange.characterAttributes.size = 8;
                dtf.textRange.characterAttributes.fillColor = C_LABEL;
            }

        } else if (dtype === "barrier") {
            // Draw a barrier line
            var bl = dec.pathItems.add();
            bl.setEntirePath([[dx, docY(dy)], [dx + dw, docY(dy)]]);
            bl.stroked = true; bl.strokeColor = C_STROKE; bl.strokeWidth = 2;
            bl.filled = false;

        } else {
            return "ERROR:\nUnknown decoration type: " + dtype + "\nSupported: text, stairs, door, barrier";
        }

        app.redraw();
        return "\u2705 Decoration element added\n" +
               "Type: " + dtype + "\n" +
               "Position: (" + dx + ", " + dy + ")\n" +
               (text ? "Text: '" + text + "'\n" : "") +
               "Placed in: DECORATION group";
    } catch (e) {
        return "addDecorationElement error:\n" + e + "\n(line " + (e.line || "?") + ")";
    }
}


// ═══════════════════════════════════════════════════════════════
//  SECTION 47 – STANDING / GA ZONE CREATOR
//  Creates a General Admission / Standing area with zone hierarchy
//  and a single bookable seat element (the whole area is one "seat").
// ═══════════════════════════════════════════════════════════════

function createStandingZone(paramsJSON) {
    var p;
    try { p = eval("(" + paramsJSON + ")"); }
    catch (pe) { return "ERROR:\nCould not parse params: " + pe; }

    try {
        if (app.documents.length === 0) return "ERROR:\nNo document open.";
        var doc = app.activeDocument;
        doc.rulerUnits = RulerUnits.Pixels;

        var zone    = String(p.zone || "GA").toUpperCase().replace(/[^A-Z0-9]/g, "");
        var cap     = parseInt(p.cap || "500", 10);
        var shape   = String(p.shape || "rect").toLowerCase();
        var gx      = parseFloat(p.x || 100);
        var gy      = parseFloat(p.y || 100);
        var gw      = parseFloat(p.w || 200);
        var gh      = parseFloat(p.h || 150);
        var fillHex = String(p.fill || "#CCCCCC");
        var fontSize = parseFloat(p.font || 20);

        if (gw < 20 || gh < 20) return "ERROR:\nMinimum size: 20×20px.";

        var AB_TOP = doc.artboards[0].artboardRect[1];
        function docY(cy) { return AB_TOP - cy; }

        // Parse fill colour
        function hexToRGB(hex) {
            hex = hex.replace("#", "");
            var r = parseInt(hex.substring(0, 2), 16) || 204;
            var g = parseInt(hex.substring(2, 4), 16) || 204;
            var b = parseInt(hex.substring(4, 6), 16) || 204;
            var c = new RGBColor(); c.red = r; c.green = g; c.blue = b;
            return c;
        }

        var layer = doc.activeLayer;
        var zoneGrp = layer.groupItems.add();
        zoneGrp.name = "ZONE_" + zone;

        // SECTION (back)
        var secGrp = zoneGrp.groupItems.add();
        secGrp.name = "SECTION";
        secGrp.zOrder(ZOrderMethod.SENDTOBACK);
        var secShape;
        if (shape === "ellipse") {
            secShape = secGrp.pathItems.ellipse(docY(gy), gx, gw, gh);
        } else if (shape === "rounded") {
            secShape = secGrp.pathItems.roundedRectangle(docY(gy), gx, gw, gh, 10, 10);
        } else {
            secShape = secGrp.pathItems.rectangle(docY(gy), gx, gw, gh);
        }
        secShape.filled = true; secShape.fillColor = makeColor(SOP_COLORS.sectionFill);
        secShape.stroked = true; secShape.strokeColor = makeColor(SOP_COLORS.sectionStroke);
        secShape.strokeWidth = 1;

        // UNDERSEATDECORATION (empty)
        var udGrp = zoneGrp.groupItems.add();
        udGrp.name = "UNDERSEATDECORATION";

        // SEAT (single bookable element -- the GA area)
        var seatGrp = zoneGrp.groupItems.add();
        seatGrp.name = "SEAT";
        var gaShape;
        var inset = 4;
        if (shape === "ellipse") {
            gaShape = seatGrp.pathItems.ellipse(
                docY(gy + inset), gx + inset, gw - inset * 2, gh - inset * 2
            );
        } else if (shape === "rounded") {
            gaShape = seatGrp.pathItems.roundedRectangle(
                docY(gy + inset), gx + inset, gw - inset * 2, gh - inset * 2, 8, 8
            );
        } else {
            gaShape = seatGrp.pathItems.rectangle(
                docY(gy + inset), gx + inset, gw - inset * 2, gh - inset * 2
            );
        }
        gaShape.filled = true; gaShape.fillColor = hexToRGB(fillHex);
        gaShape.stroked = false;
        var hash = makeHash(zone, 1, 0);
        gaShape.name = "seatData-" + zone + "-1-1-1-" + hash;

        // SEATDECORATION (empty)
        var sdecGrp = zoneGrp.groupItems.add();
        sdecGrp.name = "SEATDECORATION";

        // SECTIONDECORATION (label)
        var sdGrp = zoneGrp.groupItems.add();
        sdGrp.name = "SECTIONDECORATION";
        var cx = gx + gw / 2;
        var cy_label = docY(gy + gh / 2);
        var txt = sdGrp.textFrames.pointText([cx - zone.length * 4, cy_label + fontSize / 3]);
        txt.contents = zone;
        var attr = txt.textRange.characterAttributes;
        attr.size = fontSize;
        attr.fillColor = makeColor(SOP_COLORS.labelText);
        try { attr.textFont = app.textFonts.getByName("ArialMT"); } catch (fe) {}

        // Add capacity sub-label
        var capTxt = sdGrp.textFrames.pointText([cx - 20, cy_label - fontSize]);
        capTxt.contents = "Cap: " + cap;
        capTxt.textRange.characterAttributes.size = 10;
        capTxt.textRange.characterAttributes.fillColor = makeColor(SOP_COLORS.labelText);

        app.redraw();
        return "\u2705 Standing/GA zone created\n" +
               "Zone: " + zone + " | Capacity: " + cap + "\n" +
               "Shape: " + shape + " | Size: " + gw + "×" + gh + "px\n" +
               "Bookable item: 1 (whole-area GA seat)\n" +
               "ID: seatData-" + zone + "-1-1-1-" + hash + "\n" +
               "Hierarchy: SECTION → UNDERSEATDECO → SEAT → SEATDECO → SECTIONDECO";
    } catch (e) {
        return "createStandingZone error:\n" + e + "\n(line " + (e.line || "?") + ")";
    }
}


// ═══════════════════════════════════════════════════════════════
//  SECTION 48 – ENHANCED CONVERT TO SOP SEATS
//  Replaces selected shapes with 7×7px SOP seats, with zone
//  prefix support and optional ID assignment.
// ═══════════════════════════════════════════════════════════════

function convertToSOPSeats(paramsJSON) {
    var p;
    try { p = eval("(" + paramsJSON + ")"); }
    catch (pe) { return "ERROR:\nCould not parse params: " + pe; }

    try {
        if (app.documents.length === 0) return "ERROR:\nNo document open.";
        var doc = app.activeDocument;
        var sel = doc.selection;
        if (!sel || sel.length === 0)
            return "ERROR:\nSelect shapes to convert first.";

        var zone      = String(p.zone || "").toUpperCase().replace(/[^A-Z0-9]/g, "");
        var startNum  = parseInt(p.start || "1", 10);
        var assignIDs = (p.assignIDs !== false && p.assignIDs !== "false");
        var deleteOrig = (p.deleteOrig !== false && p.deleteOrig !== "false");

        var sCol = makeColor([0.56, 0.78, 1.0]);
        var count = 0;
        var usedH = {};

        // Collect items before modifying
        var items = [];
        for (var i = 0; i < sel.length; i++) items.push(sel[i]);

        // Sort by Y then X for consistent numbering
        items.sort(function (a, b) {
            var ay = a.geometricBounds[1], by = b.geometricBounds[1];
            if (Math.abs(ay - by) > 4) return by - ay;
            return a.geometricBounds[0] - b.geometricBounds[0];
        });

        // Try to find SEAT group
        var targetParent = null;
        if (zone) {
            var zg = findGroupByName(doc, "ZONE_" + zone);
            if (zg && zg.pageItems) {
                for (var zi = 0; zi < zg.pageItems.length; zi++) {
                    if (zg.pageItems[zi].name === "SEAT") {
                        targetParent = zg.pageItems[zi]; break;
                    }
                }
            }
        }
        if (!targetParent) targetParent = findGroupByName(doc, "SEAT");

        for (var j = 0; j < items.length; j++) {
            var item = items[j];
            try {
                var b  = item.geometricBounds;
                var cx = (b[0] + b[2]) / 2;
                var cy = (b[1] + b[3]) / 2;
                var par = targetParent || item.parent;
                var r = par.pathItems.roundedRectangle(cy + 3.5, cx - 3.5, 7, 7, 1.5, 1.5);
                r.filled = true; r.fillColor = sCol; r.stroked = false;

                var seatNum = startNum + count;
                var grp = zone || "TMP";
                var hash = makeHash(grp, seatNum, count);
                while (usedH[hash]) { count++; seatNum++; hash = makeHash(grp, seatNum, count); }
                usedH[hash] = true;
                r.name = "seatData-" + grp + "-" + seatNum + "-" + seatNum + "-1-" + hash;

                if (deleteOrig) item.remove();
                count++;
            } catch (ie) { /* skip unconvertable */ }
        }

        if (count === 0) return "ERROR:\nNo shapes could be converted.";

        var msg = "\u2705 Converted " + count + " shape(s) to 7×7px SOP seats.\n\n";
        if (targetParent) msg += "Placed in: " + (targetParent.name || "SEAT group") + "\n";
        if (assignIDs && zone) {
            msg += "IDs assigned: seatData-" + zone + "-" + startNum + " to -" + (startNum + count - 1) + "\n";
        } else {
            msg += "Temp IDs assigned (seatData-TMP-…)\n";
        }
        msg += (deleteOrig ? "Original shapes deleted." : "Original shapes preserved.");
        return msg;
    } catch (e) {
        return "convertToSOPSeats error:\n" + e + "\n(line " + (e.line || "?") + ")";
    }
}


// ═══════════════════════════════════════════════════════════════
//  SECTION 49 – FULL LAYER HIERARCHY BUILDER
//  Creates complete SOP hierarchy: STAGE, DECORATION, multiple
//  ZONE groups (each with 5 sublayers), and SEATLABELS.
// ═══════════════════════════════════════════════════════════════

function buildFullLayerHierarchy(paramsJSON) {
    var p;
    try { p = eval("(" + paramsJSON + ")"); }
    catch (pe) { return "ERROR:\nCould not parse params: " + pe; }

    try {
        if (app.documents.length === 0) return "ERROR:\nNo document open.";
        var doc = app.activeDocument;
        var layer = doc.layers[0];

        var zoneStr = String(p.zones || "A,B,C");
        var addStage = (p.stage !== false && p.stage !== "false");
        var addSL    = (p.seatlabels !== false && p.seatlabels !== "false");

        var zoneNames = zoneStr.split(",");
        var created = [];

        function ensureGroup(name, parent) {
            if (parent.pageItems) {
                for (var i = 0; i < parent.pageItems.length; i++) {
                    if (parent.pageItems[i].typename === "GroupItem" &&
                        parent.pageItems[i].name === name) {
                        return parent.pageItems[i];
                    }
                }
            }
            var g = parent.groupItems.add();
            g.name = name;
            created.push(name);
            return g;
        }

        // Build from front to back, then reorder

        // SEATLABELS (front)
        if (addSL) {
            var sl = ensureGroup("SEATLABELS", layer);
        }

        // ZONE groups
        var zoneGrps = [];
        for (var z = 0; z < zoneNames.length; z++) {
            var zn = sopTrim(zoneNames[z]).toUpperCase().replace(/[^A-Z0-9]/g, "");
            if (!zn) continue;
            var zoneName = "ZONE_" + zn;
            var zg = ensureGroup(zoneName, layer);
            zoneGrps.push(zg);

            // Create sublayers in order (SECTION at back)
            var sec = ensureGroup("SECTION", zg);
            sec.zOrder(ZOrderMethod.SENDTOBACK);
            ensureGroup("UNDERSEATDECORATION", zg);
            ensureGroup("SEAT", zg);
            ensureGroup("SEATDECORATION", zg);
            ensureGroup("SECTIONDECORATION", zg);
        }

        // DECORATION
        var dec = ensureGroup("DECORATION", layer);
        dec.zOrder(ZOrderMethod.SENDTOBACK);

        // STAGE (very back)
        if (addStage) {
            var stg = ensureGroup("STAGE", layer);
            stg.zOrder(ZOrderMethod.SENDTOBACK);
        }

        // Reorder zones behind SEATLABELS
        for (var zi = zoneGrps.length - 1; zi >= 0; zi--) {
            zoneGrps[zi].zOrder(ZOrderMethod.SENDTOBACK);
        }
        dec.zOrder(ZOrderMethod.SENDTOBACK);
        if (addStage) {
            var stg2 = findGroupByName(layer, "STAGE");
            if (stg2) stg2.zOrder(ZOrderMethod.SENDTOBACK);
        }

        if (created.length === 0) {
            return "\u2705 All SOP groups already exist — nothing to create.";
        }

        var zList = [];
        for (var zi2 = 0; zi2 < zoneNames.length; zi2++) {
            zList.push(sopTrim(zoneNames[zi2]).toUpperCase().replace(/[^A-Z0-9]/g, ""));
        }

        return "\u2705 Full hierarchy built\n" +
               "Created " + created.length + " group(s)\n" +
               "Zones: " + zList.join(", ") + "\n\n" +
               "Z-order (back→front):\n" +
               (addStage ? "  STAGE\n" : "") +
               "  DECORATION\n" +
               "  " + zList.length + " ZONE groups (each with SECTION/UD/SEAT/SDEC/SD)\n" +
               (addSL ? "  SEATLABELS\n" : "") +
               "\nNew groups: " + created.join(", ");
    } catch (e) {
        return "buildFullLayerHierarchy error:\n" + e + "\n(line " + (e.line || "?") + ")";
    }
}


// ═══════════════════════════════════════════════════════════════
//  SECTION 50 – ADD ZONE WITH SUBLAYERS
//  Adds a single zone group with all 5 SOP sublayers.
//  Convenience wrapper around buildSOPHierarchy for quick adds.
// ═══════════════════════════════════════════════════════════════

function addZoneWithSublayers(zoneName) {
    try {
        if (!zoneName) return "ERROR:\nNo zone name provided.";
        zoneName = sopTrim(zoneName).toUpperCase().replace(/[^A-Z0-9]/g, "");
        if (!zoneName) return "ERROR:\nZone name must be alphanumeric.";
        return buildSOPHierarchy(zoneName);
    } catch (e) {
        return "addZoneWithSublayers error:\n" + e + "\n(line " + (e.line || "?") + ")";
    }
}


// ═══════════════════════════════════════════════════════════════
//  SECTION 51 – SEAT SHAPE DETECTOR / TRACER
//  Scans selected objects or the entire document for shapes that
//  look like seats (near 7×7px, arranged in grid/cluster patterns).
//  Reports findings and optionally converts them.
// ═══════════════════════════════════════════════════════════════

function traceSeatPositions(paramsJSON) {
    var p;
    try { p = eval("(" + paramsJSON + ")"); }
    catch (pe) { return "ERROR:\nCould not parse params: " + pe; }

    try {
        if (app.documents.length === 0) return "ERROR:\nNo document open.";
        var doc = app.activeDocument;

        var mode     = String(p.mode || "detect").toLowerCase(); // detect, grid, cluster
        var thresh   = parseFloat(p.thresh || 12);  // max size to consider as seat
        var cluster  = parseFloat(p.cluster || 20); // cluster distance
        var autoConv = (p.autoConvert === true || p.autoConvert === "true");

        // Collect all small shapes
        var candidates = [];
        function scanItems(container) {
            if (!container || !container.pageItems) return;
            for (var i = 0; i < container.pageItems.length; i++) {
                var item = container.pageItems[i];
                if (item.typename === "PathItem" || item.typename === "Rectangle") {
                    // Check if it's seat-sized
                    if (item.width <= thresh && item.height <= thresh &&
                        item.width >= 3 && item.height >= 3) {
                        candidates.push(item);
                    }
                }
                if (item.pageItems) scanItems(item);
            }
        }

        // Scan selection or entire doc
        if (doc.selection && doc.selection.length > 0) {
            for (var si = 0; si < doc.selection.length; si++) {
                var sel = doc.selection[si];
                if (sel.typename === "PathItem" || sel.typename === "Rectangle") {
                    if (sel.width <= thresh && sel.height <= thresh) candidates.push(sel);
                }
                if (sel.pageItems) scanItems(sel);
            }
        } else {
            scanItems(doc);
        }

        if (candidates.length === 0) {
            return "No seat-like shapes found.\n" +
                   "Criteria: width/height <= " + thresh + "px and >= 3px.\n" +
                   "Adjust threshold or select shapes manually.";
        }

        // Analyse grid pattern
        var centers = [];
        for (var ci = 0; ci < candidates.length; ci++) {
            var b = candidates[ci].geometricBounds;
            centers.push({
                item: candidates[ci],
                x: (b[0] + b[2]) / 2,
                y: (b[1] + b[3]) / 2,
                w: candidates[ci].width,
                h: candidates[ci].height
            });
        }

        // Check for 9px grid alignment
        var gridAligned = 0;
        for (var gi = 0; gi < centers.length; gi++) {
            var mx = centers[gi].x % 9;
            var my = centers[gi].y % 9;
            if ((mx < 1 || mx > 8) && (my < 1 || my > 8)) gridAligned++;
        }

        // Size statistics
        var exact7 = 0;
        var avgW = 0, avgH = 0;
        for (var si2 = 0; si2 < centers.length; si2++) {
            avgW += centers[si2].w;
            avgH += centers[si2].h;
            if (Math.abs(centers[si2].w - 7) < 0.5 && Math.abs(centers[si2].h - 7) < 0.5) exact7++;
        }
        avgW /= centers.length;
        avgH /= centers.length;

        // Cluster analysis
        var clusters = 0;
        var visited = {};
        for (var ci2 = 0; ci2 < centers.length; ci2++) {
            if (visited[ci2]) continue;
            clusters++;
            // BFS to find connected cluster
            var queue = [ci2];
            visited[ci2] = true;
            while (queue.length > 0) {
                var cur = queue.shift();
                for (var ni = 0; ni < centers.length; ni++) {
                    if (visited[ni]) continue;
                    var ddx = centers[cur].x - centers[ni].x;
                    var ddy = centers[cur].y - centers[ni].y;
                    if (Math.sqrt(ddx * ddx + ddy * ddy) < cluster) {
                        visited[ni] = true;
                        queue.push(ni);
                    }
                }
            }
        }

        // Auto-convert if requested
        var converted = 0;
        if (autoConv) {
            var sCol = makeColor([0.56, 0.78, 1.0]);
            var usedH = {};
            for (var ai = 0; ai < candidates.length; ai++) {
                try {
                    var it = candidates[ai];
                    if (Math.abs(it.width - 7) > 0.5 || Math.abs(it.height - 7) > 0.5) {
                        var bnd = it.geometricBounds;
                        var ccx = (bnd[0] + bnd[2]) / 2;
                        var ccy = (bnd[1] + bnd[3]) / 2;
                        it.width = 7; it.height = 7;
                        var b2 = it.geometricBounds;
                        it.translate(ccx - (b2[0] + b2[2]) / 2, ccy - (b2[1] + b2[3]) / 2);
                        converted++;
                    }
                    it.filled = true; it.fillColor = sCol; it.stroked = false;
                    if (it.name.indexOf("seatData-") !== 0) {
                        var hash = makeHash("TMP", ai, ai);
                        while (usedH[hash]) { hash = makeHash("TMP", ai, ai + converted + 99); }
                        usedH[hash] = true;
                        it.name = "seatData-TMP-" + (ai + 1) + "-" + (ai + 1) + "-1-" + hash;
                    }
                } catch (ce) {}
            }
        }

        app.redraw();
        return "\u2705 Seat Shape Trace complete\n" +
               "Candidates found: " + candidates.length + "\n" +
               "Already 7×7px: " + exact7 + "\n" +
               "Avg size: " + avgW.toFixed(1) + "×" + avgH.toFixed(1) + "px\n" +
               "Grid-aligned (9px): " + gridAligned + " (" + Math.round(gridAligned / candidates.length * 100) + "%)\n" +
               "Clusters detected: " + clusters + "\n" +
               (autoConv ? "Auto-converted: " + converted + " resized to 7×7\n" : "") +
               "\nNext: select converted seats → Generate Seat IDs with correct GROUP.";
    } catch (e) {
        return "traceSeatPositions error:\n" + e + "\n(line " + (e.line || "?") + ")";
    }
}


// ═══════════════════════════════════════════════════════════════
//  SECTION 52 – SNAP TO 9PX GRID
//  Snaps all seat elements to the nearest 9px grid position.
//  Preserves the relative layout but aligns to SOP §5.3 grid.
// ═══════════════════════════════════════════════════════════════

function snapToGrid() {
    try {
        if (app.documents.length === 0) return "ERROR:\nNo document open.";
        var doc = app.activeDocument;
        var seats = [];
        collectSeats(doc, seats);

        if (seats.length === 0) return "ERROR:\nNo seatData-* elements found.";

        var GRID = 9;
        var snapped = 0;

        for (var i = 0; i < seats.length; i++) {
            var s = seats[i];
            try {
                var b = s.geometricBounds; // [left, top, right, bottom]
                var cx = (b[0] + b[2]) / 2;
                var cy = (b[1] + b[3]) / 2;

                // Snap center to nearest grid
                var snapX = Math.round(cx / GRID) * GRID;
                var snapY = Math.round(cy / GRID) * GRID;

                var dx = snapX - cx;
                var dy = snapY - cy;

                if (Math.abs(dx) > 0.1 || Math.abs(dy) > 0.1) {
                    s.translate(dx, dy);
                    snapped++;
                }
            } catch (se) { /* skip items that can't be moved */ }
        }

        app.redraw();
        if (snapped === 0) {
            return "\u2705 All " + seats.length + " seats already on 9px grid — nothing moved.";
        }
        return "\u2705 Snapped " + snapped + " of " + seats.length + " seat(s) to 9px grid.\n" +
               "Grid spacing: " + GRID + "px\n" +
               "Re-run Validate Geometry to confirm alignment.";
    } catch (e) {
        return "snapToGrid error:\n" + e + "\n(line " + (e.line || "?") + ")";
    }
}


/* ═══════════════════════════════════════════════════════════════════════
   §53 — CMYK-Safe Color Helper  (NEW v4.0 — BUILD tab)
   ═══════════════════════════════════════════════════════════════════════ */
function makeColorSafe(r, g, b) {
    // FIX 13: Clamp inputs and CMYK channels to valid range [0..255 / 0..100].
    // Floating-point math could produce 100.0000001 which throws in Illustrator.
    r = Math.max(0, Math.min(255, Math.round(r)));
    g = Math.max(0, Math.min(255, Math.round(g)));
    b = Math.max(0, Math.min(255, Math.round(b)));

    try {
        var doc = app.activeDocument;
        if (doc.documentColorSpace === DocumentColorSpace.CMYK) {
            var rr = r / 255, gg = g / 255, bb = b / 255;
            var k = 1 - Math.max(rr, gg, bb);
            var cmyk = new CMYKColor();
            if (k >= 1) {
                cmyk.cyan = 0; cmyk.magenta = 0; cmyk.yellow = 0; cmyk.black = 100;
            } else {
                var denom = 1 - k;
                cmyk.cyan    = Math.max(0, Math.min(100, (1 - rr - k) / denom * 100));
                cmyk.magenta = Math.max(0, Math.min(100, (1 - gg - k) / denom * 100));
                cmyk.yellow  = Math.max(0, Math.min(100, (1 - bb - k) / denom * 100));
                cmyk.black   = Math.max(0, Math.min(100, k * 100));
            }
            return cmyk;
        }
    } catch (e) {
        // No active document or other error - fall through to RGB
    }
    var c = new RGBColor();
    c.red = r; c.green = g; c.blue = b;
    return c;
}


/* ═══════════════════════════════════════════════════════════════════════
   §54 — buildLayerHierarchy (PL-01 enhanced)  (NEW v4.0 — BUILD tab)
   Creates the SOP layer hierarchy using actual AI layers.
   ═══════════════════════════════════════════════════════════════════════ */
function buildLayerHierarchy(paramsJSON) {
    try {
        var p = eval("(" + paramsJSON + ")");
        var doc = app.activeDocument;
        var zoneCount = parseInt(p.zoneCount) || 4;
        var prefix = p.prefix || "ZONE_";
        var clearExisting = !!p.clearExisting;
        var includeStage = (p.includeStage !== false);
        var includeSeatlabels = (p.includeSeatlabels !== false);

        if (clearExisting) {
            while (doc.layers.length > 1) {
                doc.layers[doc.layers.length - 1].remove();
            }
            doc.layers[0].name = "Layer 1";
        }

        // SEATLABELS (topmost — created first so it ends up on top)
        if (includeSeatlabels) {
            try { doc.layers.getByName("SEATLABELS"); }
            catch (e) {
                var slLayer = doc.layers.add();
                slLayer.name = "SEATLABELS";
            }
        }

        // Zone layers — create in reverse order so ZONE_1 ends up above ZONE_N
        // v6.3: canonical SOP names; legacy numeric suffixes are input only.
        var sublayers = ["SECTIONDECORATION", "SEATDECORATION", "SEAT", "UNDERSEATDECORATION", "SECTION"];
        for (var z = zoneCount; z >= 1; z--) {
            var zoneName = prefix + z;
            var zoneLayer;
            try { zoneLayer = doc.layers.getByName(zoneName); }
            catch (e) {
                zoneLayer = doc.layers.add();
                zoneLayer.name = zoneName;
            }
            // Add sublayers in reverse so SECTION ends up at bottom within zone
            for (var s = 0; s < sublayers.length; s++) {
                var subName = sublayers[s];
                var found = false;
                for (var si = 0; si < zoneLayer.layers.length; si++) {
                    if (zoneLayer.layers[si].name === subName) { found = true; break; }
                }
                if (!found) {
                    var sub = zoneLayer.layers.add();
                    sub.name = subName;
                }
            }
        }

        // DECORATION layer
        if (includeStage) {
            try { doc.layers.getByName("DECORATION"); }
            catch (e) {
                var decoLayer = doc.layers.add();
                decoLayer.name = "DECORATION";
                decoLayer.move(doc, ElementPlacement.PLACEATEND);
            }

            // STAGE layer (bottommost)
            try { doc.layers.getByName("STAGE"); }
            catch (e) {
                var stgLayer = doc.layers.add();
                stgLayer.name = "STAGE";
                stgLayer.move(doc, ElementPlacement.PLACEATEND);
            }
        }

        // Clean up default "Layer 1" if it's empty
        try {
            var l1 = doc.layers.getByName("Layer 1");
            if (l1.pageItems.length === 0 && l1.layers.length === 0) l1.remove();
        } catch (e) { /* not found, fine */ }

        app.redraw();
        return "\u2705 Layer hierarchy built!\n" +
               zoneCount + " zone layers (prefix: " + prefix + ")\n" +
               "Sublayers per zone: SECTION, UNDERSEATDECORATION, SEAT, SEATDECORATION, SECTIONDECORATION\n" +
               (includeStage ? "STAGE + DECORATION layers created\n" : "") +
               (includeSeatlabels ? "SEATLABELS (empty, topmost)" : "");
    } catch (e) {
        return "buildLayerHierarchy error:\n" + e + "\n(line " + (e.line || "?") + ")";
    }
}


/* ═══════════════════════════════════════════════════════════════════════
   §55 — addZoneLayer (quick-add single zone)  (NEW v4.0 — BUILD tab)
   ═══════════════════════════════════════════════════════════════════════ */
function addZoneLayer(zoneName) {
    try {
        var doc = app.activeDocument;
        var zoneLayer;
        try { zoneLayer = doc.layers.getByName(zoneName); }
        catch (e) {
            zoneLayer = doc.layers.add();
            zoneLayer.name = zoneName;
        }
        var sublayers = ["SECTIONDECORATION", "SEATDECORATION", "SEAT", "UNDERSEATDECORATION", "SECTION"];
        for (var s = 0; s < sublayers.length; s++) {
            var subName = sublayers[s];
            var found = false;
            for (var si = 0; si < zoneLayer.layers.length; si++) {
                if (zoneLayer.layers[si].name === subName) { found = true; break; }
            }
            if (!found) {
                var sub = zoneLayer.layers.add();
                sub.name = subName;
            }
        }
        app.redraw();
        return "\u2705 Zone layer '" + zoneName + "' added with 5 sublayers.";
    } catch (e) {
        return "addZoneLayer error:\n" + e + "\n(line " + (e.line || "?") + ")";
    }
}


/* ═══════════════════════════════════════════════════════════════════════
   §56 — buildStagePlus (PL-02 enhanced)  (NEW v4.0 — BUILD tab)
   CMYK-safe stage builder with rounded corner variants.
   ═══════════════════════════════════════════════════════════════════════ */
function buildStagePlus(paramsJSON) {
    return buildStage(paramsJSON);
}


/* ═══════════════════════════════════════════════════════════════════════
   §57 — generateSingleID (PL-07 single mode)  (NEW v4.0 — BUILD tab)
   Returns a single seatData ID string.
   ═══════════════════════════════════════════════════════════════════════ */
function generateSingleID(group, seatNum) {
    try {
        var hash = makeHash(group, seatNum, 0);
        var id = "seatData-" + group + "-" + seatNum + "-" + seatNum + "-1-" + hash;
        return "\u2705 Generated ID:\n" + id;
    } catch (e) {
        return "generateSingleID error:\n" + e;
    }
}


/* ═══════════════════════════════════════════════════════════════════════
   §58 — generateBatchIDs (PL-07 batch mode)  (NEW v4.0 — BUILD tab)
   Generates a range of seatData IDs and returns them as text.
   ═══════════════════════════════════════════════════════════════════════ */
function generateBatchIDs(paramsJSON) {
    try {
        var p = eval("(" + paramsJSON + ")");
        var group = p.group || "VIPA";
        var from = parseInt(p.from) || 1;
        var to = parseInt(p.to) || 20;
        var lines = [];
        for (var i = from; i <= to; i++) {
            var hash = makeHash(group, i, 0);
            lines.push("seatData-" + group + "-" + i + "-" + i + "-1-" + hash);
        }
        return "\u2705 Generated " + lines.length + " IDs (" + group + " #" + from + "-" + to + "):\n\n" +
               lines.join("\n");
    } catch (e) {
        return "generateBatchIDs error:\n" + e;
    }
}


/* ═══════════════════════════════════════════════════════════════════════
   §59 — applyBatchIDsToSelection (PL-07 apply-to-sel)  (NEW v4.0)
   Applies batch IDs to selected seat elements sorted by position.
   ═══════════════════════════════════════════════════════════════════════ */
function applyBatchIDsToSelection(paramsJSON) {
    try {
        var p = eval("(" + paramsJSON + ")");
        var doc = app.activeDocument;
        var group = p.group || "VIPA";
        var from = parseInt(p.from) || 1;
        var to = parseInt(p.to) || 20;

        var sel = doc.selection;
        if (!sel || sel.length === 0) {
            return "\u26A0 No selection. Select seats first.";
        }

        // Collect valid items
        var items = [];
        for (var i = 0; i < sel.length; i++) {
            var it = sel[i];
            if (it.typename === "PathItem" || it.typename === "Rectangle" ||
                it.typename === "GroupItem") {
                items.push(it);
            }
        }

        if (items.length === 0) {
            return "\u26A0 No valid path/rect items in selection.";
        }

        // Sort top-to-bottom, left-to-right
        items.sort(function(a, b) {
            var ay = -(a.top || 0), by = -(b.top || 0);
            if (Math.abs(ay - by) > 4) return ay - by;
            return (a.left || 0) - (b.left || 0);
        });

        var count = Math.min(items.length, to - from + 1);
        var applied = 0;
        for (var j = 0; j < count; j++) {
            var seatNum = from + j;
            var hash = makeHash(group, seatNum, 0);
            items[j].name = "seatData-" + group + "-" + seatNum + "-" + seatNum + "-1-" + hash;
            applied++;
        }

        app.redraw();
        return "\u2705 Applied " + applied + " IDs to selection.\n" +
               "GROUP: " + group + " | Range: " + from + "-" + (from + applied - 1) + "\n" +
               "Sort: top\u2192bottom, left\u2192right";
    } catch (e) {
        return "applyBatchIDsToSelection error:\n" + e + "\n(line " + (e.line || "?") + ")";
    }
}


/* ═══════════════════════════════════════════════════════════════════════
   §60 — assignIDsToSelection (PL-07 selection mode)  (NEW v4.0)
   Assigns sequential seatData IDs to selected items with sort options.
   ═══════════════════════════════════════════════════════════════════════ */
function assignIDsToSelection(paramsJSON) {
    try {
        var p = eval("(" + paramsJSON + ")");
        var doc = app.activeDocument;
        var group = p.group || "VIPA";
        var startSeat = parseInt(p.startSeat) || 1;
        var sortOrder = p.sortOrder || "topdown";

        var sel = doc.selection;
        if (!sel || sel.length === 0) {
            return "\u26A0 No selection. Select seats/shapes first.";
        }

        var items = [];
        for (var i = 0; i < sel.length; i++) {
            var it = sel[i];
            if (it.typename === "PathItem" || it.typename === "Rectangle" ||
                it.typename === "GroupItem") {
                items.push(it);
            }
        }

        if (items.length === 0) {
            return "\u26A0 No valid path/rect items in selection.";
        }

        // Sort based on chosen order
        if (sortOrder === "topdown") {
            items.sort(function(a, b) {
                var ay = -(a.top || 0), by = -(b.top || 0);
                if (Math.abs(ay - by) > 4) return ay - by;
                return (a.left || 0) - (b.left || 0);
            });
        } else if (sortOrder === "leftright") {
            items.sort(function(a, b) {
                var ax = (a.left || 0), bx = (b.left || 0);
                if (Math.abs(ax - bx) > 4) return ax - bx;
                return -(a.top || 0) - (-(b.top || 0));
            });
        }
        // "asis" = no sort

        var applied = 0;
        for (var j = 0; j < items.length; j++) {
            var seatNum = startSeat + j;
            var hash = makeHash(group, seatNum, 0);
            items[j].name = "seatData-" + group + "-" + seatNum + "-" + seatNum + "-1-" + hash;
            applied++;
        }

        app.redraw();
        return "\u2705 Assigned " + applied + " IDs to selection.\n" +
               "GROUP: " + group + " | Start: " + startSeat + " | Sort: " + sortOrder;
    } catch (e) {
        return "assignIDsToSelection error:\n" + e + "\n(line " + (e.line || "?") + ")";
    }
}


/* ═══════════════════════════════════════════════════════════════════════
   §61 — saveAllIDsToFile (PL-07 save mode)  (NEW v4.0 — BUILD tab)
   Saves all seatData IDs in the document to a text file.
   ═══════════════════════════════════════════════════════════════════════ */
function saveAllIDsToFile() {
    try {
        var doc = app.activeDocument;
        var seats = [];
        collectSeats(doc, seats);

        if (seats.length === 0) {
            return "\u26A0 No seats found in document.";
        }

        // Sort by ID for readability
        seats.sort(function(a, b) {
            return a.name < b.name ? -1 : a.name > b.name ? 1 : 0;
        });

        var lines = [];
        for (var i = 0; i < seats.length; i++) {
            lines.push(seats[i].name);
        }

        // Save next to document
        var docPath;
        try { docPath = doc.path; } catch (e) { docPath = Folder.desktop; }
        var savePath = new File(docPath + "/" + doc.name.replace(/\.[^.]+$/, "") + "_seat_ids.txt");

        var f = new File(savePath);
        f.open("w");
        f.write(lines.join("\n"));
        f.close();

        return "\u2705 Saved " + lines.length + " seat IDs to:\n" + savePath.fsName;
    } catch (e) {
        return "saveAllIDsToFile error:\n" + e + "\n(line " + (e.line || "?") + ")";
    }
}


/* ═══════════════════════════════════════════════════════════════════════
   §62 — bulkRenameGroupPrefix (PL-09 enhanced)  (NEW v4.0 — BUILD tab)
   Bulk rename with scope selector, preview mode, and hash regeneration.
   ═══════════════════════════════════════════════════════════════════════ */
function bulkRenameGroupPrefix(paramsJSON) {
    try {
        var p = eval("(" + paramsJSON + ")");
        var doc = app.activeDocument;
        var oldPrefix = (p.oldPrefix || "").toUpperCase();
        var newPrefix = (p.newPrefix || "").toUpperCase();
        var scope = p.scope || "prefix";
        var regenHash = (p.regenHash !== false);
        var preview = !!p.preview;

        if (!newPrefix) {
            return "\u26A0 Enter a new GROUP prefix.";
        }

        // Collect target seats based on scope
        var targets = [];

        if (scope === "selected") {
            var sel = doc.selection;
            if (!sel || sel.length === 0) {
                return "\u26A0 No selection. Select seats first.";
            }
            for (var s = 0; s < sel.length; s++) {
                if (sel[s].name && sel[s].name.indexOf("seatData-") === 0) {
                    targets.push(sel[s]);
                }
            }
        } else {
            var allSeats = [];
            collectSeats(doc, allSeats);
            for (var i = 0; i < allSeats.length; i++) {
                if (scope === "all") {
                    targets.push(allSeats[i]);
                } else if (scope === "prefix" && oldPrefix) {
                    var parts = allSeats[i].name.split("-");
                    if (parts.length >= 6 && parts[1].indexOf(oldPrefix) === 0) {
                        targets.push(allSeats[i]);
                    }
                }
            }
        }

        if (targets.length === 0) {
            return "\u26A0 No matching seats found.\n" +
                   "Scope: " + scope + (oldPrefix ? " | Old prefix: " + oldPrefix : "");
        }

        // Preview mode — show what would change
        if (preview) {
            var previewLines = ["PREVIEW \u2014 " + targets.length + " seats will be renamed:\n"];
            var maxShow = Math.min(targets.length, 15);
            for (var j = 0; j < maxShow; j++) {
                var tp = targets[j].name.split("-");
                var oldGroup = tp[1] || "";
                var rowPart = (scope === "all") ? "" : oldGroup.substring(oldPrefix.length);
                var newGroup = newPrefix + rowPart;
                previewLines.push("  " + oldGroup + " \u2192 " + newGroup);
            }
            if (targets.length > maxShow) {
                previewLines.push("  ... and " + (targets.length - maxShow) + " more");
            }
            previewLines.push("\nUncheck 'Preview' and run again to apply.");
            return previewLines.join("\n");
        }

        // Apply renames
        var renamed = 0;
        for (var k = 0; k < targets.length; k++) {
            var parts = targets[k].name.split("-");
            if (parts.length < 6) continue;

            var oldGroup = parts[1];
            var rowPart = (scope === "all") ? "" : oldGroup.substring(oldPrefix.length);
            var newGroup = newPrefix + rowPart;

            parts[1] = newGroup;

            if (regenHash) {
                var seatNum = parseInt(parts[2]) || 1;
                parts[5] = makeHash(newGroup, seatNum, k);
            }

            targets[k].name = parts.join("-");
            renamed++;
        }

        app.redraw();
        return "\u2705 Renamed " + renamed + " seats.\n" +
               "Scope: " + scope + "\n" +
               (oldPrefix ? "Old prefix: " + oldPrefix + "\n" : "") +
               "New prefix: " + newPrefix + "\n" +
               (regenHash ? "Hashes regenerated." : "Hashes preserved.");
    } catch (e) {
        return "bulkRenameGroupPrefix error:\n" + e + "\n(line " + (e.line || "?") + ")";
    }
}


/* ═══════════════════════════════════════════════════════════════════════
   §63 — buildCategoryMap (PL-12 enhanced)  (NEW v4.0 — BUILD tab)
   Multi-line category input, 4 layout modes, custom sizing, CMYK-safe.
   ═══════════════════════════════════════════════════════════════════════ */
function buildCategoryMap(paramsJSON) {
    try {
        var p = eval("(" + paramsJSON + ")");
        var doc = app.activeDocument;
        var catText = p.categories || "";
        var layout = p.layout || "horizontal";
        var boxW = parseFloat(p.boxWidth) || 200;
        var boxH = parseFloat(p.boxHeight) || 80;
        var spacing = parseFloat(p.spacing) || 20;
        var stageH = parseFloat(p.stageHeight) || 60;
        var showPrices = (p.showPrices !== false);

        // Parse categories from multi-line text (NAME | PRICE)
        var lines = catText.split("\n");
        var categories = [];
        for (var i = 0; i < lines.length; i++) {
            var line = lines[i].replace(/^\s+|\s+$/g, "");
            if (line.length === 0) continue;
            var pipe = line.split("|");
            var name = pipe[0].replace(/^\s+|\s+$/g, "");
            var price = pipe.length > 1 ? pipe[1].replace(/^\s+|\s+$/g, "") : "";
            if (name) categories.push({ name: name, price: price });
        }

        if (categories.length === 0) {
            return "\u26A0 No categories parsed. Enter NAME | PRICE per line.";
        }

        // Determine grid columns based on layout
        var cols = categories.length; // horizontal default
        if (layout === "vertical") cols = 1;
        else if (layout === "grid2") cols = 2;
        else if (layout === "grid3") cols = 3;

        var rows = Math.ceil(categories.length / cols);

        // Calculate total dimensions
        var totalW = cols * boxW + (cols - 1) * spacing;
        var totalH = rows * boxH + (rows - 1) * spacing + stageH + spacing;

        // Centre on 1150x950 canvas (AI Y-up: top = positive)
        var startX = (1150 - totalW) / 2;
        var startY = -(950 - stageH - spacing); // negative for AI coords

        var layer = doc.activeLayer;
        var created = 0;

        for (var c = 0; c < categories.length; c++) {
            var col = c % cols;
            var row = Math.floor(c / cols);

            var bx = startX + col * (boxW + spacing);
            var by = startY + row * (boxH + spacing); // going down in AI = more negative

            // White box with #D1D2D4 stroke, 3pt rounded corners
            var box = layer.pathItems.roundedRectangle(
                -by, bx, boxW, boxH, 3, 3
            );
            box.fillColor = makeColorSafe(255, 255, 255);
            box.stroked = true;
            box.strokeColor = makeColorSafe(209, 210, 212);
            box.strokeWidth = 1;
            box.name = "cat_box_" + categories[c].name.replace(/\s/g, "_");

            // Category name text (18px, centred)
            var nameText = layer.textFrames.add();
            nameText.contents = categories[c].name.toUpperCase();
            var nameCA = nameText.textRange.characterAttributes;
            nameCA.fillColor = makeColorSafe(109,110,112);
            nameCA.size = 18;
            nameCA.stroked = false;
            try { nameCA.textFont = app.textFonts.getByName("ProximaNova-Regular"); }
            catch (e) { try { nameCA.textFont = app.textFonts.getByName("ArialMT"); } catch (e2) {} }

            var nw = nameText.width;
            var nameY = -by - (boxH / 2) + 8;
            if (showPrices && categories[c].price) nameY = -by - (boxH / 3);
            nameText.position = [bx + (boxW - nw) / 2, nameY];
            nameText.name = "cat_name_" + (c + 1);

            // Price text (12px, centred below name)
            if (showPrices && categories[c].price) {
                var priceText = layer.textFrames.add();
                priceText.contents = categories[c].price.toUpperCase();
                var priceCA = priceText.textRange.characterAttributes;
                priceCA.fillColor = makeColorSafe(109,110,112);
                priceCA.size = 12;
                priceCA.stroked = false;
                try { priceCA.textFont = app.textFonts.getByName("ProximaNova-Regular"); }
                catch (e) { try { priceCA.textFont = app.textFonts.getByName("ArialMT"); } catch (e2) {} }

                var pw = priceText.width;
                priceText.position = [bx + (boxW - pw) / 2, nameY - 22];
                priceText.name = "cat_price_" + (c + 1);
            }

            created++;
        }

        // Stage box at bottom (30% larger per SOP §11)
        var stageW = totalW * 0.6;
        var stageX = startX + (totalW - stageW) / 2;
        var stageTopY = startY + rows * (boxH + spacing);

        var stageBox = layer.pathItems.roundedRectangle(
            -stageTopY, stageX, stageW, stageH, 3, 3
        );
        stageBox.fillColor = makeColorSafe(224, 224, 224);
        stageBox.stroked = true;
        stageBox.strokeColor = makeColorSafe(204, 204, 204);
        stageBox.strokeWidth = 1;
        stageBox.name = "stage_box";

        // Stage label
        var stageTxt = layer.textFrames.add();
        stageTxt.contents = "STAGE";
        var stgCA = stageTxt.textRange.characterAttributes;
        stgCA.fillColor = makeColorSafe(109,110,112);
        stgCA.size = 18;
        stgCA.stroked = false;
        try { stgCA.textFont = app.textFonts.getByName("ProximaNova-Regular"); }
        catch (e) { try { stgCA.textFont = app.textFonts.getByName("ArialMT"); } catch (e2) {} }
        var stw = stageTxt.width;
        stageTxt.position = [stageX + (stageW - stw) / 2, -stageTopY - (stageH / 2) + 8];
        stageTxt.name = "stage_label";

        app.redraw();
        return "\u2705 Category map created!\n\n" +
               created + " category boxes + stage\n" +
               "Layout: " + layout + " (" + cols + " cols x " + rows + " rows)\n" +
               "Box size: " + boxW + "x" + boxH + "px | Spacing: " + spacing + "px\n\n" +
               "SOP \u00A711 Reminders:\n" +
               "  \u2022 All boxes must be same colour (white)\n" +
               "  \u2022 Export as JPEG: 950px wide, bg #F1F1F2\n" +
               "  \u2022 Stage at bottom, numbered L\u2192R from stage";
    } catch (e) {
        return "buildCategoryMap error:\n" + e + "\n(line " + (e.line || "?") + ")";
    }
}


/* ═══════════════════════════════════════════════════════════════════════
   §64 — fixAllSOP (Enhanced 50+ op recovery)  (Ultimate v6.1)
   ═══════════════════════════════════════════════════════════════════════ */
function fixAllSOP() {
    var results = [];
    var ops = [
        ["fixSubLayerNames",             fixSubLayerNames],
        ["addSEATLABELS",                addSEATLABELS],
        ["fixSectionFills",              fixSectionFills],
        ["fixSectionStrokes",            fixSectionStrokes],
        ["fixSeatStrokes",               fixSeatStrokes],
        ["fixSeatOpacity",               fixSeatOpacity],
        ["fixSeatSizes",                 fixSeatSizes],
        ["fixRxRy",                      fixRxRy],
        ["fixLabelColors",               fixLabelColors],
        ["fixTextStrokes",               fixTextStrokes],
        ["fixStageGroup",                fixStageGroup],
        ["fixStageFill",                 fixStageFill],
        ["fixStageLabel",                fixStageLabel],
        ["fixDecorBadgeFills",           fixDecorBadgeFills],
        ["fixSectionDecorationNesting",  fixSectionDecorationNesting],
        ["fixSeatDataCase",              fixSeatDataCase],
        ["fixSeatFieldMismatch",         fixSeatFieldMismatch],
        ["fixField4",                    fixField4],
        ["fixGroupHyphens",              fixGroupHyphens],
        ["fixHashSpaces",                fixHashSpaces],
        ["fixDuplicateHashes",           fixDuplicateHashes],
        ["fixMalformedIDs",              fixMalformedIDs],
        ["autoFixSeatIDs",               autoFixSeatIDs],
        ["removeAllForbidden",           removeAllForbidden],
        ["cleanHiddenLayers",            cleanHiddenLayers],
        ["cleanEmptyGroups",             cleanEmptyGroups]
    ];
    for (var i = 0; i < ops.length; i++) {
        try { results.push(ops[i][0] + ": " + ops[i][1]()); }
        catch (e) { results.push(ops[i][0] + ": ERROR - " + e); }
    }
    return "=== Full Recovery Complete (" + ops.length + " operations) ===\n\n" + results.join("\n---\n");
}


/* ═══════════════════════════════════════════════════════════════════════
   §65 — fixAllColors / fixAllIDs / fixAllStructure  (Quick combo fixes)
   ═══════════════════════════════════════════════════════════════════════ */
function fixAllColors() {
    var r = [];
    try { r.push(fixSectionFills()); } catch(e) { r.push("ERR: " + e); }
    try { r.push(fixSectionStrokes()); } catch(e) { r.push("ERR: " + e); }
    try { r.push(fixSeatStrokes()); } catch(e) { r.push("ERR: " + e); }
    try { r.push(fixSeatOpacity()); } catch(e) { r.push("ERR: " + e); }
    try { r.push(fixLabelColors()); } catch(e) { r.push("ERR: " + e); }
    try { r.push(fixTextStrokes()); } catch(e) { r.push("ERR: " + e); }
    try { r.push(fixDecorBadgeFills()); } catch(e) { r.push("ERR: " + e); }
    try { r.push(fixStageFill()); } catch(e) { r.push("ERR: " + e); }
    return "=== Fix All Colors Complete ===\n" + r.join("\n");
}

function fixAllIDs() {
    var r = [];
    try { r.push(fixSeatDataCase()); } catch(e) { r.push("ERR: " + e); }
    try { r.push(fixSeatFieldMismatch()); } catch(e) { r.push("ERR: " + e); }
    try { r.push(fixField4()); } catch(e) { r.push("ERR: " + e); }
    try { r.push(fixGroupHyphens()); } catch(e) { r.push("ERR: " + e); }
    try { r.push(fixHashSpaces()); } catch(e) { r.push("ERR: " + e); }
    try { r.push(fixDuplicateHashes()); } catch(e) { r.push("ERR: " + e); }
    try { r.push(fixMalformedIDs()); } catch(e) { r.push("ERR: " + e); }
    try { r.push(autoFixSeatIDs()); } catch(e) { r.push("ERR: " + e); }
    return "=== Fix All IDs Complete ===\n" + r.join("\n");
}

function fixAllStructure() {
    var r = [];
    try { r.push(fixSubLayerNames()); } catch(e) { r.push("ERR: " + e); }
    try { r.push(fixSectionDecorationNesting()); } catch(e) { r.push("ERR: " + e); }
    try { r.push(addSEATLABELS()); } catch(e) { r.push("ERR: " + e); }
    try { r.push(fixStageGroup()); } catch(e) { r.push("ERR: " + e); }
    try { r.push(cleanHiddenLayers()); } catch(e) { r.push("ERR: " + e); }
    try { r.push(cleanEmptyGroups()); } catch(e) { r.push("ERR: " + e); }
    return "=== Fix All Structure Complete ===\n" + r.join("\n");
}


/* ═══════════════════════════════════════════════════════════════════════
   §66 — Individual colour/fill fixes  (NEW v4.0 — FIX > Colours)
   ═══════════════════════════════════════════════════════════════════════ */
function fixSectionStrokes() {
    try {
        var doc = app.activeDocument;
        var fixed = 0;
        function scan(obj) {
            if (!obj) return;
            if ((obj.typename === "GroupItem" || obj.typename === "Layer") &&
                obj.name && obj.name.indexOf("SECTION") === 0 && obj.name.indexOf("SECTIONDECORATION") !== 0) {
                for (var i = 0; i < obj.pageItems.length; i++) {
                    var it = obj.pageItems[i];
                    if (it.typename === "PathItem" || it.typename === "CompoundPathItem") {
                        var pi = (it.typename === "CompoundPathItem") ? it.pathItems[0] : it;
                        pi.stroked = true;
                        pi.strokeColor = makeColorSafe(209,210,212);
                        pi.strokeWidth = 1;
                        fixed++;
                    }
                }
            }
            if (obj.pageItems) for (var j = 0; j < obj.pageItems.length; j++) scan(obj.pageItems[j]);
            if (obj.layers) for (var k = 0; k < obj.layers.length; k++) scan(obj.layers[k]);
        }
        scan(doc);
        app.redraw();
        return "\u2705 Fixed " + fixed + " section strokes \u2192 #D1D2D4 1px.";
    } catch(e) { return "fixSectionStrokes error: " + e; }
}

function fixSeatOpacity() {
    try {
        var doc = app.activeDocument;
        var seats = []; collectSeats(doc, seats);
        var fixed = 0;
        for (var i = 0; i < seats.length; i++) {
            if (seats[i].opacity !== 100) { seats[i].opacity = 100; fixed++; }
        }
        return "\u2705 Fixed " + fixed + " seat opacity \u2192 100%.";
    } catch(e) { return "fixSeatOpacity error: " + e; }
}

function fixTextStrokes() {
    try {
        var doc = app.activeDocument;
        var fixed = 0;
        function scan(obj) {
            if (!obj) return;
            if (obj.typename === "TextFrame") {
                var ca = obj.textRange.characterAttributes;
                if (ca.stroked) { ca.stroked = false; fixed++; }
            }
            if (obj.pageItems) for (var i = 0; i < obj.pageItems.length; i++) scan(obj.pageItems[i]);
            if (obj.layers) for (var j = 0; j < obj.layers.length; j++) scan(obj.layers[j]);
        }
        scan(doc);
        return "\u2705 Removed strokes from " + fixed + " text elements.";
    } catch(e) { return "fixTextStrokes error: " + e; }
}

function fixDecorBadgeFills() {
    try {
        var doc = app.activeDocument;
        var fixed = 0;
        function scan(obj) {
            if (!obj) return;
            if ((obj.typename === "GroupItem" || obj.typename === "Layer") &&
                obj.name && obj.name.indexOf("SECTIONDECORATION") === 0) {
                for (var i = 0; i < obj.pageItems.length; i++) {
                    var it = obj.pageItems[i];
                    if (it.typename === "PathItem") {
                        it.fillColor = makeColorSafe(255, 255, 255);
                        it.stroked = true;
                        it.strokeColor = makeColorSafe(209,210,212);
                        it.strokeWidth = 1;
                        fixed++;
                    }
                }
            }
            if (obj.pageItems) for (var j = 0; j < obj.pageItems.length; j++) scan(obj.pageItems[j]);
            if (obj.layers) for (var k = 0; k < obj.layers.length; k++) scan(obj.layers[k]);
        }
        scan(doc);
        return "\u2705 Fixed " + fixed + " decoration badge fills.";
    } catch(e) { return "fixDecorBadgeFills error: " + e; }
}

function cleanCanvasBackground() {
    try {
        var doc = app.activeDocument;
        var removed = 0;
        // Look for very large rectangles that might be background fills
        for (var i = doc.pathItems.length - 1; i >= 0; i--) {
            var p = doc.pathItems[i];
            if (p.width > 1000 && p.height > 800 && !p.name) {
                p.remove(); removed++;
            }
        }
        return "\u2705 Removed " + removed + " potential canvas background objects.";
    } catch(e) { return "cleanCanvasBackground error: " + e; }
}


/* ═══════════════════════════════════════════════════════════════════════
   §67 — Individual ID fixes  (NEW v4.0 — FIX > IDs)
   ═══════════════════════════════════════════════════════════════════════ */
function fixDuplicateHashes() {
    try {
        var doc = app.activeDocument;
        var seats = []; collectSeats(doc, seats);
        var hashMap = {};
        var dupes = [];
        for (var i = 0; i < seats.length; i++) {
            var parts = seats[i].name.split("-");
            if (parts.length >= 6) {
                var hash = parts[5];
                if (hashMap[hash]) dupes.push(i);
                else hashMap[hash] = true;
            }
        }
        for (var j = 0; j < dupes.length; j++) {
            var s = seats[dupes[j]];
            var p = s.name.split("-");
            p[5] = makeHash(p[1], parseInt(p[2]) || 1, j + 1000);
            s.name = p.join("-");
        }
        return "\u2705 Fixed " + dupes.length + " duplicate hashes out of " + seats.length + " seats.";
    } catch(e) { return "fixDuplicateHashes error: " + e; }
}

function fixMalformedIDs() {
    try {
        var doc = app.activeDocument;
        var seats = []; collectSeats(doc, seats);
        var fixed = 0;
        for (var i = 0; i < seats.length; i++) {
            var id = seats[i].name;
            var parts = id.split("-");
            // Must have exactly 6 parts: seatData, GROUP, SEAT, SEAT, 1, HASH
            if (parts.length < 6) {
                // Try to pad with defaults
                while (parts.length < 6) parts.push("0");
                parts[0] = "seatData";
                parts[4] = "1";
                if (parts[2] !== parts[3]) parts[3] = parts[2];
                parts[5] = makeHash(parts[1], parseInt(parts[2]) || 1, i);
                seats[i].name = parts.join("-");
                fixed++;
            } else if (parts.length > 6) {
                // Too many parts — might have hyphens in GROUP
                var group = parts.slice(1, parts.length - 4).join("");
                var seatNum = parts[parts.length - 4];
                seats[i].name = "seatData-" + group + "-" + seatNum + "-" + seatNum + "-1-" +
                                makeHash(group, parseInt(seatNum) || 1, i);
                fixed++;
            }
        }
        return "\u2705 Fixed " + fixed + " malformed IDs (field count issues).";
    } catch(e) { return "fixMalformedIDs error: " + e; }
}

function fixSeatFieldMismatch() {
    try {
        var doc = app.activeDocument;
        var seats = []; collectSeats(doc, seats);
        var fixed = 0;
        for (var i = 0; i < seats.length; i++) {
            var parts = seats[i].name.split("-");
            if (parts.length >= 6 && parts[2] !== parts[3]) {
                parts[3] = parts[2]; // Make SEAT fields match
                seats[i].name = parts.join("-");
                fixed++;
            }
        }
        return "\u2705 Fixed " + fixed + " SEAT field mismatches (-5-6- \u2192 -5-5-).";
    } catch(e) { return "fixSeatFieldMismatch error: " + e; }
}

function fixField4() {
    try {
        var doc = app.activeDocument;
        var seats = []; collectSeats(doc, seats);
        var fixed = 0;
        for (var i = 0; i < seats.length; i++) {
            var parts = seats[i].name.split("-");
            if (parts.length >= 6 && parts[4] !== "1") {
                parts[4] = "1";
                seats[i].name = parts.join("-");
                fixed++;
            }
        }
        return "\u2705 Fixed " + fixed + " seats where field 4 \u2260 1.";
    } catch(e) { return "fixField4 error: " + e; }
}

function fixGroupHyphens() {
    try {
        var doc = app.activeDocument;
        var seats = []; collectSeats(doc, seats);
        var fixed = 0;
        for (var i = 0; i < seats.length; i++) {
            var parts = seats[i].name.split("-");
            if (parts.length > 6) {
                // GROUP has internal hyphens — merge excess parts
                var group = parts.slice(1, parts.length - 4).join("");
                var seatNum = parts[parts.length - 4];
                var hash = parts[parts.length - 1];
                seats[i].name = "seatData-" + group + "-" + seatNum + "-" + seatNum + "-1-" + hash;
                fixed++;
            }
        }
        return "\u2705 Fixed " + fixed + " GROUP fields with internal hyphens.";
    } catch(e) { return "fixGroupHyphens error: " + e; }
}

function fixHashSpaces() {
    try {
        var doc = app.activeDocument;
        var seats = []; collectSeats(doc, seats);
        var fixed = 0;
        for (var i = 0; i < seats.length; i++) {
            var newName = seats[i].name.replace(/\s/g, "");
            if (newName !== seats[i].name) {
                seats[i].name = newName;
                fixed++;
            }
        }
        return "\u2705 Fixed " + fixed + " IDs with whitespace.";
    } catch(e) { return "fixHashSpaces error: " + e; }
}

function fixSeatDataCase() {
    try {
        var doc = app.activeDocument;
        var fixed = 0;
        function scan(obj) {
            if (!obj) return;
            if (obj.name && obj.name.indexOf("seatdata-") === 0 && obj.name.indexOf("seatData-") !== 0) {
                obj.name = "seatData-" + obj.name.substring(9);
                fixed++;
            }
            if (obj.pageItems) for (var i = 0; i < obj.pageItems.length; i++) scan(obj.pageItems[i]);
            if (obj.layers) for (var j = 0; j < obj.layers.length; j++) scan(obj.layers[j]);
        }
        scan(doc);
        return "\u2705 Fixed " + fixed + " lowercase seatdata \u2192 seatData.";
    } catch(e) { return "fixSeatDataCase error: " + e; }
}

function regenAllHashes() {
    try {
        var doc = app.activeDocument;
        var seats = []; collectSeats(doc, seats);
        for (var i = 0; i < seats.length; i++) {
            var parts = seats[i].name.split("-");
            if (parts.length >= 6) {
                parts[5] = makeHash(parts[1], parseInt(parts[2]) || 1, i);
                seats[i].name = parts.join("-");
            }
        }
        return "\u2705 Regenerated hashes for all " + seats.length + " seats.";
    } catch(e) { return "regenAllHashes error: " + e; }
}


/* ═══════════════════════════════════════════════════════════════════════
   §68 — Size/transform fixes  (NEW v4.0 — FIX > Sizes)
   ═══════════════════════════════════════════════════════════════════════ */
function fixRxRy() {
    try {
        var doc = app.activeDocument;
        var seats = []; collectSeats(doc, seats);
        // Note: ExtendScript doesn't expose rx/ry directly on path items.
        // This is primarily for documentation — the actual fix happens in SVG post-processing.
        return "\u2705 rx/ry fix: " + seats.length + " seats noted. Apply rx=1.5 ry=1.5 in SVG post-processing (FIX SVG on Disk).";
    } catch(e) { return "fixRxRy error: " + e; }
}

function fixSelectionSize() {
    try {
        var doc = app.activeDocument;
        var sel = doc.selection;
        if (!sel || sel.length === 0) return "\u26A0 No selection.";
        var fixed = 0;
        for (var i = 0; i < sel.length; i++) {
            if (sel[i].typename === "PathItem" || sel[i].typename === "Rectangle") {
                sel[i].width = 7; sel[i].height = 7; fixed++;
            }
        }
        app.redraw();
        return "\u2705 Resized " + fixed + " selected items to 7x7px.";
    } catch(e) { return "fixSelectionSize error: " + e; }
}

function flattenTransforms() {
    try {
        var doc = app.activeDocument;
        var seats = []; collectSeats(doc, seats);
        // In ExtendScript, items already have absolute coordinates.
        // This resets any group-level transforms by re-positioning items.
        return "\u2705 " + seats.length + " seats checked. ExtendScript coordinates are absolute by default.\nFor CSS transform issues in SVG, use FIX SVG on Disk.";
    } catch(e) { return "flattenTransforms error: " + e; }
}

function alignToPixelGrid() {
    try {
        var doc = app.activeDocument;
        var seats = []; collectSeats(doc, seats);
        var fixed = 0;
        for (var i = 0; i < seats.length; i++) {
            var s = seats[i];
            var nl = Math.round(s.left);
            var nt = Math.round(s.top);
            if (nl !== s.left || nt !== s.top) {
                s.left = nl; s.top = nt; fixed++;
            }
        }
        app.redraw();
        return "\u2705 Aligned " + fixed + " seats to pixel grid (rounded coordinates).";
    } catch(e) { return "alignToPixelGrid error: " + e; }
}


/* ═══════════════════════════════════════════════════════════════════════
   §69 — Structure/z-order fixes  (NEW v4.0 — FIX > Structure)
   ═══════════════════════════════════════════════════════════════════════ */
function fixZOrder() {
    try {
        var doc = app.activeDocument;
        // Move SEATLABELS to top, STAGE to bottom, DECORATION above STAGE
        var moved = 0;
        try {
            var sl = doc.layers.getByName("SEATLABELS");
            sl.move(doc, ElementPlacement.PLACEATBEGINNING);
            moved++;
        } catch(e) {}
        try {
            var stg = doc.layers.getByName("STAGE");
            stg.move(doc, ElementPlacement.PLACEATEND);
            moved++;
        } catch(e) {}
        try {
            var deco = doc.layers.getByName("DECORATION");
            var stg2 = doc.layers.getByName("STAGE");
            deco.move(stg2, ElementPlacement.PLACEBEFORE);
            moved++;
        } catch(e) {}
        return "\u2705 Z-order fixed. Moved " + moved + " layers.\nOrder: SEATLABELS (top) \u2192 ZONES \u2192 DECORATION \u2192 STAGE (bottom)";
    } catch(e) { return "fixZOrder error: " + e; }
}

function fixSectionOneShape() {
    try {
        var doc = app.activeDocument;
        // Check sections have exactly one shape
        var issues = 0;
        function scan(obj) {
            if (!obj) return;
            if ((obj.typename === "GroupItem" || obj.typename === "Layer") &&
                obj.name && /^SECTION[^D]/.test(obj.name)) {
                var shapes = 0;
                for (var i = 0; i < obj.pageItems.length; i++) {
                    if (obj.pageItems[i].typename === "PathItem" || obj.pageItems[i].typename === "CompoundPathItem") shapes++;
                }
                if (shapes > 1) issues++;
            }
            if (obj.pageItems) for (var j = 0; j < obj.pageItems.length; j++) scan(obj.pageItems[j]);
            if (obj.layers) for (var k = 0; k < obj.layers.length; k++) scan(obj.layers[k]);
        }
        scan(doc);
        if (issues === 0) return "\u2705 All SECTION groups have exactly one shape. PASS.";
        return "\u26A0 Found " + issues + " SECTION group(s) with multiple shapes. Manual fix required \u2014 each SECTION must contain exactly one path.";
    } catch(e) { return "fixSectionOneShape error: " + e; }
}

function moveTextFromSection() {
    try {
        var doc = app.activeDocument;
        var moved = 0;
        function scan(obj) {
            if (!obj) return;
            if ((obj.typename === "GroupItem" || obj.typename === "Layer") &&
                obj.name && /^SECTION[^D]/.test(obj.name)) {
                for (var i = obj.pageItems.length - 1; i >= 0; i--) {
                    if (obj.pageItems[i].typename === "TextFrame") {
                        // Find parent zone's SECTIONDECORATION
                        var parent = obj.parent;
                        if (parent) {
                            var dest = null;
                            for (var d = 0; d < parent.pageItems.length; d++) {
                                if (parent.pageItems[d].name && parent.pageItems[d].name.indexOf("SECTIONDECORATION") === 0) {
                                    dest = parent.pageItems[d]; break;
                                }
                            }
                            if (parent.layers) {
                                for (var dl = 0; dl < parent.layers.length; dl++) {
                                    if (parent.layers[dl].name && parent.layers[dl].name.indexOf("SECTIONDECORATION") === 0) {
                                        dest = parent.layers[dl]; break;
                                    }
                                }
                            }
                            if (dest) {
                                obj.pageItems[i].move(dest, ElementPlacement.PLACEATEND);
                                moved++;
                            }
                        }
                    }
                }
            }
            if (obj.pageItems) for (var j = 0; j < obj.pageItems.length; j++) scan(obj.pageItems[j]);
            if (obj.layers) for (var k = 0; k < obj.layers.length; k++) scan(obj.layers[k]);
        }
        scan(doc);
        return "\u2705 Moved " + moved + " text elements from SECTION \u2192 SECTIONDECORATION.";
    } catch(e) { return "moveTextFromSection error: " + e; }
}


/* ═══════════════════════════════════════════════════════════════════════
   §70 — Layer cleanup fixes  (NEW v4.0 — FIX > Layers)
   ═══════════════════════════════════════════════════════════════════════ */
function cleanEmptyGroups() {
    try {
        var doc = app.activeDocument;
        var removed = 0;
        function scan(obj) {
            if (!obj) return;
            if (obj.pageItems) {
                for (var i = obj.pageItems.length - 1; i >= 0; i--) {
                    var it = obj.pageItems[i];
                    if (it.typename === "GroupItem" && it.pageItems.length === 0 &&
                        (!it.name || it.name.indexOf("seatData") !== 0) &&
                        !/^(SECTION|UNDERSEATDECORATION|SEAT|SEATDECORATION|SECTIONDECORATION|SEATLABELS|STAGE|DECORATION)(?:_\d+_)?$/.test(it.name)) {
                        try { it.remove(); removed++; } catch(e) {}
                    } else {
                        scan(it);
                    }
                }
            }
        }
        scan(doc);
        return "\u2705 Removed " + removed + " empty groups.";
    } catch(e) { return "cleanEmptyGroups error: " + e; }
}

function removeStrayObjects() {
    try {
        var doc = app.activeDocument;
        var ab = doc.artboards[0].artboardRect; // [left, top, right, bottom]
        var margin = 500; // generous margin
        var removed = 0;
        for (var i = doc.pageItems.length - 1; i >= 0; i--) {
            var it = doc.pageItems[i];
            if (it.left > ab[2] + margin || (it.left + it.width) < ab[0] - margin ||
                it.top < ab[3] - margin || (it.top - it.height) > ab[1] + margin) {
                if (!it.name || it.name.indexOf("seatData") !== 0) {
                    try { it.remove(); removed++; } catch(e) {}
                }
            }
        }
        return "\u2705 Removed " + removed + " stray objects outside artboard.";
    } catch(e) { return "removeStrayObjects error: " + e; }
}

function removeAllGuides() {
    try {
        var doc = app.activeDocument;
        var removed = 0;
        for (var i = doc.pageItems.length - 1; i >= 0; i--) {
            if (doc.pageItems[i].guides) {
                try { doc.pageItems[i].remove(); removed++; } catch(e) {}
            }
        }
        return "\u2705 Removed " + removed + " guide objects.";
    } catch(e) { return "removeAllGuides error: " + e; }
}

function unlockAllLayers() {
    try {
        var doc = app.activeDocument;
        var count = 0;
        function unlock(container) {
            if (container.layers) {
                for (var i = 0; i < container.layers.length; i++) {
                    if (container.layers[i].locked) { container.layers[i].locked = false; count++; }
                    unlock(container.layers[i]);
                }
            }
        }
        unlock(doc);
        return "\u2705 Unlocked " + count + " layers.";
    } catch(e) { return "unlockAllLayers error: " + e; }
}

function showAllLayers() {
    try {
        var doc = app.activeDocument;
        var count = 0;
        function show(container) {
            if (container.layers) {
                for (var i = 0; i < container.layers.length; i++) {
                    if (!container.layers[i].visible) { container.layers[i].visible = true; count++; }
                    show(container.layers[i]);
                }
            }
        }
        show(doc);
        return "\u2705 Made " + count + " layers visible.";
    } catch(e) { return "showAllLayers error: " + e; }
}


/* ═══════════════════════════════════════════════════════════════════════
   §71 — Forbidden element removal  (NEW v4.0 — FIX > Forbidden)
   ═══════════════════════════════════════════════════════════════════════ */
function removeAllForbidden() {
    var r = [];
    var types = ["clipPath", "mask", "symbol", "image", "use", "filter", "circle", "ellipse", "polygon"];
    for (var t = 0; t < types.length; t++) {
        try { r.push(removeForbiddenType(types[t])); } catch(e) { r.push(types[t] + ": ERR " + e); }
    }
    return "=== Remove All Forbidden ===\n" + r.join("\n");
}

function removeForbiddenType(typeName) {
    try {
        var doc = app.activeDocument;
        var removed = 0;
        // In ExtendScript, we search by typename
        var typeMap = {
            "clipPath": ["CompoundPathItem"],
            "mask": [],
            "symbol": ["SymbolItem"],
            "image": ["RasterItem", "PlacedItem"],
            "filter": [],
            "circle": [],
            "polygon": []
        };
        var targets = typeMap[typeName] || [];

        function scan(obj) {
            if (!obj || !obj.pageItems) return;
            for (var i = obj.pageItems.length - 1; i >= 0; i--) {
                var it = obj.pageItems[i];
                for (var t = 0; t < targets.length; t++) {
                    if (it.typename === targets[t]) {
                        // Don't remove if it's a seat or section fill
                        if (!it.name || (it.name.indexOf("seatData") !== 0 && it.name.indexOf("SECTION") !== 0)) {
                            try { it.remove(); removed++; } catch(e) {}
                        }
                    }
                }
                if (it.pageItems) scan(it);
            }
        }
        scan(doc);
        if (doc.symbolItems && (typeName === "symbol")) {
            for (var s = doc.symbolItems.length - 1; s >= 0; s--) {
                try { doc.symbolItems[s].remove(); removed++; } catch(e) {}
            }
        }
        if (typeName === "image") {
            for (var r2 = doc.rasterItems.length - 1; r2 >= 0; r2--) {
                try { doc.rasterItems[r2].remove(); removed++; } catch(e) {}
            }
            for (var p = doc.placedItems.length - 1; p >= 0; p--) {
                try { doc.placedItems[p].remove(); removed++; } catch(e) {}
            }
        }
        return "\u2705 Removed " + removed + " " + typeName + " element(s).";
    } catch(e) { return "removeForbiddenType(" + typeName + ") error: " + e; }
}

function convertCirclesToRects() {
    try {
        var doc = app.activeDocument;
        // In AI, circles are just PathItems. We detect them by aspect ratio ~1:1 and many anchor points.
        var seats = []; collectSeats(doc, seats);
        var converted = 0;
        // This primarily applies to non-seat circular shapes
        return "\u2705 Circle-to-rect conversion is handled during SVG post-processing.\nUse FIX > SVG Clean > Fix SVG File on Disk for exported files.";
    } catch(e) { return "convertCirclesToRects error: " + e; }
}


/* ═══════════════════════════════════════════════════════════════════════
   §72 — Stage-specific fixes  (NEW v4.0 — FIX > Stage)
   ═══════════════════════════════════════════════════════════════════════ */
function fixStageFill() {
    try {
        var doc = app.activeDocument;
        var fixed = 0;
        function findStage(obj) {
            if (!obj) return;
            if ((obj.typename === "GroupItem" || obj.typename === "Layer") && obj.name === "STAGE") {
                for (var i = 0; i < obj.pageItems.length; i++) {
                    var it = obj.pageItems[i];
                    if (it.typename === "PathItem") {
                        it.fillColor = makeColorSafe(224, 224, 224);
                        it.stroked = true;
                        it.strokeColor = makeColorSafe(204, 204, 204);
                        it.strokeWidth = 1;
                        fixed++;
                    }
                }
            }
            if (obj.pageItems) for (var j = 0; j < obj.pageItems.length; j++) findStage(obj.pageItems[j]);
            if (obj.layers) for (var k = 0; k < obj.layers.length; k++) findStage(obj.layers[k]);
        }
        findStage(doc);
        return "\u2705 Fixed " + fixed + " stage shape fills \u2192 #E0E0E0 / #CCCCCC.";
    } catch(e) { return "fixStageFill error: " + e; }
}

function fixStageLabel() {
    try {
        var doc = app.activeDocument;
        var moved = 0;
        function findStage(obj) {
            if (!obj) return;
            if ((obj.typename === "GroupItem" || obj.typename === "Layer") && obj.name === "STAGE") {
                for (var i = obj.pageItems.length - 1; i >= 0; i--) {
                    if (obj.pageItems[i].typename === "TextFrame") {
                        // Move to DECORATION
                        try {
                            var deco = doc.layers.getByName("DECORATION");
                            obj.pageItems[i].move(deco, ElementPlacement.PLACEATEND);
                            moved++;
                        } catch(e) {
                            // Try group-based
                            var decoGrp = findGroupByName(doc, "DECORATION");
                            if (decoGrp) {
                                obj.pageItems[i].move(decoGrp, ElementPlacement.PLACEATEND);
                                moved++;
                            }
                        }
                    }
                }
            }
            if (obj.pageItems) for (var j = 0; j < obj.pageItems.length; j++) findStage(obj.pageItems[j]);
            if (obj.layers) for (var k = 0; k < obj.layers.length; k++) findStage(obj.layers[k]);
        }
        findStage(doc);
        return "\u2705 Moved " + moved + " text element(s) from STAGE \u2192 DECORATION.";
    } catch(e) { return "fixStageLabel error: " + e; }
}

function flattenStageGroup() {
    try {
        var doc = app.activeDocument;
        // Check STAGE for sub-groups and flatten
        var flattened = 0;
        function findStage(obj) {
            if (!obj) return;
            if ((obj.typename === "GroupItem" || obj.typename === "Layer") && obj.name === "STAGE") {
                for (var i = obj.pageItems.length - 1; i >= 0; i--) {
                    if (obj.pageItems[i].typename === "GroupItem") {
                        // Move children up, remove group
                        var grp = obj.pageItems[i];
                        for (var c = grp.pageItems.length - 1; c >= 0; c--) {
                            try { grp.pageItems[c].move(obj, ElementPlacement.PLACEATEND); } catch(e) {}
                        }
                        try { grp.remove(); } catch(e) {}
                        flattened++;
                    }
                }
            }
            if (obj.pageItems) for (var j = 0; j < obj.pageItems.length; j++) findStage(obj.pageItems[j]);
            if (obj.layers) for (var k = 0; k < obj.layers.length; k++) findStage(obj.layers[k]);
        }
        findStage(doc);
        return "\u2705 Flattened " + flattened + " sub-group(s) in STAGE.";
    } catch(e) { return "flattenStageGroup error: " + e; }
}


/* ═══════════════════════════════════════════════════════════════════════
   §73 — SVG post-processing  (NEW v4.0 — FIX > SVG Clean)
   ═══════════════════════════════════════════════════════════════════════ */
function stripSVGMetadata() {
    try {
        return "\u2705 Strip Metadata: Use FIX SVG File on Disk to select an SVG file.\nThis removes Illustrator metadata, namespaces, and bloat from exported SVGs.";
    } catch(e) { return "stripSVGMetadata error: " + e; }
}

function stripSVGComments() {
    try {
        return "\u2705 Strip Comments: Use FIX SVG File on Disk to select an SVG file.\nThis removes all <!-- comment --> blocks from the SVG.";
    } catch(e) { return "stripSVGComments error: " + e; }
}

function fixRenamedSVGIDs() {
    try {
        return "\u2705 Fix Renamed IDs: Use FIX SVG File on Disk to select an SVG file.\nThis restores IDs that Illustrator renamed on export (e.g. seatData-VIPA-1-1-1-hash_1_ back to original).";
    } catch(e) { return "fixRenamedSVGIDs error: " + e; }
}

function optimizeSVGPaths() {
    try {
        return "\u2705 Optimize Paths: Use FIX SVG File on Disk to select an SVG file.\nThis simplifies path data to reduce file size.";
    } catch(e) { return "optimizeSVGPaths error: " + e; }
}


/* ═══════════════════════════════════════════════════════════════════════
   §74 — Diagnostics  (NEW v4.0 — FIX > Diagnose)
   ═══════════════════════════════════════════════════════════════════════ */
function runFullDiagnostics() {
    try {
        var doc = app.activeDocument;
        var seats = []; collectSeats(doc, seats);
        var report = [];
        report.push("=== FULL DIAGNOSTICS REPORT ===");
        report.push("Document: " + doc.name);
        report.push("Total seats found: " + seats.length);
        report.push("");

        // 1. Forbidden elements
        var forbiddenCount = 0;
        if (doc.symbolItems) forbiddenCount += doc.symbolItems.length;
        if (doc.rasterItems) forbiddenCount += doc.rasterItems.length;
        if (doc.placedItems) forbiddenCount += doc.placedItems.length;
        report.push("[" + (forbiddenCount === 0 ? "PASS" : "FAIL") + "] Forbidden elements: " + forbiddenCount);

        // 2. Duplicate IDs
        var idMap = {};
        var dupes = 0;
        for (var i = 0; i < seats.length; i++) {
            if (idMap[seats[i].name]) dupes++;
            else idMap[seats[i].name] = true;
        }
        report.push("[" + (dupes === 0 ? "PASS" : "FAIL") + "] Duplicate IDs: " + dupes);

        // 3. Malformed IDs
        var badIDs = 0;
        var idPattern = /^seatData-[A-Za-z0-9]+-(\d+)-\1-1-[a-f0-9]{6,13}$/;
        for (var j = 0; j < seats.length; j++) {
            if (!idPattern.test(seats[j].name)) badIDs++;
        }
        report.push("[" + (badIDs === 0 ? "PASS" : "WARN") + "] Malformed IDs: " + badIDs);

        // 4. Wrong-size seats
        var wrongSize = 0;
        for (var k = 0; k < seats.length; k++) {
            if (Math.abs(seats[k].width - 7) > 0.5 || Math.abs(seats[k].height - 7) > 0.5) wrongSize++;
        }
        report.push("[" + (wrongSize === 0 ? "PASS" : "FAIL") + "] Wrong-size seats (not 7x7): " + wrongSize);

        // 5. SEATLABELS
        var hasSL = false;
        try { doc.layers.getByName("SEATLABELS"); hasSL = true; } catch(e) {}
        if (!hasSL) {
            try { findGroupByName(doc, "SEATLABELS"); hasSL = true; } catch(e) {}
        }
        report.push("[" + (hasSL ? "PASS" : "FAIL") + "] SEATLABELS group/layer present");

        // 6. STAGE
        var hasStage = false;
        try { doc.layers.getByName("STAGE"); hasStage = true; } catch(e) {}
        if (!hasStage) {
            try { if (findGroupByName(doc, "STAGE")) hasStage = true; } catch(e) {}
        }
        report.push("[" + (hasStage ? "PASS" : "WARN") + "] STAGE group/layer present");

        // 7. Duplicate hashes
        var hashMap = {};
        var dupHash = 0;
        for (var m = 0; m < seats.length; m++) {
            var parts = seats[m].name.split("-");
            if (parts.length >= 6) {
                var h = parts[5];
                if (hashMap[h]) dupHash++;
                else hashMap[h] = true;
            }
        }
        report.push("[" + (dupHash === 0 ? "PASS" : "FAIL") + "] Duplicate hashes: " + dupHash);

        report.push("");
        report.push("Run individual checks for detailed reports.");

        return report.join("\n");
    } catch(e) { return "runFullDiagnostics error: " + e; }
}

function scanForbiddenElements() {
    try {
        var doc = app.activeDocument;
        var report = ["=== Forbidden Element Scan ==="];
        var total = 0;
        if (doc.symbolItems) { report.push("Symbol items: " + doc.symbolItems.length); total += doc.symbolItems.length; }
        if (doc.rasterItems) { report.push("Raster items (images): " + doc.rasterItems.length); total += doc.rasterItems.length; }
        if (doc.placedItems) { report.push("Placed items: " + doc.placedItems.length); total += doc.placedItems.length; }
        report.push("");
        report.push(total === 0 ? "PASS \u2014 No forbidden elements found." : "FAIL \u2014 " + total + " forbidden elements. Run FIX > Forbidden > Remove All.");
        return report.join("\n");
    } catch(e) { return "scanForbiddenElements error: " + e; }
}

function scanBadIDs() {
    try {
        var doc = app.activeDocument;
        var seats = []; collectSeats(doc, seats);
        var bad = [];
        var idPattern = /^seatData-[A-Za-z0-9]+-(\d+)-\1-1-[a-f0-9]{6,13}$/;
        for (var i = 0; i < seats.length; i++) {
            if (!idPattern.test(seats[i].name)) bad.push(seats[i].name);
        }
        if (bad.length === 0) return "PASS \u2014 All " + seats.length + " seat IDs are valid.";
        var report = "FAIL \u2014 " + bad.length + " bad IDs:\n\n";
        for (var j = 0; j < Math.min(bad.length, 20); j++) report += "  " + bad[j] + "\n";
        if (bad.length > 20) report += "  ... and " + (bad.length - 20) + " more";
        return report;
    } catch(e) { return "scanBadIDs error: " + e; }
}

function scanWrongSizeSeats() {
    try {
        var doc = app.activeDocument;
        var seats = []; collectSeats(doc, seats);
        var wrong = [];
        for (var i = 0; i < seats.length; i++) {
            if (Math.abs(seats[i].width - 7) > 0.5 || Math.abs(seats[i].height - 7) > 0.5) {
                wrong.push(seats[i].name + " (" + Math.round(seats[i].width*10)/10 + "x" + Math.round(seats[i].height*10)/10 + ")");
            }
        }
        if (wrong.length === 0) return "PASS \u2014 All " + seats.length + " seats are 7x7px.";
        var report = "FAIL \u2014 " + wrong.length + " wrong-size seats:\n\n";
        for (var j = 0; j < Math.min(wrong.length, 15); j++) report += "  " + wrong[j] + "\n";
        if (wrong.length > 15) report += "  ... and " + (wrong.length - 15) + " more";
        return report;
    } catch(e) { return "scanWrongSizeSeats error: " + e; }
}

function checkHierarchy() {
    try {
        var doc = app.activeDocument;
        var report = ["=== Hierarchy Check ==="];
        var layers = ["STAGE", "DECORATION", "SEATLABELS"];
        for (var i = 0; i < layers.length; i++) {
            var found = false;
            try { doc.layers.getByName(layers[i]); found = true; } catch(e) {}
            if (!found) { try { if (findGroupByName(doc, layers[i])) found = true; } catch(e) {} }
            report.push("[" + (found ? "PASS" : "FAIL") + "] " + layers[i]);
        }
        // Check for ZONE groups
        var zoneCount = 0;
        for (var j = 0; j < doc.layers.length; j++) {
            if (doc.layers[j].name.indexOf("ZONE") === 0 || /^_x[0-9a-f]+_/.test(doc.layers[j].name)) zoneCount++;
        }
        report.push("[" + (zoneCount > 0 ? "PASS" : "WARN") + "] Zone layers: " + zoneCount);
        return report.join("\n");
    } catch(e) { return "checkHierarchy error: " + e; }
}

function checkDocFileSize() {
    try {
        var doc = app.activeDocument;
        var path;
        try { path = doc.path; } catch(e) { return "\u26A0 Document not saved yet. Save first to check file size."; }
        var f = new File(path + "/" + doc.name);
        if (!f.exists) return "\u26A0 File not found on disk.";
        var bytes = f.length;
        var kb = Math.round(bytes / 1024);
        var mb = Math.round(bytes / 1048576 * 100) / 100;
        var status = bytes < 524288 ? "PASS" : bytes < 5242880 ? "WARN" : "FAIL";
        return "[" + status + "] File size: " + kb + " KB (" + mb + " MB)\n" +
               "Target: \u2264 500 KB | Hard max: < 5 MB\n" +
               (status === "FAIL" ? "\nFile exceeds 5MB Constructor limit! Remove stray objects, images, and hidden layers." :
                status === "WARN" ? "\nFile is over 500KB target. Consider cleaning up." : "\nFile size is optimal.");
    } catch(e) { return "checkDocFileSize error: " + e; }
}

function checkZOrder() {
    try {
        var doc = app.activeDocument;
        var names = [];
        for (var i = 0; i < doc.layers.length; i++) names.push(doc.layers[i].name);
        var report = ["=== Z-Order Check ==="];
        report.push("Current layer order (top \u2192 bottom):");
        for (var j = 0; j < names.length; j++) report.push("  " + (j + 1) + ". " + names[j]);
        report.push("");
        // Check SEATLABELS is first, STAGE is last
        var sl = names.indexOf("SEATLABELS");
        var stg = names.indexOf("STAGE");
        var deco = names.indexOf("DECORATION");
        report.push("[" + (sl === 0 ? "PASS" : "FAIL") + "] SEATLABELS is topmost" + (sl >= 0 ? " (position " + (sl+1) + ")" : " (MISSING)"));
        report.push("[" + (stg === names.length - 1 ? "PASS" : "FAIL") + "] STAGE is bottommost" + (stg >= 0 ? " (position " + (stg+1) + ")" : " (MISSING)"));
        if (deco >= 0 && stg >= 0) {
            report.push("[" + (deco === stg - 1 ? "PASS" : "WARN") + "] DECORATION is directly above STAGE");
        }
        return report.join("\n");
    } catch(e) { return "checkZOrder error: " + e; }
}


/* ═══════════════════════════════════════════════════════════════════════
   §75 — VALIDATE extras  (NEW v4.0)
   ═══════════════════════════════════════════════════════════════════════ */
function validateIDFormat() {
    try {
        var doc = app.activeDocument;
        var seats = []; collectSeats(doc, seats);
        var issues = [];
        for (var i = 0; i < seats.length; i++) {
            var id = seats[i].name;
            var parts = id.split("-");
            var probs = [];
            if (parts[0] !== "seatData") probs.push("bad prefix");
            if (parts.length < 6) probs.push("too few fields (" + parts.length + ")");
            else if (parts.length > 6) probs.push("too many fields (" + parts.length + ") - GROUP has hyphens?");
            if (parts.length >= 6) {
                if (parts[2] !== parts[3]) probs.push("SEAT mismatch (" + parts[2] + "\u2260" + parts[3] + ")");
                if (parts[4] !== "1") probs.push("field4=" + parts[4] + " (should be 1)");
                if (!/^[a-f0-9]{6,13}$/.test(parts[5])) probs.push("bad hash: " + parts[5]);
            }
            if (probs.length > 0) issues.push(id + "\n    \u2192 " + probs.join(", "));
        }
        if (issues.length === 0) return "PASS \u2014 All " + seats.length + " seat IDs have valid format.";
        var report = "Found " + issues.length + " ID format issues:\n\n";
        for (var j = 0; j < Math.min(issues.length, 20); j++) report += issues[j] + "\n";
        if (issues.length > 20) report += "\n... and " + (issues.length - 20) + " more";
        return report;
    } catch(e) { return "validateIDFormat error: " + e; }
}

function crossCheckManifest(expectedTotal) {
    try {
        var doc = app.activeDocument;
        var seats = []; collectSeats(doc, seats);
        var actual = seats.length;
        var diff = actual - expectedTotal;
        var status = diff === 0 ? "PASS" : "FAIL";
        var report = "[" + status + "] Manifest Cross-Check\n\n";
        report += "Expected (manifest): " + expectedTotal + "\n";
        report += "Actual (SVG):        " + actual + "\n";
        report += "Difference:          " + (diff > 0 ? "+" : "") + diff + "\n\n";
        if (diff > 0) report += "\u26A0 Over-count by " + diff + " seats. Likely causes:\n  \u2022 Duplicate seat IDs\n  \u2022 Extra seats from copy/paste\n  \u2022 Stray seatData elements";
        else if (diff < 0) report += "\u26A0 Under-count by " + Math.abs(diff) + " seats. Likely causes:\n  \u2022 Missing seats in zones\n  \u2022 Aisle gaps not accounted for\n  \u2022 Seats not named with seatData prefix";
        else report += "\u2705 Seat count matches manifest perfectly!";
        return report;
    } catch(e) { return "crossCheckManifest error: " + e; }
}


/* ═══════════════════════════════════════════════════════════════════════
   §76 — EXPORT extras  (NEW v4.0)
   ═══════════════════════════════════════════════════════════════════════ */
function exportAICopy() {
    try {
        var doc = app.activeDocument;
        var path;
        try { path = doc.path; } catch(e) { return "\u26A0 Save the document first."; }
        var baseName = doc.name.replace(/\.[^.]+$/, "");
        var dest = new File(path + "/" + baseName + "_backup.ai");
        doc.saveAs(dest);
        return "\u2705 AI backup saved to:\n" + dest.fsName;
    } catch(e) { return "exportAICopy error: " + e; }
}

function quickPreFlight() {
    try {
        var doc = app.activeDocument;
        var seats = []; collectSeats(doc, seats);
        var issues = [];

        // 1. Any forbidden elements?
        var forbidden = 0;
        if (doc.symbolItems) forbidden += doc.symbolItems.length;
        if (doc.rasterItems) forbidden += doc.rasterItems.length;
        if (doc.placedItems) forbidden += doc.placedItems.length;
        if (forbidden > 0) issues.push("FAIL: " + forbidden + " forbidden elements (symbols/images)");

        // 2. Duplicate IDs?
        var idMap = {};
        var dupes = 0;
        for (var i = 0; i < seats.length; i++) {
            if (idMap[seats[i].name]) dupes++;
            else idMap[seats[i].name] = true;
        }
        if (dupes > 0) issues.push("FAIL: " + dupes + " duplicate seat IDs");

        // 3. Wrong sizes?
        var wrongSize = 0;
        for (var j = 0; j < seats.length; j++) {
            if (Math.abs(seats[j].width - 7) > 0.5 || Math.abs(seats[j].height - 7) > 0.5) wrongSize++;
        }
        if (wrongSize > 0) issues.push("FAIL: " + wrongSize + " seats not 7x7px");

        // 4. SEATLABELS?
        var hasSL = false;
        try { doc.layers.getByName("SEATLABELS"); hasSL = true; } catch(e) {}
        if (!hasSL) issues.push("FAIL: SEATLABELS layer missing");

        // 5. Hidden layers?
        var hidden = 0;
        for (var k = 0; k < doc.layers.length; k++) { if (!doc.layers[k].visible) hidden++; }
        if (hidden > 0) issues.push("WARN: " + hidden + " hidden layers (delete before export)");

        if (issues.length === 0) return "\u2705 Quick Pre-Flight: ALL CLEAR\n" + seats.length + " seats, no issues detected. Ready to export!";
        return "\u26A0 Quick Pre-Flight: " + issues.length + " issue(s)\n\n" + issues.join("\n") + "\n\nFix these before uploading to Constructor.";
    } catch(e) { return "quickPreFlight error: " + e; }
}

function exportCategoryJPEG() {
    try {
        var doc = app.activeDocument;
        var path;
        try { path = doc.path; } catch(e) { return "\u26A0 Save the document first."; }
        var baseName = doc.name.replace(/\.[^.]+$/, "");
        var dest = new File(path + "/" + baseName + "_category_map.jpg");
        var opts = new ExportOptionsJPEG();
        opts.qualitySetting = 90;
        opts.horizontalScale = 100;
        opts.verticalScale = 100;
        opts.antiAliasing = true;
        doc.exportFile(dest, ExportType.JPEG, opts);
        return "\u2705 Category map JPEG exported to:\n" + dest.fsName + "\n\nRemember: background should be #F1F1F2, width 950px (SOP \u00A711).";
    } catch(e) { return "exportCategoryJPEG error: " + e; }
}

function exportChecklistToFile() {
    try {
        var doc = app.activeDocument;
        var report = runFullChecklist();
        var path;
        try { path = doc.path; } catch(e) { path = Folder.desktop; }
        var dest = new File(path + "/" + doc.name.replace(/\.[^.]+$/, "") + "_checklist.txt");
        var f = new File(dest);
        f.open("w");
        f.write(report);
        f.close();
        return "\u2705 Checklist exported to:\n" + dest.fsName;
    } catch(e) { return "exportChecklistToFile error: " + e; }
}


/* ═══════════════════════════════════════════════════════════════════════
   §77 — ADVANCED extras  (NEW v4.0)
   ═══════════════════════════════════════════════════════════════════════ */
function batchFixFolder() {
    try {
        var folder = Folder.selectDialog("Select folder containing SVG files to batch fix");
        if (!folder) return "\u26A0 Cancelled.";
        var files = folder.getFiles("*.svg");
        if (files.length === 0) return "\u26A0 No SVG files found in folder.";
        return "\u2705 Found " + files.length + " SVG files in:\n" + folder.fsName + "\n\nBatch SVG fixing requires the Fix SVG File on Disk function.\nProcess each file individually with FIX > SVG Clean.";
    } catch(e) { return "batchFixFolder error: " + e; }
}

function batchValidateFolder() {
    try {
        var folder = Folder.selectDialog("Select folder containing SVG files to validate");
        if (!folder) return "\u26A0 Cancelled.";
        var files = folder.getFiles("*.svg");
        if (files.length === 0) return "\u26A0 No SVG files found in folder.";
        return "\u2705 Found " + files.length + " SVG files in:\n" + folder.fsName + "\n\nBatch validation scans SVG source. Open each file in Illustrator and run VALIDATE > Full Checklist.";
    } catch(e) { return "batchValidateFolder error: " + e; }
}


/* ═══════════════════════════════════════════════════════════════════════
   §78 — MORE tab extras  (NEW v4.0)
   ═══════════════════════════════════════════════════════════════════════ */
function getDocumentInfo() {
    try {
        var doc = app.activeDocument;
        var seats = []; collectSeats(doc, seats);
        var info = [];
        info.push("=== Document Info ===");
        info.push("Name: " + doc.name);
        try { info.push("Path: " + doc.path.fsName); } catch(e) { info.push("Path: (not saved)"); }
        info.push("Color space: " + (doc.documentColorSpace === DocumentColorSpace.CMYK ? "CMYK" : "RGB"));
        info.push("Artboard: " + Math.round(doc.width) + " x " + Math.round(doc.height) + " px");
        info.push("Layers: " + doc.layers.length);
        info.push("Total page items: " + doc.pageItems.length);
        info.push("Seats (seatData): " + seats.length);
        info.push("Text frames: " + doc.textFrames.length);
        info.push("Symbols: " + (doc.symbolItems ? doc.symbolItems.length : 0));
        info.push("Raster images: " + (doc.rasterItems ? doc.rasterItems.length : 0));
        return info.join("\n");
    } catch(e) { return "getDocumentInfo error: " + e; }
}

function listAllZones() {
    try {
        var doc = app.activeDocument;
        var zones = [];
        for (var i = 0; i < doc.layers.length; i++) {
            var ln = doc.layers[i].name;
            if (ln.indexOf("ZONE") === 0 || /^_x[0-9a-f]+_/.test(ln)) {
                zones.push(ln);
            }
        }
        // Also check for group-based zones
        function scanGroups(obj) {
            if (!obj || !obj.pageItems) return;
            for (var i = 0; i < obj.pageItems.length; i++) {
                var it = obj.pageItems[i];
                if (it.typename === "GroupItem" && it.name &&
                    (it.name.indexOf("ZONE") === 0 || /^_x[0-9a-f]+_/.test(it.name))) {
                    zones.push(it.name + " (group)");
                }
            }
        }
        scanGroups(doc);
        if (zones.length === 0) return "\u26A0 No zone layers/groups found.";
        return "\u2705 Found " + zones.length + " zones:\n\n" + zones.join("\n");
    } catch(e) { return "listAllZones error: " + e; }
}

function totalSeatCount() {
    try {
        var doc = app.activeDocument;
        var seats = []; collectSeats(doc, seats);
        return "\u2705 Total seats: " + seats.length;
    } catch(e) { return "totalSeatCount error: " + e; }
}

function selectAllSeats() {
    try {
        var doc = app.activeDocument;
        var seats = []; collectSeats(doc, seats);
        doc.selection = seats;
        return "\u2705 Selected " + seats.length + " seats.";
    } catch(e) { return "selectAllSeats error: " + e; }
}

/* ═══════════════════════════════════════════════════════════
   §80  ADVANCED — AUTO-DETECT IMPORT
   ═══════════════════════════════════════════════════════════ */

function autoDetectImport(paramsJSON) {
    try {
        var p = eval("(" + paramsJSON + ")");
        var f = File.openDialog("Select source file",
            "All Supported:*.svg;*.json;*.pdf;*.png;*.jpg;*.jpeg;*.ai;*.csv,SVG:*.svg,JSON:*.json,PDF:*.pdf,Images:*.png;*.jpg;*.jpeg,AI:*.ai,CSV:*.csv");
        if (!f) return "Cancelled.";
        var ext = f.name.split(".").pop().toLowerCase();
        var result = "";
        switch (ext) {
            case "svg":
                app.open(f);
                if (p.scale && p.scale !== 1) { for (var i=0;i<app.activeDocument.pageItems.length;i++) app.activeDocument.pageItems[i].resize(p.scale*100,p.scale*100); }
                var sc = 0; collectSeats(app.activeDocument, []); // count
                result = "\u2705 SVG imported: " + app.activeDocument.pathItems.length + " paths";
                break;
            case "json":
                result = jsonToSVG(paramsJSON);
                break;
            case "pdf":
                result = pdfToSVG(paramsJSON);
                break;
            case "png": case "jpg": case "jpeg":
                result = importImageReference(paramsJSON);
                break;
            case "ai":
                app.open(f);
                result = "\u2705 AI file opened: " + app.activeDocument.pathItems.length + " paths, " + app.activeDocument.layers.length + " layers";
                break;
            case "csv":
                result = csvToSVG(paramsJSON);
                break;
            default:
                return "\u26a0 Unsupported file type: " + ext;
        }
        if (p.cleanup && ext !== "csv") removeStrayObjects();
        if (p.buildSOP && ext !== "csv") {
            try {
                var doc = app.activeDocument;
                var order = ["STAGE","DECORATION","SEATLABELS"];
                for (var i=0;i<order.length;i++) {
                    try { doc.layers.getByName(order[i]); } catch(e2) { var L=doc.layers.add(); L.name=order[i]; }
                }
            } catch(e3){}
        }
        return result;
    } catch(e) { return "autoDetectImport error: " + e; }
}

function importImageReference(paramsJSON) {
    try {
        var p = eval("(" + paramsJSON + ")");
        var f = File.openDialog("Select layout image","Images:*.png;*.jpg;*.jpeg;*.tif;*.bmp;*.gif");
        if (!f) return "Cancelled.";
        var doc;
        if (app.documents.length === 0) doc = app.documents.add(DocumentColorSpace.RGB,5000,4000);
        else doc = app.activeDocument;
        var refLayer; try { refLayer = doc.layers.getByName("REFERENCE_IMAGE"); } catch(e2) { refLayer = doc.layers.add(); refLayer.name = "REFERENCE_IMAGE"; }
        refLayer.locked = false;
        var placed = refLayer.placedItems.add();
        placed.file = f;
        placed.position = [0,0];
        var opac = p.opacity || 40;
        refLayer.opacity = opac;
        var imgW = placed.width, imgH = placed.height;
        var gridStep = p.gridStep || 90;
        var gridLayer; try { gridLayer = doc.layers.getByName("GRID_HELPER"); } catch(e3) { gridLayer = doc.layers.add(); gridLayer.name = "GRID_HELPER"; }
        var gc = new RGBColor(); gc.red=100;gc.green=100;gc.blue=255;
        for (var x=0;x<imgW;x+=gridStep) {
            var vl = gridLayer.pathItems.add();
            vl.setEntirePath([[x,0],[x,-imgH]]);
            vl.strokeColor = gc; vl.strokeWidth = 0.25; vl.filled = false;
        }
        for (var y=0;y<imgH;y+=gridStep) {
            var hl = gridLayer.pathItems.add();
            hl.setEntirePath([[0,-y],[imgW,-y]]);
            hl.strokeColor = gc; hl.strokeWidth = 0.25; hl.filled = false;
        }
        refLayer.locked = true; gridLayer.locked = true;
        return "\u2705 Image placed (" + Math.round(imgW) + "\u00d7" + Math.round(imgH) + "px), grid at " + gridStep + "px, opacity " + opac + "%";
    } catch(e) { return "importImageReference error: " + e; }
}

/* ═══════════════════════════════════════════════════════════
   §81  ADVANCED — JSON → SVG CONVERTER
   ═══════════════════════════════════════════════════════════ */

function jsonToSVG(paramsJSON) {
    try {
        var p = eval("(" + paramsJSON + ")");
        var f = File.openDialog("Select JSON file","JSON:*.json,Text:*.txt");
        if (!f) return "Cancelled.";
        f.open("r"); f.encoding = "UTF-8"; var raw = f.read(); f.close();
        var data = eval("(" + raw + ")");
        var scale = p.scale || 1;
        var seats = [];
        // Extract seats based on format
        if (data.venue && data.venue.sections) {
            // Ticketmaster
            var secs = data.venue.sections;
            for (var i=0;i<secs.length;i++) {
                var sec = secs[i]; var rows = sec.rows || [];
                for (var r=0;r<rows.length;r++) {
                    var rs = rows[r].seats || [];
                    for (var s=0;s<rs.length;s++) {
                        seats.push({section:sec.name||String(i),row:rows[r].name||String(r),seat:rs[s].number||(s+1),x:rs[s].x||s*9,y:rs[s].y||(i*200+r*9)});
                    }
                }
            }
        } else if (data.sections && data.sections.length) {
            for (var i=0;i<data.sections.length;i++) {
                var sec = data.sections[i];
                var sl = sec.seats || sec.items || [];
                for (var j=0;j<sl.length;j++) {
                    seats.push({section:sec[p.keySection||"name"]||sec.name||String(i),row:sl[j][p.keyRow||"row"]||"",seat:sl[j][p.keySeat||"seat"]||(j+1),x:sl[j].x||j*9,y:sl[j].y||i*200});
                }
            }
        } else if (data instanceof Array) {
            for (var i=0;i<data.length;i++) {
                var it = data[i];
                seats.push({section:it[p.keySection||"section"]||"A",row:it[p.keyRow||"row"]||"",seat:it[p.keySeat||"seat"]||(i+1),x:parseFloat(it.x)||i*9,y:parseFloat(it.y)||0});
            }
        } else return "\u26a0 Could not detect JSON format.";
        if (seats.length===0) return "\u26a0 No seats found in JSON.";
        // Normalize coords
        var minX=Infinity,minY=Infinity;
        for (var i=0;i<seats.length;i++){if(seats[i].x<minX)minX=seats[i].x;if(seats[i].y<minY)minY=seats[i].y;}
        for (var i=0;i<seats.length;i++){seats[i].x=(seats[i].x-minX+100)*scale;seats[i].y=(seats[i].y-minY+100)*scale;}
        // Create doc
        var doc = app.documents.add(DocumentColorSpace.RGB,5000,4000);
        var order=["STAGE","DECORATION","SEATLABELS"];
        for(var i=0;i<order.length;i++){var L=doc.layers.add();L.name=order[i];}
        var zonesLayer=doc.layers.add();zonesLayer.name="ZONES";
        var sectionMap = {};
        for (var i=0;i<seats.length;i++) {
            var st = seats[i]; var sec = st.section||"A";
            if (!sectionMap[sec]) {
                var zl = zonesLayer.layers.add(); zl.name = "ZONE_"+sec;
                var sl = zl.layers.add(); sl.name = "SEAT";
                var scl = zl.layers.add(); scl.name = "SECTION";
                zl.layers.add().name = "SECTIONDECORATION";
                zl.layers.add().name = "UNDERSEATDECORATION";
                zl.layers.add().name = "SEATDECORATION";
                sectionMap[sec] = {seat:sl, section:scl, count:0};
            }
            var grp = sec + (st.row||"");
            sectionMap[sec].count++;
            var rect = sectionMap[sec].seat.pathItems.rectangle(-st.y,st.x,7,7);
            rect.fillColor = makeColorSafe(204,204,204);
            rect.stroked = false;
            rect.name = "seatData-" + grp.replace(/-/g,"") + "-" + st.seat + "-" + st.seat + "-1-" + djb2Hash(grp + st.seat + i);
        }
        return "\u2705 JSON converted: " + seats.length + " seats from " + Object.keys(sectionMap).length + " sections";
    } catch(e) { return "jsonToSVG error: " + e; }
}

function detectSourceLayout() {
    try {
        var doc = app.activeDocument;
        var allPaths = []; var seats = [];
        function walk(layer) {
            for (var i=0;i<layer.pathItems.length;i++) allPaths.push(layer.pathItems[i]);
            for (var k=0;k<layer.layers.length;k++) walk(layer.layers[k]);
        }
        for (var i=0;i<doc.layers.length;i++) walk(doc.layers[i]);
        for (var p=0;p<allPaths.length;p++) {
            var path = allPaths[p];
            if (Math.abs(path.width-7)<3 && Math.abs(path.height-7)<3) {
                var b = path.geometricBounds;
                seats.push({x:b[1],y:-b[0]});
            }
        }
        if (seats.length === 0) return "\u26a0 No seats detected in document.";
        seats.sort(function(a,b){return a.y-b.y;});
        var rows=[], curRow=null, tol=5;
        for (var s=0;s<seats.length;s++) {
            if (!curRow || Math.abs(seats[s].y-curRow.y)>tol) { curRow={y:seats[s].y,n:0}; rows.push(curRow); }
            curRow.n++;
        }
        var isCurved = false;
        for (var r=0;r<Math.min(rows.length,3);r++) {
            // check Y variance (simplified)
            if (rows[r].n > 30) isCurved = true;
        }
        var venue = isCurved ? "AMPHITHEATRE" : "THEATRE";
        return "\u2705 Layout: " + venue + " | " + seats.length + " seats | " + rows.length + " rows | Avg " + Math.round(seats.length/Math.max(1,rows.length)) + " cols/row";
    } catch(e) { return "detectSourceLayout error: " + e; }
}

/* ═══════════════════════════════════════════════════════════
   §82  ADVANCED — PDF → SVG CONVERTER
   ═══════════════════════════════════════════════════════════ */

function pdfToSVG(paramsJSON) {
    try {
        var p = eval("(" + paramsJSON + ")");
        var f = File.openDialog("Select PDF","PDF:*.pdf");
        if (!f) return "Cancelled.";
        var opts = new PDFFileOptions();
        opts.pDFCropToBox = PDFBoxType.PDFMEDIABOX;
        app.open(f, DocumentColorSpace.RGB, opts);
        var doc = app.activeDocument;
        var scale = p.scale || 3;
        if (scale !== 1) {
            for (var i=0;i<doc.pageItems.length;i++) doc.pageItems[i].resize(scale*100,scale*100);
        }
        var seatMin = p.seatMin || 3, seatMax = p.seatMax || 15;
        var seats=[], junk=[], texts=[];
        function categorize(parent) {
            for (var i=0;i<parent.pathItems.length;i++) {
                var pi = parent.pathItems[i];
                var w=Math.abs(pi.width), h=Math.abs(pi.height);
                var aspect = Math.max(w,h)/Math.max(Math.min(w,h),0.1);
                if (w<0.5 || h<0.5 || pi.opacity===0 || pi.hidden) junk.push(pi);
                else if (w>=seatMin && w<=seatMax && h>=seatMin && h<=seatMax && aspect<2) seats.push(pi);
                else if (w<2 || h<2) junk.push(pi);
            }
            for (var t=0;t<parent.textFrames.length;t++) texts.push(parent.textFrames[t]);
            for (var j=0;j<parent.layers.length;j++) categorize(parent.layers[j]);
        }
        categorize(doc);
        if (p.removeJunk) { for (var j=junk.length-1;j>=0;j--) junk[j].remove(); }
        if (p.normalize) {
            for (var s=0;s<seats.length;s++) {
                var pi = seats[s];
                var cx = pi.left+pi.width/2, cy = pi.top-pi.height/2;
                pi.width=7; pi.height=7; pi.left=cx-3.5; pi.top=cy+3.5;
                pi.fillColor = makeColorSafe(204,204,204);
                pi.stroked = false;
            }
        }
        if (p.buildSOP) {
            var order=["STAGE","DECORATION","SEATLABELS"];
            for(var i=0;i<order.length;i++){try{doc.layers.getByName(order[i]);}catch(e2){var L=doc.layers.add();L.name=order[i];}}
            var zonesLayer; try{zonesLayer=doc.layers.getByName("ZONES");}catch(e3){zonesLayer=doc.layers.add();zonesLayer.name="ZONES";}
            var zoneLayer=zonesLayer.layers.add();zoneLayer.name="ZONE_A";
            var seatLayer=zoneLayer.layers.add();seatLayer.name="SEAT";
            zoneLayer.layers.add().name="SECTION";
            zoneLayer.layers.add().name="SECTIONDECORATION";
            for (var s=0;s<seats.length;s++) {
                seats[s].move(seatLayer,ElementPlacement.PLACEATEND);
                seats[s].name = "seatData-A-"+(s+1)+"-"+(s+1)+"-1-"+djb2Hash("A"+(s+1)+s);
            }
        }
        return "\u2705 PDF processed: " + seats.length + " seats normalized, " + junk.length + " artifacts removed, " + texts.length + " text labels";
    } catch(e) { return "pdfToSVG error: " + e; }
}

/* ═══════════════════════════════════════════════════════════
   §83  ADVANCED — CSV/EXCEL → SVG
   ═══════════════════════════════════════════════════════════ */

function csvToSVG(paramsJSON) {
    try {
        var p = eval("(" + paramsJSON + ")");
        var f = File.openDialog("Select manifest CSV","CSV:*.csv");
        if (!f) return "Cancelled.";
        f.open("r"); f.encoding="UTF-8"; var raw=f.read(); f.close();
        var lines = raw.split(/\r?\n/);
        if (lines.length<2) return "\u26a0 Empty CSV file.";
        var headers = lines[0].split(",");
        for (var h=0;h<headers.length;h++) headers[h] = headers[h].replace(/["']/g,"").trim().toUpperCase();
        var zoneIdx=-1,rowIdx=-1,seatIdx=-1;
        for (var h=0;h<headers.length;h++) {
            var hh = headers[h];
            if (hh.indexOf("ZONE")>=0||hh.indexOf("SECTION")>=0) zoneIdx=h;
            if (hh==="ROW"||hh.indexOf("ROW")>=0) rowIdx=h;
            if ((hh==="SEAT"||hh.indexOf("SEAT")>=0)&&hh.indexOf("COUNT")<0) seatIdx=h;
        }
        var zones = {};
        for (var i=1;i<lines.length;i++) {
            if (!lines[i].trim()) continue;
            var cells = lines[i].split(",");
            var z = zoneIdx>=0 ? (cells[zoneIdx]||"").replace(/["']/g,"").trim() : "A";
            var r = rowIdx>=0 ? (cells[rowIdx]||"").replace(/["']/g,"").trim() : "";
            var s = seatIdx>=0 ? (cells[seatIdx]||"").replace(/["']/g,"").trim() : "";
            if (!z) continue;
            if (!zones[z]) zones[z] = {};
            if (!zones[z][r]) zones[z][r] = [];
            zones[z][r].push(s);
        }
        var step = p.step || 9, startX = p.startX || 500, startY = p.startY || 500, zoneGap = p.zoneGap || 100;
        var doc = app.documents.add(DocumentColorSpace.RGB,5000,4000);
        var order=["STAGE","DECORATION","SEATLABELS"];
        for(var i=0;i<order.length;i++){var L=doc.layers.add();L.name=order[i];}
        var zonesLayer=doc.layers.add();zonesLayer.name="ZONES";
        var curX=startX, curY=startY, totalSeats=0, zoneCount=0;
        for (var zk in zones) {
            if (!zones.hasOwnProperty(zk)) continue;
            var zoneLayer=zonesLayer.layers.add();zoneLayer.name="ZONE_"+zk;
            var seatLayer=zoneLayer.layers.add();seatLayer.name="SEAT";
            zoneLayer.layers.add().name="SECTION";
            zoneLayer.layers.add().name="SECTIONDECORATION";
            zoneLayer.layers.add().name="UNDERSEATDECORATION";
            zoneLayer.layers.add().name="SEATDECORATION";
            var rowKeys=[];for(var rk in zones[zk])rowKeys.push(rk);
            rowKeys.sort();
            var maxCols=0;
            for(var ri=0;ri<rowKeys.length;ri++){if(zones[zk][rowKeys[ri]].length>maxCols)maxCols=zones[zk][rowKeys[ri]].length;}
            for (var ri=0;ri<rowKeys.length;ri++) {
                var rowSeats = zones[zk][rowKeys[ri]];
                for (var ci=0;ci<rowSeats.length;ci++) {
                    var x = curX + ci*step;
                    var y = curY + ri*step;
                    var grp = zk + rowKeys[ri];
                    var seatNum = rowSeats[ci] || String(ci+1);
                    var rect = seatLayer.pathItems.rectangle(-y,x,7,7);
                    rect.fillColor = makeColorSafe(204,204,204);
                    rect.stroked = false;
                    rect.name = "seatData-"+grp.replace(/-/g,"")+"-"+seatNum+"-"+seatNum+"-1-"+djb2Hash(grp+seatNum+totalSeats);
                    totalSeats++;
                }
            }
            curX += maxCols*step+zoneGap;
            if (curX > 4500) { curX=startX; curY+=rowKeys.length*step+zoneGap; }
            zoneCount++;
        }
        return "\u2705 CSV imported: " + totalSeats + " seats across " + zoneCount + " zones";
    } catch(e) { return "csvToSVG error: " + e; }
}

/* ═══════════════════════════════════════════════════════════
   §84  ADVANCED — TURBO BUILD
   ═══════════════════════════════════════════════════════════ */

function turboBuild(paramsJSON) {
    try {
        var p = eval("(" + paramsJSON + ")");
        var startTime = new Date().getTime();
        app.userInteractionLevel = UserInteractionLevel.DONTDISPLAYALERTS;
        var doc = app.documents.add(DocumentColorSpace.RGB, p.canvasW||5000, p.canvasH||4000);
        // Root layers
        var layerNames=["SEATLABELS","DECORATION","STAGE"];
        for(var i=0;i<layerNames.length;i++){var L=doc.layers.add();L.name=layerNames[i];}
        var zonesLayer=doc.layers.add();zonesLayer.name="ZONES";
        // Stage
        var stageLayer=doc.layers.getByName("STAGE");
        var sw=600,sh=100,sx=(p.canvasW||5000-sw)/2,sy=(p.canvasH||4000)-sh-50;
        if(p.stagePos==="top"){sy=50;}else if(p.stagePos==="left"){sx=50;sy=((p.canvasH||4000)-sh)/2;}else if(p.stagePos==="right"){sx=(p.canvasW||5000)-sw-50;sy=((p.canvasH||4000)-sh)/2;}
        var stageRect=stageLayer.pathItems.rectangle(-sy,sx,sw,sh);
        stageRect.fillColor=makeColorSafe(224,224,224);
        stageRect.strokeColor=makeColorSafe(204,204,204);
        stageRect.name="stage_main";
        var decoLayer=doc.layers.getByName("DECORATION");
        var sLabel=decoLayer.textFrames.add();
        sLabel.contents="STAGE";sLabel.position=[sx+sw/2-30,-(sy+sh/2+8)];
        sLabel.textRange.characterAttributes.fillColor=makeColorSafe(109,110,112);
        sLabel.textRange.characterAttributes.size=24;
        // Zones
        var totalSeats=0;
        var zones = p.zones || [];
        var aisles = {};
        if (p.aisleAfter) { var aa=String(p.aisleAfter).split(","); for(var a=0;a<aa.length;a++){var n=parseInt(aa[a],10);if(!isNaN(n))aisles[n]=true;} }
        for (var z=0;z<zones.length;z++) {
            var zone = zones[z];
            var zoneLayer=zonesLayer.layers.add();zoneLayer.name="ZONE_"+zone.code;
            var seatLayer=zoneLayer.layers.add();seatLayer.name="SEAT";
            zoneLayer.layers.add().name="SECTION";
            zoneLayer.layers.add().name="SECTIONDECORATION";
            zoneLayer.layers.add().name="UNDERSEATDECORATION";
            zoneLayer.layers.add().name="SEATDECORATION";
            var R=zone.rows||10, C=zone.cols||20, SX=zone.startX||500, SY=zone.startY||500;
            if (zone.layout==="arc"||zone.layout==="fan") {
                var arcDeg=120,arcRad=arcDeg*Math.PI/180,startAng=-Math.PI/2-arcRad/2;
                var cx=SX,cy=SY,radius=400;
                for(var r=0;r<R;r++){
                    var rowLetter=r<26?String.fromCharCode(65+r):String.fromCharCode(65+Math.floor(r/26)-1)+String.fromCharCode(65+r%26);
                    var rad=radius+r*9;var arcStep=arcRad/Math.max(1,C-1);
                    for(var c=0;c<C;c++){
                        var angle=startAng+c*arcStep;
                        var seatX=cx+rad*Math.cos(angle)-3.5;
                        var seatY=cy+rad*Math.sin(angle)-3.5;
                        var rect=seatLayer.pathItems.rectangle(seatY,seatX,7,7);
                        rect.fillColor=makeColorSafe(204,204,204);rect.stroked=false;
                        rect.name="seatData-"+zone.code+rowLetter+"-"+(c+1)+"-"+(c+1)+"-1-"+djb2Hash(zone.code+rowLetter+(c+1)+totalSeats);
                        totalSeats++;
                    }
                }
            } else {
                for(var r=0;r<R;r++){
                    var rowLetter=r<26?String.fromCharCode(65+r):String.fromCharCode(65+Math.floor(r/26)-1)+String.fromCharCode(65+r%26);
                    var aisleOffset=0;
                    for(var c=0;c<C;c++){
                        if(aisles[c])aisleOffset+=18;
                        var x=SX+c*9+aisleOffset;
                        var y=SY+r*9;
                        var rect=seatLayer.pathItems.rectangle(-y,x,7,7);
                        rect.fillColor=makeColorSafe(204,204,204);rect.stroked=false;
                        rect.name="seatData-"+zone.code+rowLetter+"-"+(c+1)+"-"+(c+1)+"-1-"+djb2Hash(zone.code+rowLetter+(c+1)+totalSeats);
                        totalSeats++;
                    }
                }
            }
        }
        app.userInteractionLevel = UserInteractionLevel.DISPLAYALERTS;
        app.redraw();
        var elapsed = ((new Date().getTime()-startTime)/1000).toFixed(2);
        return "\u2705 TURBO BUILD: "+totalSeats+" seats in "+zones.length+" zones ("+elapsed+"s, "+Math.round(totalSeats/parseFloat(elapsed))+" seats/s)";
    } catch(e) { app.userInteractionLevel = UserInteractionLevel.DISPLAYALERTS; return "turboBuild error: " + e; }
}

function buildFromScratchInteractive() {
    try {
        return "\u2705 Use the Turbo Build mode with zone config lines. Format: code,rows,cols,layout,startX,startY";
    } catch(e) { return "buildFromScratchInteractive error: " + e; }
}

/* ═══════════════════════════════════════════════════════════
   §85  ADVANCED — SPEED BUILD
   ═══════════════════════════════════════════════════════════ */

function speedBuildComplete(outputName) {
    try {
        if (app.documents.length===0) return "\u26a0 No document open. Open an SVG/AI first.";
        var doc = app.activeDocument;
        var startTime = new Date().getTime();
        // Phase 1: detect layout
        var seats=[]; collectSeats(doc,seats);
        var seatCount = seats.length;
        // Phase 2: build SOP layers if missing
        var order=["STAGE","DECORATION","SEATLABELS"];
        for(var i=0;i<order.length;i++){try{doc.layers.getByName(order[i]);}catch(e2){var L=doc.layers.add();L.name=order[i];}}
        // Phase 3: enforce geometry
        for (var s=0;s<seats.length;s++){
            var p=seats[s];
            if(Math.abs(p.width-7)>0.1){p.width=7;}
            if(Math.abs(p.height-7)>0.1){p.height=7;}
            p.stroked=false;
        }
        // Phase 4: export
        var folder = doc.path || Folder.desktop;
        var outSVG = new File(folder+"/"+outputName+".svg");
        var opts = new ExportOptionsSVG();
        opts.embedRasterImages=false;opts.coordinatePrecision=1;opts.cssProperties=SVGCSSPropertyLocation.STYLEATTRIBUTES;
        opts.documentEncoding=SVGDocumentEncoding.UTF8;opts.compressed=false;
        safeExportSVG(doc,outSVG,opts);
        // Phase 5: post-process
        outSVG.open("r"); var svg=outSVG.read(); outSVG.close();
        svg=svg.replace(/<rect([^>]*?id="seatData-[^"]+"[^>]*?)(\/?)>/g,function(m,attrs){
            if(attrs.indexOf("rx=")<0)attrs+=" rx=\"1.5\" ry=\"1.5\"";
            return "<rect"+attrs+"/>";
        });
        svg=svg.replace(/<!--[\s\S]*?-->/g,"");
        svg=svg.replace(/<metadata[\s\S]*?<\/metadata>/g,"");
        outSVG.open("w");outSVG.write(svg);outSVG.close();
        var elapsed=((new Date().getTime()-startTime)/1000).toFixed(2);
        return "\u2705 Speed Build complete: "+seatCount+" seats, exported to "+outputName+".svg ("+elapsed+"s)";
    } catch(e) { return "speedBuildComplete error: " + e; }
}

// snapshotVersion, hashRegistryCheck, venueStatusReport are defined earlier
// (full implementations at §38, §40, §41) — stub duplicates removed (v6.5.1 dedup fix)

/* ═══════════════════════════════════════════════════════════
   §86  ADVANCED — AUTO-HEALER (15 operations)
   ═══════════════════════════════════════════════════════════ */

function autoHealAll() {
    try {
        var doc=app.activeDocument;var fixes=0;var log=[];
        // 1. Fix layer names
        var r1=healSublayerNames();log.push("1. Layer names: "+r1);if(r1.indexOf("\u2705")>=0)fixes++;
        // 2. Duplicate IDs
        var r2=healDuplicateIDs();log.push("2. Duplicate IDs: "+r2);if(r2.indexOf("\u2705")>=0)fixes++;
        // 3. Malformed IDs
        var r3=healMalformedIDs();log.push("3. Malformed IDs: "+r3);if(r3.indexOf("\u2705")>=0)fixes++;
        // 4. Seat geometry
        var r4=healSeatGeometry();log.push("4. Seat geometry: "+r4);if(r4.indexOf("\u2705")>=0)fixes++;
        // 5. Seat colors
        var r5=healSeatColors();log.push("5. Seat colors: "+r5);if(r5.indexOf("\u2705")>=0)fixes++;
        // 6. Section colors
        var r6=healSectionColors();log.push("6. Section colors: "+r6);if(r6.indexOf("\u2705")>=0)fixes++;
        // 7. Text colors
        var r7=healTextColors();log.push("7. Text colors: "+r7);if(r7.indexOf("\u2705")>=0)fixes++;
        // 8. Overlaps
        var r8=healOverlappingSeats();log.push("8. Overlaps: "+r8);
        // 9. Orphan seats
        var r9=healOrphanSeats();log.push("9. Orphan seats: "+r9);if(r9.indexOf("\u2705")>=0)fixes++;
        // 10. Missing sublayers
        var r10=healMissingSublayers();log.push("10. Sublayers: "+r10);if(r10.indexOf("\u2705")>=0)fixes++;
        // 11. Hidden layers
        var r11=healHiddenLayers();log.push("11. Hidden: "+r11);if(r11.indexOf("\u2705")>=0)fixes++;
        // 12. Locked layers
        var r12=healLockedLayers();log.push("12. Locked: "+r12);if(r12.indexOf("\u2705")>=0)fixes++;
        // 13. Empty groups
        var r13=healEmptyGroups();log.push("13. Empty groups: "+r13);if(r13.indexOf("\u2705")>=0)fixes++;
        // 14. Out of bounds
        var r14=healOutOfBounds();log.push("14. Bounds: "+r14);
        // 15. Stage tag
        var r15=healStageDirection();log.push("15. Stage tag: "+r15);if(r15.indexOf("\u2705")>=0)fixes++;
        return "\u2705 AUTO-HEAL COMPLETE: "+fixes+"/15 operations applied\n"+log.join("\n");
    } catch(e) { return "autoHealAll error: " + e; }
}

function healSublayerNames() { return fixSubLayerNames(); }

function healDuplicateIDs() {
    try {
        var doc=app.activeDocument;var seats=[];collectSeats(doc,seats);
        var seen={};var fixed=0;
        for(var i=0;i<seats.length;i++){
            if(seen[seats[i].name]){
                var parts=seats[i].name.split("-");
                if(parts.length>=6){parts[5]=djb2Hash(parts[1]+parts[2]+i+Math.random());seats[i].name=parts.join("-");fixed++;}
            }
            seen[seats[i].name]=1;
        }
        return fixed>0?("\u2705 Re-hashed "+fixed+" duplicate IDs"):("\u2705 No duplicate IDs");
    } catch(e) { return "healDuplicateIDs error: " + e; }
}

function healMalformedIDs() {
    try {
        var doc=app.activeDocument;var seats=[];collectSeats(doc,seats);
        var pattern=/^seatData-([A-Za-z0-9_]+)-(\d+)-\2-1-[a-f0-9]{6,13}$/;
        var fixed=0;
        for(var i=0;i<seats.length;i++){
            if(!pattern.test(seats[i].name)){
                var m=seats[i].name.match(/seatData-([^-]+)-(\d+)/);
                var grp=m?m[1].replace(/-/g,""):"X";
                var seat=m?m[2]:String(i+1);
                seats[i].name="seatData-"+grp+"-"+seat+"-"+seat+"-1-"+djb2Hash(grp+seat+i);
                fixed++;
            }
        }
        return fixed>0?("\u2705 Repaired "+fixed+" malformed IDs"):("\u2705 All IDs valid");
    } catch(e) { return "healMalformedIDs error: " + e; }
}

function healSeatGeometry() {
    try {
        var doc=app.activeDocument;var seats=[];collectSeats(doc,seats);var fixed=0;
        for(var i=0;i<seats.length;i++){
            var changed=false;
            if(Math.abs(seats[i].width-7)>0.1){seats[i].width=7;changed=true;}
            if(Math.abs(seats[i].height-7)>0.1){seats[i].height=7;changed=true;}
            try{if(seats[i].stroked){seats[i].stroked=false;changed=true;}}catch(e2){}
            if(changed)fixed++;
        }
        return fixed>0?("\u2705 Normalized "+fixed+" seats to 7\u00d77"):("\u2705 All seats 7\u00d77");
    } catch(e) { return "healSeatGeometry error: " + e; }
}

function healSeatColors() {
    try {
        var doc=app.activeDocument;var seats=[];collectSeats(doc,seats);var fixed=0;
        var defColor=makeColorSafe(204,204,204);
        for(var i=0;i<seats.length;i++){
            try {
                var f=seats[i].fillColor;
                if(!f||f.typename==="NoColor"){seats[i].fillColor=defColor;fixed++;}
            } catch(e2){seats[i].fillColor=defColor;fixed++;}
        }
        return fixed>0?("\u2705 Reset "+fixed+" seat colors"):("\u2705 All seat colors OK");
    } catch(e) { return "healSeatColors error: " + e; }
}

function healSectionColors() {
    if(!app.documents.length)return 'ERROR: No document open.';var changed=0,failed=0;
    ywWalkArtwork(app.activeDocument,function(n){if(n.typename==='PathItem'&&n.parent&&/^SECTION(?:_\d+_)?$/.test(n.parent.name))try{n.filled=true;n.fillColor=makeColorSafe(241,241,241);n.stroked=true;n.strokeColor=makeColorSafe(209,210,212);n.strokeWidth=1;changed++;}catch(e){failed++;}});
    return (failed?'ERROR: ':'\u2705 ')+'Section colours: '+changed+' updated, '+failed+' blocked.';
}

function healTextColors() {
    if(!app.documents.length)return 'ERROR: No document open.';var changed=0,failed=0;
    ywWalkArtwork(app.activeDocument,function(n){if(n.typename==='TextFrame')try{n.textRange.characterAttributes.fillColor=makeColorSafe(109,110,112);n.textRange.characterAttributes.strokeColor=new NoColor();changed++;}catch(e){failed++;}});
    return (failed?'ERROR: ':'\u2705 ')+'Text colours: '+changed+' updated, '+failed+' blocked. Font size and position preserved.';
}

function healOverlappingSeats() {
    try{var r=ywSOPAuditData();for(var i=0;i<r.checks.length;i++)if(r.checks[i].name==='Minimum seat gap 2 px')return (r.checks[i].status==='PASS'?'\u2705 ':'REVIEW: ')+r.checks[i].detail+'. No seats moved.';}catch(e){return 'ERROR: Seat gap check: '+e;}
}

function healOrphanSeats() {
    try{var r=ywSOPAuditData();for(var i=0;i<r.checks.length;i++)if(r.checks[i].name==='All seats inside SEAT containers')return (r.checks[i].status==='PASS'?'\u2705 ':'REVIEW: ')+r.checks[i].detail+'. No seats moved; assign orphan seats to their intended zones explicitly.';}catch(e){return 'ERROR: Orphan check: '+e;}
}

function healMissingSublayers() {
    if(!app.documents.length)return 'ERROR: No document open.';var zones=[],created=0,failed=0,required=['SECTION','UNDERSEATDECORATION','SEAT','SEATDECORATION','SECTIONDECORATION'];
    ywWalkArtwork(app.activeDocument,function(n){if((n.typename==='Layer'||n.typename==='GroupItem')&&/^ZONE_/.test(n.name))zones.push(n);});
    for(var z=0;z<zones.length;z++)for(var k=0;k<required.length;k++){var zone=zones[z],found=false,i;if(zone.layers)for(i=0;i<zone.layers.length;i++)if(zone.layers[i].parent===zone&&zone.layers[i].name===required[k])found=true;if(zone.pageItems)for(i=0;i<zone.pageItems.length;i++)if(zone.pageItems[i].parent===zone&&zone.pageItems[i].name===required[k])found=true;if(!found)try{var n=zone.typename==='Layer'?zone.layers.add():zone.groupItems.add();n.name=required[k];created++;}catch(e){failed++;}}
    return (failed?'ERROR: ':zones.length?'\u2705 ':'REVIEW: ')+zones.length+' zones inspected; '+created+' containers created; '+failed+' blocked. Empty SECTION shapes still require building.';
}

function healHiddenLayers() {
    try {
        var doc=app.activeDocument;var fixed=0;
        function walk(parent){for(var i=0;i<parent.layers.length;i++){var L=parent.layers[i];if(!L.visible){L.visible=true;fixed++;}if(L.layers.length)walk(L);}}
        walk(doc);
        return fixed>0?("\u2705 Unhid "+fixed+" layers"):("\u2705 All layers visible");
    } catch(e) { return "healHiddenLayers error: " + e; }
}

function healLockedLayers() {
    try {
        var doc=app.activeDocument;var fixed=0;
        function walk(parent){for(var i=0;i<parent.layers.length;i++){var L=parent.layers[i];if(L.locked){L.locked=false;fixed++;}if(L.layers.length)walk(L);}}
        walk(doc);
        return fixed>0?("\u2705 Unlocked "+fixed+" layers"):("\u2705 All layers unlocked");
    } catch(e) { return "healLockedLayers error: " + e; }
}

function healEmptyGroups() { return cleanEmptyGroups(); }

function healOutOfBounds() {
    try{var r=ywSOPAuditData();for(var i=0;i<r.checks.length;i++)if(r.checks[i].name==='Seats inside active artboard')return (r.checks[i].status==='PASS'?'\u2705 ':'REVIEW: ')+r.checks[i].detail+' on active artboard. No seats moved.';}catch(e){return 'ERROR: Bounds check: '+e;}
}

function healStageDirection() {
    try {
        var doc=app.activeDocument;var fixed=0;
        try{
            var stage=doc.layers.getByName("STAGE");
            for(var i=0;i<stage.pageItems.length;i++){
                if(stage.pageItems[i].name.indexOf("stage")<0){
                    stage.pageItems[i].name="stage_"+(stage.pageItems[i].name||"main");fixed++;
                }
            }
        }catch(e2){}
        return fixed>0?("\u2705 Tagged "+fixed+" stage elements"):("\u2705 Stage already tagged");
    } catch(e) { return "healStageDirection error: " + e; }
}

function batchFixAllAndSave() {
    try {
        var r = autoHealAll();
        var doc=app.activeDocument;
        if(doc.fullName)doc.save();
        return r + "\n\u2705 Document saved.";
    } catch(e) { return "batchFixAllAndSave error: " + e; }
}

/* ═══════════════════════════════════════════════════════════
   §87  ADVANCED — DEEP CLEAN
   ═══════════════════════════════════════════════════════════ */

function deepCleanScan() {
    try {
        var doc=app.activeDocument;
        var hidden=0,zeroSize=0,tiny=0,stray=0,empty=0,lowOp=0;
        function scan(parent){
            for(var i=0;i<parent.pathItems.length;i++){
                var p=parent.pathItems[i];
                if(p.name&&p.name.indexOf("seatData-")===0)continue;
                var w=Math.abs(p.width),h=Math.abs(p.height);
                if(p.hidden)hidden++;
                if(w<0.5||h<0.5)zeroSize++;
                else if(w<2&&h<2)tiny++;
                if((w<1||h<1)&&w!==h)stray++;
                if(p.opacity<5)lowOp++;
            }
            for(var j=0;j<parent.layers.length;j++){
                if(parent.layers[j].pageItems.length===0&&parent.layers[j].layers.length===0)empty++;
                scan(parent.layers[j]);
            }
        }
        scan(doc);
        var total=hidden+zeroSize+tiny+stray+empty+lowOp;
        return "\ud83d\udd0d SCAN: Hidden:"+hidden+" Zero:"+zeroSize+" Tiny:"+tiny+" Stray:"+stray+" Empty:"+empty+" LowOp:"+lowOp+" | TOTAL REMOVABLE: "+total;
    } catch(e) { return "deepCleanScan error: " + e; }
}

function deepCleanExecute(paramsJSON) {
    try {
        var p=eval("("+paramsJSON+")");
        var doc=app.activeDocument;var removed=0;var protected_=0;
        function cleanLayer(parent){
            for(var i=parent.pathItems.length-1;i>=0;i--){
                var pi=parent.pathItems[i];
                if(p.protectSeats&&pi.name&&pi.name.indexOf("seatData-")===0){protected_++;continue;}
                if(p.protectStage&&pi.name&&pi.name.indexOf("stage")>=0){protected_++;continue;}
                var w=Math.abs(pi.width),h=Math.abs(pi.height);
                var shouldRemove=false;
                if(p.invisible&&pi.hidden)shouldRemove=true;
                if(p.zeroSize&&(w<0.5||h<0.5))shouldRemove=true;
                if(p.tiny&&w<2&&h<2&&(!pi.name||pi.name.indexOf("seatData")<0))shouldRemove=true;
                if(p.lowOpacity&&pi.opacity<5)shouldRemove=true;
                if(p.stray&&(w<1||h<1)&&w!==h)shouldRemove=true;
                if(p.guides&&pi.guides)shouldRemove=true;
                if(shouldRemove){pi.remove();removed++;}
            }
            if(p.suffix){
                for(var k=0;k<parent.layers.length;k++){
                    var L=parent.layers[k];
                    var clean=L.name.replace(/_\d+_$/,"");
                    if(clean!==L.name)L.name=clean;
                }
            }
            if(p.whiteFill&&(parent.name==="SECTION"||/^SECTION_\d+_$/.test(parent.name))){
                for(var i=0;i<parent.pathItems.length;i++){
                    var pi=parent.pathItems[i];
                    try{if(pi.fillColor.red>250&&pi.fillColor.green>250&&pi.fillColor.blue>250){pi.fillColor=makeColorSafe(241,241,241);pi.strokeColor=makeColorSafe(209,210,212);}}catch(e2){}
                }
            }
            for(var j=0;j<parent.layers.length;j++)cleanLayer(parent.layers[j]);
            if(p.empty){
                for(var k=parent.layers.length-1;k>=0;k--){
                    var L=parent.layers[k];
                    if(L.pageItems.length===0&&L.layers.length===0){
                        var sopLayers=["STAGE","DECORATION","ZONES","SEATLABELS","SECTION","SEAT","SEATDECORATION","SECTIONDECORATION","UNDERSEATDECORATION"];
                        var isSOP=false;for(var s=0;s<sopLayers.length;s++){if(L.name===sopLayers[s]||L.name.indexOf("ZONE_")===0){isSOP=true;break;}}
                        if(!isSOP){L.remove();removed++;}
                    }
                }
            }
        }
        cleanLayer(doc);
        if(p.duplicates){
            var allSeats=[];collectSeats(doc,allSeats);
            for(var a=allSeats.length-1;a>=1;a--){
                for(var b=a-1;b>=0;b--){
                    if(Math.abs(allSeats[a].left-allSeats[b].left)<0.5&&Math.abs(allSeats[a].top-allSeats[b].top)<0.5){
                        allSeats[a].remove();removed++;break;
                    }
                }
            }
        }
        return "\u2705 DEEP CLEAN: Removed "+removed+" items, Protected "+protected_+" items";
    } catch(e) { return "deepCleanExecute error: " + e; }
}

/* ═══════════════════════════════════════════════════════════
   §88  ADVANCED — SVG OPTIMIZER
   ═══════════════════════════════════════════════════════════ */

function optimizeSVGFile() {
    try {
        var f=File.openDialog("Select SVG to optimize","*.svg");
        if(!f)return "Cancelled.";
        f.encoding="UTF-8";f.open("r");var svg=f.read();f.close();
        var before=f.length;
        svg=svg.replace(/<!--[\s\S]*?-->/g,"");
        svg=svg.replace(/<metadata[\s\S]*?<\/metadata>/g,"");
        svg=svg.replace(/<defs>\s*<\/defs>/g,"");
        svg=svg.replace(/<title>[\s\S]*?<\/title>/g,"");
        svg=svg.replace(/<desc>[\s\S]*?<\/desc>/g,"");
        svg=svg.replace(/(\d+\.\d{2,})/g,function(m){return parseFloat(m).toFixed(1);});
        svg=svg.replace(/>\s+</g,"><");
        svg=svg.replace(/\s{2,}/g," ");
        svg=svg.replace(/\s*stroke-width="0"/g,"");
        svg=svg.replace(/\s*opacity="1"/g,"");
        var out=new File(f.fsName.replace(/\.svg$/,"_OPT.svg"));
        out.encoding="UTF-8";out.open("w");out.write(svg);out.close();
        var after=out.length;
        var saved=((1-after/before)*100).toFixed(1);
        return "\u2705 Optimized: "+(before/1024).toFixed(1)+"KB \u2192 "+(after/1024).toFixed(1)+"KB (saved "+saved+"%)";
    } catch(e) { return "optimizeSVGFile error: " + e; }
}

function reduceSVGDecimals() {
    try {
        var f=File.openDialog("Select SVG","*.svg");if(!f)return "Cancelled.";
        f.encoding="UTF-8";f.open("r");var svg=f.read();f.close();
        svg=svg.replace(/(\d+\.\d{2,})/g,function(m){return parseFloat(m).toFixed(1);});
        f.open("w");f.write(svg);f.close();
        return "\u2705 Reduced all decimals to 1dp";
    } catch(e) { return "reduceSVGDecimals error: " + e; }
}

function collapseSVGWhitespace() {
    try {
        var f=File.openDialog("Select SVG","*.svg");if(!f)return "Cancelled.";
        f.encoding="UTF-8";f.open("r");var svg=f.read();f.close();
        var before=svg.length;
        svg=svg.replace(/>\s+</g,"><");svg=svg.replace(/\s{2,}/g," ");
        f.open("w");f.write(svg);f.close();
        return "\u2705 Collapsed whitespace: saved "+(before-svg.length)+" chars";
    } catch(e) { return "collapseSVGWhitespace error: " + e; }
}

function injectSeatRxRy() {
    try {
        var f=File.openDialog("Select SVG","*.svg");if(!f)return "Cancelled.";
        f.encoding="UTF-8";f.open("r");var svg=f.read();f.close();
        var count=0;
        svg=svg.replace(/<rect([^>]*?id="seatData-[^"]+"[^>]*?)(\/?)>/g,function(m,attrs){
            if(attrs.indexOf("rx=")<0){attrs+=' rx="1.5" ry="1.5"';count++;}
            return "<rect"+attrs+"/>";
        });
        f.open("w");f.write(svg);f.close();
        return "\u2705 Injected rx/ry on "+count+" seats";
    } catch(e) { return "injectSeatRxRy error: " + e; }
}

function fixSectionWhiteInSVG() {
    try {
        var f=File.openDialog("Select SVG","*.svg");if(!f)return "Cancelled.";
        f.encoding="UTF-8";f.open("r");var svg=f.read();f.close();
        var count=0;
        svg=svg.replace(/fill="#[Ff]{6}"/g,function(){count++;return 'fill="#F1F1F1"';});
        f.open("w");f.write(svg);f.close();
        return "\u2705 Fixed "+count+" #FFFFFF \u2192 #F1F1F1";
    } catch(e) { return "fixSectionWhiteInSVG error: " + e; }
}

function sopExportFull(outputName) {
 try {
  if(!app.documents.length)return "ERROR: No document open.";
  var doc=app.activeDocument,folder;try{folder=doc.path;}catch(e){folder=Folder.selectDialog("Choose export folder");}
  if(!folder)return "Export cancelled.";
  var name=String(outputName||"hallmap").replace(/[^A-Za-z0-9_-]/g,"_");
  var file=new File(folder.fsName+"/"+name+".svg");safeExportSVG(doc,file,safeSOPExportOpts());
  var opt=new File(folder.fsName+"/"+name+"_OPT.svg");
  if(!file.copy(opt.fsName))return "ERROR: SVG exported, but optimized copy could not be written.";
  return "SOP export complete: "+file.fsName+" and "+opt.fsName+". Geometry and text precision preserved.";
 }catch(e){return "ERROR: SOP export: "+e;}
}

/* ═══════════════════════════════════════════════════════════
   §89  ADVANCED — QA 50-ITEM CHECK
   ═══════════════════════════════════════════════════════════ */

function fullQA50() {
    try {var r=ywSOPAuditData(),lines=['SOP QA: '+r.pass+' PASS / '+r.fail+' FAIL / '+r.pending+' PENDING ('+r.checks.length+' checks)','Read-only audit. Pending checks are NOT approval to upload.',''];for(var i=0;i<r.checks.length;i++){var c=r.checks[i];lines.push((i+1)+'. ['+c.status+'] '+c.name+(c.detail?' - '+c.detail:''));}return lines.join('\n');}catch(e){return 'ERROR: SOP QA: '+e;}
}

function quickValidate() {
    try {
        var doc=app.activeDocument;var seats=[];collectSeats(doc,seats);
        var seatIDs={},dups=0,badIDs=0,badGeom=0;
        var pattern=/^seatData-[A-Za-z0-9_]+-(\d+)-\1-1-[a-f0-9]{6,13}$/;
        for(var i=0;i<seats.length;i++){
            if(seatIDs[seats[i].name])dups++;else seatIDs[seats[i].name]=1;
            if(!pattern.test(seats[i].name))badIDs++;
            if(Math.abs(seats[i].width-7)>0.5||Math.abs(seats[i].height-7)>0.5)badGeom++;
        }
        var hasStage=false;try{hasStage=doc.layers.getByName("STAGE").pageItems.length>0;}catch(e2){}
        var results=[];
        results.push(hasStage?"\u2714 STAGE present":"\u2718 STAGE missing");
        results.push(dups===0?"\u2714 No duplicate IDs":"\u2718 "+dups+" duplicate IDs");
        results.push(badIDs===0?"\u2714 All IDs valid":"\u2718 "+badIDs+" malformed IDs");
        results.push(badGeom===0?"\u2714 All seats 7x7":"\u2718 "+badGeom+" wrong size");
        results.push("\u2714 Total: "+seats.length+" seats");
        return results.join("\n");
    } catch(e) { return "quickValidate error: " + e; }
}

function fullDiagnosticTroubleshoot() {
    try {
        var doc=app.activeDocument;var critical=[],warnings=[],info=[];
        // Check 1: Layer structure
        var required=["STAGE","DECORATION","SEATLABELS"];
        for(var r=0;r<required.length;r++){try{doc.layers.getByName(required[r]);}catch(e2){critical.push("Missing layer: "+required[r]);}}
        // Check 2: Seat IDs
        var seats=[];collectSeats(doc,seats);
        var seatIDs={},dups=0,badIDs=0;
        var pattern=/^seatData-[A-Za-z0-9_]+-(\d+)-\1-1-[a-f0-9]{6,13}$/;
        for(var i=0;i<seats.length;i++){if(seatIDs[seats[i].name])dups++;else seatIDs[seats[i].name]=1;if(!pattern.test(seats[i].name))badIDs++;}
        if(dups>0)critical.push(dups+" duplicate IDs");
        if(badIDs>0)critical.push(badIDs+" malformed IDs");
        // Check 3: Geometry
        var badGeom=0;for(var i=0;i<seats.length;i++){if(Math.abs(seats[i].width-7)>0.5||Math.abs(seats[i].height-7)>0.5)badGeom++;}
        if(badGeom>0)warnings.push(badGeom+" seats not 7x7");
        // Check 4: Colours
        info.push("Seat count: "+seats.length);
        info.push("Document: "+doc.name);
        // Check 5: _n_ suffixes
        var hasSuffix=false;
        function checkSuffix(parent){for(var i=0;i<parent.layers.length;i++){if(/_\d+_$/.test(parent.layers[i].name))hasSuffix=true;checkSuffix(parent.layers[i]);}}
        checkSuffix(doc);
        if(hasSuffix)critical.push("Layer names have _n_ suffixes");
        var status=critical.length===0?"PASS":"FAIL";
        return "DIAGNOSTIC: "+status+"\n\nCRITICAL ("+critical.length+"):\n"+(critical.length?critical.join("\n"):"None")+"\n\nWARNINGS ("+warnings.length+"):\n"+(warnings.length?warnings.join("\n"):"None")+"\n\nINFO:\n"+info.join("\n");
    } catch(e) { return "fullDiagnosticTroubleshoot error: " + e; }
}

// ═══════════════════════════════════════════════════════════════
//  SEAT RESIZER & REFLOW  (050-Yousufweiji_SeatResizer.jsx v2.1)
//  CEP-callable: seatResizerRun(paramsJSON)
//  params: { mode:"reflow"|"resize", removeStroke:bool,
//            alignRowY:bool, previewOnly:bool,
//            aisleThresh:number, rowTolerance:number }
// ═══════════════════════════════════════════════════════════════

function seatResizerRun(paramsJSON) {
    try {
        if (app.documents.length === 0) return "ERROR:\nNo document open.";
        var doc = app.activeDocument;

        var p = {};
        try { p = eval("(" + paramsJSON + ")"); } catch (pe) { p = {}; }
        var doReflow     = (p.mode !== "resize");
        var removeStroke = (p.removeStroke  !== false);
        var alignRowY    = (p.alignRowY     !== false);
        var previewOnly  = (p.previewOnly   === true);
        var aisleThresh  = parseFloat(p.aisleThresh)  || 20;
        var ROW_TOL      = parseFloat(p.rowTolerance) || 4;
        var SEAT_W = 7, SEAT_H = 7, SLOT_STEP = 9;

        function srGetCentre(item) {
            var gb = item.geometricBounds;
            return { x: (gb[0]+gb[2])/2, y: (gb[1]+gb[3])/2 };
        }
        function srGetSize(item) {
            var gb = item.geometricBounds;
            return { w: Math.abs(gb[2]-gb[0]), h: Math.abs(gb[1]-gb[3]) };
        }
        function srPlaceSeat(item, cx, cy) {
            var sz = srGetSize(item);
            if (sz.w < 0.01 || sz.h < 0.01) return false;
            item.resize((SEAT_W/sz.w)*100, (SEAT_H/sz.h)*100, true, true, true, true, (SEAT_W/sz.w)*100);
            item.position = [cx - SEAT_W/2, cy + SEAT_H/2];
            return true;
        }
        function srRemoveStroke(item) {
            try {
                if (item.typename === "PathItem") { item.stroked = false; }
                else if (item.typename === "CompoundPathItem") {
                    for (var p2=0; p2<item.pathItems.length; p2++) item.pathItems[p2].stroked = false;
                }
            } catch (e) {}
        }
        function srIsSeat(item) { return item.name && item.name.indexOf("seatData-") === 0; }
        function srCollectAll(container, results) {
            var i;
            if (container.pageItems) {
                for (i=0; i<container.pageItems.length; i++) {
                    if (srIsSeat(container.pageItems[i])) results.push(container.pageItems[i]);
                    if (container.pageItems[i].pageItems) srCollectAll(container.pageItems[i], results);
                }
            }
            if (container.layers) {
                for (i=0; i<container.layers.length; i++) srCollectAll(container.layers[i], results);
            }
        }
        function srDetectRows(seatList) {
            var infos = [];
            for (var i=0; i<seatList.length; i++) {
                var c = srGetCentre(seatList[i]), s = srGetSize(seatList[i]);
                infos.push({ item: seatList[i], cx: c.x, cy: c.y, w: s.w, h: s.h });
            }
            infos.sort(function(a,b){return b.cy-a.cy;});
            var rows=[], used=[];
            for (var u=0; u<infos.length; u++) used.push(false);
            for (var j=0; j<infos.length; j++) {
                if (used[j]) continue;
                var row=[infos[j]]; used[j]=true;
                var rowYSum=infos[j].cy, rowYCount=1;
                for (var k=j+1; k<infos.length; k++) {
                    if (used[k]) continue;
                    if (Math.abs(infos[k].cy-(rowYSum/rowYCount)) <= ROW_TOL) {
                        row.push(infos[k]); used[k]=true; rowYSum+=infos[k].cy; rowYCount++;
                    }
                }
                row.sort(function(a,b){return a.cx-b.cx;});
                rows.push(row);
            }
            rows.sort(function(a,b){return b[0].cy-a[0].cy;});
            return rows;
        }
        function srReflowRow(row, aisleT, doAY) {
            if (row.length===0) return [];
            var rowY=row[0].cy;
            if (doAY && row.length>1) {
                var yVals=[];
                for (var m=0; m<row.length; m++) yVals.push(row[m].cy);
                yVals.sort(function(a,b){return a-b;});
                rowY=yVals[Math.floor(yVals.length/2)];
            }
            var gaps=[];
            for (var g=1; g<row.length; g++) gaps.push(row[g].cx-row[g-1].cx);
            var segments=[], segStart=0;
            for (var a=0; a<gaps.length; a++) {
                if (gaps[a]>aisleT) { segments.push({start:segStart,end:a}); segStart=a+1; }
            }
            segments.push({start:segStart,end:row.length-1});
            var results=[], currentX=row[0].cx;
            for (var si=0; si<segments.length; si++) {
                var seg=segments[si];
                if (si>0) {
                    var origGap=row[seg.start].cx-row[seg.start-1].cx;
                    var aisleSlots=Math.round(origGap/SLOT_STEP);
                    if (aisleSlots<3) aisleSlots=3;
                    currentX+=aisleSlots*SLOT_STEP;
                }
                for (var idx=seg.start; idx<=seg.end; idx++) {
                    results.push({item:row[idx].item,newCx:currentX,newCy:doAY?rowY:row[idx].cy});
                    if (idx<seg.end) currentX+=SLOT_STEP;
                }
            }
            return results;
        }

        app.executeMenuCommand("deselectall");
        var seatItems=[];
        srCollectAll(doc, seatItems);
        if (seatItems.length===0)
            return "ERROR:\nNo seatData-* elements found.\nElements must be named: seatData-{GROUP}-{N}-{N}-1-{HASH}";

        var sizeBuckets={};
        for (var ps=0; ps<seatItems.length; ps++) {
            var psz=srGetSize(seatItems[ps]);
            var sKey=(Math.round(psz.w*10)/10)+"x"+(Math.round(psz.h*10)/10);
            sizeBuckets[sKey]=(sizeBuckets[sKey]||0)+1;
        }
        var rows=srDetectRows(seatItems), totalAisles=0;
        for (var ri=0; ri<rows.length; ri++) {
            for (var gi=1; gi<rows[ri].length; gi++) {
                if (rows[ri][gi].cx-rows[ri][gi-1].cx>aisleThresh) totalAisles++;
            }
        }
        var resizedCount=0, errorCount=0;
        if (!previewOnly) {
            app.userInteractionLevel=UserInteractionLevel.DONTDISPLAYALERTS;
            for (var rIdx=0; rIdx<rows.length; rIdx++) {
                var currentRow=rows[rIdx];
                if (doReflow) {
                    var placements=srReflowRow(currentRow, aisleThresh, alignRowY);
                    for (var pi=0; pi<placements.length; pi++) {
                        try { srPlaceSeat(placements[pi].item,placements[pi].newCx,placements[pi].newCy); resizedCount++; if(removeStroke)srRemoveStroke(placements[pi].item); } catch(e){errorCount++;}
                    }
                } else {
                    for (var ci=0; ci<currentRow.length; ci++) {
                        try { srPlaceSeat(currentRow[ci].item,currentRow[ci].cx,currentRow[ci].cy); resizedCount++; if(removeStroke)srRemoveStroke(currentRow[ci].item); } catch(e){errorCount++;}
                    }
                }
            }
            app.userInteractionLevel=UserInteractionLevel.DISPLAYALERTS;
            app.redraw();
        }

        var rpt=[];
        rpt.push("=== SEAT RESIZER v2.1 ===");
        if (previewOnly) rpt.push("*** PREVIEW ONLY \u2014 no changes applied ***");
        rpt.push("Mode:            "+(doReflow?"REFLOW (9px step)":"RESIZE ONLY"));
        rpt.push("Align row Y:     "+(alignRowY?"YES":"NO"));
        rpt.push("Aisle threshold: "+aisleThresh+" px");
        rpt.push("Row Y tolerance: "+ROW_TOL+" px");
        rpt.push("");
        rpt.push("Total seats:     "+seatItems.length);
        rpt.push("Rows detected:   "+rows.length);
        rpt.push("Aisles found:    "+totalAisles);
        if (!previewOnly) {
            rpt.push("Resized to 7x7:  "+resizedCount);
            if (errorCount>0) rpt.push("Errors:          "+errorCount+" (!)");
        }
        rpt.push("");
        rpt.push("Sizes BEFORE:");
        var bKeys=[];
        for (var bk in sizeBuckets) { if(sizeBuckets.hasOwnProperty(bk)) bKeys.push(bk); }
        bKeys.sort();
        for (var bi=0; bi<bKeys.length; bi++) {
            rpt.push("  "+bKeys[bi]+" px : "+sizeBuckets[bKeys[bi]]+" seats"+(bKeys[bi]==="7x7"?" (ok)":" <- needs resize"));
        }
        rpt.push("");
        rpt.push("Standard: 7x7 px | 9px step | 2px gap | 27px aisle");
        if (!previewOnly && errorCount===0 && resizedCount>0)
            rpt.push("\u2705 All seats processed. Ctrl+Z to undo.");
        return rpt.join("\n");

    } catch(e) { return "seatResizerRun error:\n"+e+"\n(line "+(e.line||"?")+")"; }
}

// ═══════════════════════════════════════════════════════════════
//  IMAGE TO VECTOR  (ImageToVector.jsx v6.5.1)
//  imageToVectorRun(paramsJSON)
//  params: { filePath, preset, threshold, removeWhite, removeRasters, targetLayer, action }
//  action: "load" | "trace"
// ═══════════════════════════════════════════════════════════════
function imageToVectorRun(paramsJSON) {
    try {
        if (app.documents.length===0) return "ERROR:\nNo document open.";
        var doc=app.activeDocument;
        var p={}; try{p=eval("("+paramsJSON+")");}catch(e){p={};}
        var filePath     = p.filePath||"";
        var preset       = p.preset||"[Default]";
        var threshold    = parseInt(p.threshold)||128;
        var removeWhite  = (p.removeWhite!==false);
        var removeRasters= (p.removeRasters!==false);
        var targetLayer  = p.targetLayer||"active";
        var action       = p.action||"trace";

        if (!filePath) return "ERROR:\nNo file path provided.";
        var imgFile=new File(filePath);
        if (!imgFile.exists) return "ERROR:\nFile not found:\n"+filePath;

        // Helpers
        function iv2rgb(arr){var c=new RGBColor();c.red=arr[0];c.green=arr[1];c.blue=arr[2];return c;}
        function iv2findLayer(name){
            for(var i=0;i<doc.layers.length;i++){if(doc.layers[i].name===name)return doc.layers[i];}
            try{var l=doc.layers.add();l.name=name;return l;}catch(e){return doc.activeLayer;}
        }
        function iv2removeWhite(container){
            var removed=0;
            function scan(c){
                if(c.pathItems){for(var i=c.pathItems.length-1;i>=0;i--){try{var pp=c.pathItems[i];if(pp.filled&&pp.fillColor.typename==="RGBColor"){var fc=pp.fillColor;if(fc.red>245&&fc.green>245&&fc.blue>245){pp.remove();removed++;}}}catch(e){}}}
                if(c.groupItems){for(var g=c.groupItems.length-1;g>=0;g--){scan(c.groupItems[g]);try{if(c.groupItems[g].pageItems.length===0)c.groupItems[g].remove();}catch(e){}}}
            }
            if(container)scan(container);
            return removed;
        }

        // Determine target layer
        var destLayer=doc.activeLayer;
        if(targetLayer==="DECORATION"){destLayer=iv2findLayer("DECORATION");}
        else if(targetLayer==="VECTORIZED"){destLayer=iv2findLayer("VECTORIZED");}

        // Load image
        var placed=destLayer.placedItems.add();
        placed.file=imgFile;
        placed.name="TRACE_SOURCE_"+imgFile.name;
        // Centre on artboard
        var AB=doc.artboards[doc.artboards.getActiveArtboardIndex()];
        var ABR=AB.artboardRect;
        placed.left=ABR[0]+((ABR[2]-ABR[0])-placed.width)/2;
        placed.top=ABR[1]-((ABR[1]-ABR[3])-placed.height)/2;

        var rpt=["=== IMAGE TO VECTOR v6.5.1 ==="];
        rpt.push("File: "+imgFile.name);
        rpt.push("Loaded: "+Math.round(placed.width)+"x"+Math.round(placed.height)+" px");

        if(action==="load"){
            app.redraw();
            rpt.push("");
            rpt.push("Image loaded (raster). Use 'Load + Trace' to vectorize.");
            return rpt.join("\n");
        }

        // Embed + trace
        rpt.push("Tracing with preset: "+preset+"...");
        doc.selection=[placed];
        var pathCount=0;

        try {
            // Embed
            try{app.executeMenuCommand("placedart");$.sleep(200);}catch(e){}
            if(doc.selection.length===0) return rpt.join("\n")+"\nERROR: Could not embed image.";
            var ri=doc.selection[0];

            if(ri.typename==="RasterItem"){
                var tracing=ri.trace();
                var trOpts=tracing.tracing.tracingOptions;
                try{trOpts.loadFromPreset(preset);}catch(pe){if(threshold)trOpts.threshold=threshold;}
                $.sleep(600);
                var expanded=tracing.tracing.expandTracing();
                $.sleep(300);
                function countP(item){if(item.typename==="PathItem"||item.typename==="CompoundPathItem")pathCount++;if(item.pageItems)for(var i=0;i<item.pageItems.length;i++)countP(item.pageItems[i]);}
                if(expanded)countP(expanded);
                else if(doc.selection.length>0)countP(doc.selection[0]);
                rpt.push("Paths created: "+pathCount);
            } else {
                // Fallback menu
                app.executeMenuCommand("Live Trace Default");$.sleep(1200);
                app.executeMenuCommand("expandStyle");$.sleep(400);
                rpt.push("Traced via menu command (fallback).");
            }
        } catch(te){
            rpt.push("Trace error: "+te.message);
        }

        // Post-processing
        if(removeWhite){
            var cur=doc.selection.length>0?doc.selection[0]:null;
            var wr=iv2removeWhite(cur||destLayer);
            rpt.push("White fills removed: "+wr);
        }
        if(removeRasters){
            var rr=0;
            for(var ri2=doc.rasterItems.length-1;ri2>=0;ri2--){try{doc.rasterItems[ri2].remove();rr++;}catch(e){}}
            for(var pi2=doc.placedItems.length-1;pi2>=0;pi2--){try{doc.placedItems[pi2].remove();rr++;}catch(e){}}
            rpt.push("Rasters removed: "+rr);
        }

        app.redraw();
        rpt.push("");
        rpt.push("Rasters remaining: "+doc.rasterItems.length+(doc.rasterItems.length>0?" ⚠ (SOP violation!)":" ✓"));
        rpt.push("✅ Vectorization complete. Ctrl+Z to undo.");
        return rpt.join("\n");
    } catch(e){return "imageToVectorRun error:\n"+e+"\n(line "+(e.line||"?")+")"; }
}

// ═══════════════════════════════════════════════════════════════
//  FACE STAGE DIRECTION  (FaceStageDirection.jsx v6.5.1)
//  faceStageDirectionRun(paramsJSON)
//  params: { scope, mode, fixOnly, stageX, stageY }
//  scope: "document"|"selection"|"layer"
//  mode:  "scan"|"fix"|"indicators"
// ═══════════════════════════════════════════════════════════════
function faceStageDirectionRun(paramsJSON) {
    try {
        if (app.documents.length===0) return "ERROR:\nNo document open.";
        var doc=app.activeDocument;
        var p={}; try{p=eval("("+paramsJSON+")");}catch(e){p={};}
        var scope   = p.scope||"document";
        var mode    = p.mode||"scan";
        var fixOnly = (p.fixOnly!==false);
        var stageX  = parseFloat(p.stageX)||null;
        var stageY  = parseFloat(p.stageY)||null;

        var SOP_W=7,SOP_H=7,SOP_RX=1.5,SOP_RY=1.5;
        var ROT_THRESH=1.5;

        // Helpers
        function fsdRgb(arr){var c=new RGBColor();c.red=arr[0];c.green=arr[1];c.blue=arr[2];return c;}
        function fsdCentre(item){var b=item.geometricBounds;return{x:(b[0]+b[2])/2,y:(b[1]+b[3])/2};}
        function fsdIsSeat(p2){return p2&&p2.name&&p2.name.indexOf("seatData-")===0;}
        function fsdCollect(container,results){
            if(container.pageItems)for(var i=0;i<container.pageItems.length;i++){if(fsdIsSeat(container.pageItems[i]))results.push(container.pageItems[i]);if(container.pageItems[i].pageItems)fsdCollect(container.pageItems[i],results);}
            if(container.layers)for(var j=0;j<container.layers.length;j++)fsdCollect(container.layers[j],results);
        }
        function fsdIsRotated(item){
            var b=item.geometricBounds;
            var w=Math.abs(b[2]-b[0]),h=Math.abs(b[1]-b[3]);
            return (w>SOP_W+ROT_THRESH&&h>SOP_H+ROT_THRESH)||(Math.abs(w-h)>1.5&&(w<5||h<5));
        }
        function fsdRebuild(oldSeat){
            var c=fsdCentre(oldSeat);
            var layer=oldSeat.layer;
            var name=oldSeat.name;
            var fillC=null;
            try{if(oldSeat.filled&&oldSeat.fillColor)fillC=oldSeat.fillColor;}catch(e){}
            var newSeat=layer.pathItems.roundedRectangle(c.y+SOP_H/2,c.x-SOP_W/2,SOP_W,SOP_H,SOP_RX,SOP_RY);
            newSeat.filled=true;
            newSeat.fillColor=fillC||fsdRgb([204,204,204]);
            newSeat.stroked=false;
            newSeat.name=name||"";
            try{oldSeat.remove();}catch(e){}
            return newSeat;
        }
        function fsdDetectStage(){
            for(var i=0;i<doc.layers.length;i++){
                if(doc.layers[i].name==="STAGE"&&doc.layers[i].pathItems.length>0){
                    var b=doc.layers[i].pathItems[0].geometricBounds;
                    return{cx:(b[0]+b[2])/2,cy:(b[1]+b[3])/2};
                }
            }
            return null;
        }

        // Collect seats
        var seats=[];
        if(scope==="selection"){var sel=doc.selection;for(var i=0;i<sel.length;i++){if(fsdIsSeat(sel[i]))seats.push(sel[i]);else fsdCollect(sel[i],seats);}}
        else if(scope==="layer"){fsdCollect(doc.activeLayer,seats);}
        else{fsdCollect(doc,seats);}

        if(seats.length===0) return "ERROR:\nNo seatData-* elements found in scope.";

        // Stage position
        var stg=null;
        if(stageX&&stageY){stg={cx:stageX,cy:stageY};}
        else{stg=fsdDetectStage();}

        // Process
        var totalScanned=seats.length,rotatedCount=0,fixedCount=0,errors=0;
        for(var i=0;i<seats.length;i++){
            var isRot=fsdIsRotated(seats[i]);
            if(isRot) rotatedCount++;
            if(mode!=="scan"&&isRot){
                try{fsdRebuild(seats[i]);fixedCount++;}catch(e){errors++;}
            }
        }

        if(mode!=="scan") app.redraw();

        var rpt=["=== FACE STAGE DIRECTION v6.5.1 ==="];
        rpt.push("Scope:          "+scope);
        rpt.push("Mode:           "+mode);
        rpt.push("Stage:          "+(stg?"X="+Math.round(stg.cx)+" Y="+Math.round(stg.cy):"not detected"));
        rpt.push("");
        rpt.push("Total scanned:  "+totalScanned);
        rpt.push("Diamond/rotated: "+rotatedCount+(rotatedCount>0?" ⚠ CRITICAL":" ✓"));
        if(mode!=="scan"){
            rpt.push("Seats rebuilt:  "+fixedCount);
            if(errors>0) rpt.push("Errors:         "+errors);
        }
        rpt.push("");
        rpt.push("SOP: seats must be axis-aligned 7x7px. No rotation transforms.");
        if(mode!=="scan"&&errors===0&&fixedCount>0)
            rpt.push("✅ "+fixedCount+" seats rebuilt. Ctrl+Z to undo.");
        else if(mode==="scan"&&rotatedCount===0)
            rpt.push("✅ All seats correctly oriented.");
        return rpt.join("\n");
    } catch(e){return "faceStageDirectionRun error:\n"+e+"\n(line "+(e.line||"?")+")"; }
}

// ═══════════════════════════════════════════════════════════════
//  MULTI-ZONE ALIGNER  (MultiZoneAligner.jsx v6.5.1)
//  multiZoneAlignerRun(paramsJSON)
//  params: { scope, namedList, operation, stageX, stageY, gridStep }
//  operation: "stageAxis"|"top"|"bottom"|"left"|"right"|"centreH"|"centreV"
//             |"distH"|"distV"|"snapGrid"|"fixSymm"|"analyse"
// ═══════════════════════════════════════════════════════════════
function multiZoneAlignerRun(paramsJSON) {
    try {
        if (app.documents.length===0) return "ERROR:\nNo document open.";
        var doc=app.activeDocument;
        var p={}; try{p=eval("("+paramsJSON+")");}catch(e){p={};}
        var scope     = p.scope||"all";
        var namedList = p.namedList||"";
        var operation = p.operation||"analyse";
        var gridStep  = parseFloat(p.gridStep)||9;
        var manStageX = parseFloat(p.stageX)||null;
        var manStageY = parseFloat(p.stageY)||null;

        var RESERVED={"STAGE":1,"DECORATION":1,"SEATLABELS":1};

        // Helpers
        function mzaFindDeep(root,name){for(var i=0;i<root.layers.length;i++){if(root.layers[i].name===name)return root.layers[i];var h=mzaFindDeep(root.layers[i],name);if(h)return h;}return null;}
        function mzaGatherItems(container,results){if(container.pageItems)for(var i=0;i<container.pageItems.length;i++)results.push(container.pageItems[i]);if(container.layers)for(var j=0;j<container.layers.length;j++)mzaGatherItems(container.layers[j],results);}
        function mzaGetBounds(zone){
            var items=[];mzaGatherItems(zone,items);if(!items.length)return null;
            var minX=Infinity,maxX=-Infinity,minY=Infinity,maxY=-Infinity;
            for(var i=0;i<items.length;i++){try{var b=items[i].geometricBounds;if(b[0]<minX)minX=b[0];if(b[2]>maxX)maxX=b[2];if(b[3]<minY)minY=b[3];if(b[1]>maxY)maxY=b[1];}catch(e){}}
            if(minX===Infinity)return null;
            return{minX:minX,maxX:maxX,minY:minY,maxY:maxY,width:maxX-minX,height:maxY-minY,cx:(minX+maxX)/2,cy:(minY+maxY)/2};
        }
        function mzaTranslate(zone,dx,dy){
            if(Math.abs(dx)<0.01&&Math.abs(dy)<0.01)return 0;
            var items=[];mzaGatherItems(zone,items);var moved=0;
            for(var i=0;i<items.length;i++){try{items[i].left+=dx;items[i].top+=dy;moved++;}catch(e){}}
            return moved;
        }
        function mzaSnap(v,step){return Math.round(v/step)*step;}
        function mzaDetectStage(){
            var stg=mzaFindDeep(doc,"STAGE");
            if(!stg||!stg.pathItems.length)return null;
            var b=stg.pathItems[0].geometricBounds;
            return{cx:(b[0]+b[2])/2,cy:(b[1]+b[3])/2};
        }

        // Resolve zones
        var zones=[];
        if(scope==="all"){for(var i=0;i<doc.layers.length;i++){if(!RESERVED[doc.layers[i].name])zones.push(doc.layers[i]);}}
        else if(scope==="selection"){var sel=doc.selection;var seen={};for(var i=0;i<sel.length;i++){try{var lyr=sel[i].layer;while(lyr&&lyr.parent&&lyr.parent.typename==="Layer")lyr=lyr.parent;if(lyr&&!RESERVED[lyr.name]&&!seen[lyr.name]){zones.push(lyr);seen[lyr.name]=1;}}catch(e){}}}
        else if(scope==="named"){var names=namedList.split(",");for(var i=0;i<names.length;i++){var nm=names[i].replace(/^\s+|\s+$/g,"");if(!nm)continue;var z=mzaFindDeep(doc,nm);if(z)zones.push(z);}}

        if(zones.length===0) return "ERROR:\nNo zones found for scope: "+scope;

        // Stage
        var stg=null;
        if(manStageX&&manStageY){stg={cx:manStageX,cy:manStageY};}
        else{stg=mzaDetectStage();}

        var moved=0,rpt=["=== MULTI-ZONE ALIGNER v6.5.1 ==="];
        rpt.push("Scope:     "+scope+" ("+zones.length+" zones)");
        rpt.push("Stage:     "+(stg?"X="+Math.round(stg.cx)+" Y="+Math.round(stg.cy):"not detected"));
        rpt.push("Operation: "+operation);
        rpt.push("");

        if(operation==="analyse"){
            for(var i=0;i<zones.length;i++){
                var b=mzaGetBounds(zones[i]);
                if(!b){rpt.push("  "+zones[i].name+": (empty)");continue;}
                var dist=stg?Math.round(b.cx-stg.cx):0;
                rpt.push("  "+zones[i].name+": CX="+Math.round(b.cx)+" CY="+Math.round(b.cy)+" W="+Math.round(b.width)+" H="+Math.round(b.height)+(stg?" Δ="+(dist>=0?"+":"")+dist:""));
            }
            rpt.push("\n✅ Analysis complete (no changes made).");
            return rpt.join("\n");
        }

        if(operation==="stageAxis"&&stg){
            for(var i=0;i<zones.length;i++){var b=mzaGetBounds(zones[i]);if(!b)continue;mzaTranslate(zones[i],stg.cx-b.cx,0);moved++;}
        } else if(operation==="top"){
            var maxY=-Infinity;for(var i=0;i<zones.length;i++){var b=mzaGetBounds(zones[i]);if(b&&b.maxY>maxY)maxY=b.maxY;}
            for(var i=0;i<zones.length;i++){var b=mzaGetBounds(zones[i]);if(!b)continue;mzaTranslate(zones[i],0,maxY-b.maxY);moved++;}
        } else if(operation==="bottom"){
            var minY=Infinity;for(var i=0;i<zones.length;i++){var b=mzaGetBounds(zones[i]);if(b&&b.minY<minY)minY=b.minY;}
            for(var i=0;i<zones.length;i++){var b=mzaGetBounds(zones[i]);if(!b)continue;mzaTranslate(zones[i],0,minY-b.minY);moved++;}
        } else if(operation==="left"){
            var minX=Infinity;for(var i=0;i<zones.length;i++){var b=mzaGetBounds(zones[i]);if(b&&b.minX<minX)minX=b.minX;}
            for(var i=0;i<zones.length;i++){var b=mzaGetBounds(zones[i]);if(!b)continue;mzaTranslate(zones[i],minX-b.minX,0);moved++;}
        } else if(operation==="right"){
            var maxX=-Infinity;for(var i=0;i<zones.length;i++){var b=mzaGetBounds(zones[i]);if(b&&b.maxX>maxX)maxX=b.maxX;}
            for(var i=0;i<zones.length;i++){var b=mzaGetBounds(zones[i]);if(!b)continue;mzaTranslate(zones[i],maxX-b.maxX,0);moved++;}
        } else if(operation==="centreH"){
            var sumCX=0,cnt=0;for(var i=0;i<zones.length;i++){var b=mzaGetBounds(zones[i]);if(b){sumCX+=b.cx;cnt++;}}
            var avgCX=cnt?sumCX/cnt:0;
            for(var i=0;i<zones.length;i++){var b=mzaGetBounds(zones[i]);if(!b)continue;mzaTranslate(zones[i],avgCX-b.cx,0);moved++;}
        } else if(operation==="centreV"){
            var sumCY=0,cnt=0;for(var i=0;i<zones.length;i++){var b=mzaGetBounds(zones[i]);if(b){sumCY+=b.cy;cnt++;}}
            var avgCY=cnt?sumCY/cnt:0;
            for(var i=0;i<zones.length;i++){var b=mzaGetBounds(zones[i]);if(!b)continue;mzaTranslate(zones[i],0,avgCY-b.cy);moved++;}
        } else if(operation==="distH"){
            var infos=[];for(var i=0;i<zones.length;i++){var b=mzaGetBounds(zones[i]);if(b)infos.push({zone:zones[i],bounds:b});}
            infos.sort(function(a,c){return a.bounds.minX-c.bounds.minX;});
            if(infos.length>=3){var first=infos[0].bounds,last=infos[infos.length-1].bounds,tw=0;for(var i=0;i<infos.length;i++)tw+=infos[i].bounds.width;var gap=(last.maxX-first.minX-tw)/(infos.length-1);var nextX=first.maxX+gap;for(var i=1;i<infos.length-1;i++){var dx=nextX-infos[i].bounds.minX;mzaTranslate(infos[i].zone,dx,0);moved++;nextX+=infos[i].bounds.width+gap;}}
        } else if(operation==="distV"){
            var infos=[];for(var i=0;i<zones.length;i++){var b=mzaGetBounds(zones[i]);if(b)infos.push({zone:zones[i],bounds:b});}
            infos.sort(function(a,c){return a.bounds.minY-c.bounds.minY;});
            if(infos.length>=3){var first=infos[0].bounds,last=infos[infos.length-1].bounds,th=0;for(var i=0;i<infos.length;i++)th+=infos[i].bounds.height;var gap=(last.maxY-first.minY-th)/(infos.length-1);var nextY=first.maxY+gap;for(var i=1;i<infos.length-1;i++){var dy=nextY-infos[i].bounds.minY;mzaTranslate(infos[i].zone,0,dy);moved++;nextY+=infos[i].bounds.height+gap;}}
        } else if(operation==="snapGrid"){
            for(var i=0;i<zones.length;i++){var b=mzaGetBounds(zones[i]);if(!b)continue;var dx=mzaSnap(b.minX,gridStep)-b.minX;var dy=mzaSnap(b.minY,gridStep)-b.minY;mzaTranslate(zones[i],dx,dy);moved++;}
        } else if(operation==="fixSymm"&&stg){
            for(var i=0;i<zones.length;i++){var b=mzaGetBounds(zones[i]);if(!b)continue;var dist=b.cx-stg.cx;var snapped=Math.round(dist/gridStep)*gridStep;mzaTranslate(zones[i],(stg.cx+snapped)-b.cx,0);moved++;}
        } else {
            return "ERROR:\nUnknown operation: "+operation;
        }

        rpt.push("Moved:     "+moved+" zone(s)");
        rpt.push("");
        rpt.push("\u2705 Alignment complete.");
        return rpt.join("\n");

    } catch (e) {
        return "multiZoneAlignerRun error:\n" + e + "\n(line " + (e.line || "?") + ")";
    }
}

/* ═══════════════════════════════════════════════════════════════
   §79-82 — LEVEL 2+ EXPANSION (added by Claude Opus 4.7)
   - LayerToggle: scan/act/preset (replaces LayerToggle.jsx external)
   - convertToSeatShape: 7×7 seat shape converter (replaces 18-...jsx)
   - seatsToZoneScan/Build: 2-step zone builder (replaces 17-...jsx)
   - hierarchyValidate: 10-check Validator
   - createBackupSnapshot: save .ai snapshot before destructive ops
   ═══════════════════════════════════════════════════════════════ */

function createBackupSnapshot(tag) {
 try {
  if (!app.documents.length) return "ERROR: No document open.";
  var doc=app.activeDocument;
  if (!doc.saved) return "ERROR: Save your current changes before creating an AI snapshot.";
  var source=doc.fullName;
  if (!source || !source.exists || !/\.ai$/i.test(source.name)) return "ERROR: Save as an AI document before creating a snapshot.";
  var folder=new Folder(source.parent.fsName+"/.yw_backups");
  if(!folder.exists&&!folder.create()) return "ERROR: Cannot create snapshot folder.";
  var dest=new File(folder.fsName+"/"+source.name.replace(/\.ai$/i,"")+"__"+String(tag||"snapshot").replace(/[^A-Za-z0-9_-]/g,"_")+"__"+new Date().getTime()+".ai");
  if(!source.copy(dest.fsName)) return "ERROR: Cannot copy saved document to snapshot.";
  return "Snapshot saved: "+dest.fsName+" (working document unchanged)";
 } catch(e) {return "ERROR: Snapshot: "+e+" line="+(e.line||"?");}
}

/* ═══════════════════════════════════════════════════════════════
   §79 — LAYER TOGGLE (CEP-callable scan / act / preset)
   ═══════════════════════════════════════════════════════════════ */

var LT_TYPES = [
    { label:"SECTION",              pattern:/^SECTION(_\d+_)?$/i },
    { label:"SECTIONDECORATION",    pattern:/^SECTIONDECORATION(_\d+_)?$/i },
    { label:"SEAT",                 pattern:/^SEAT(_\d+_)?$/i },
    { label:"SEATDECORATION",       pattern:/^SEATDECORATION$/i },
    { label:"UNDERSEATDECORATION",  pattern:/^UNDERSEATDECORATION$/i },
    { label:"DECORATION",           pattern:/^DECORATION$/i },
    { label:"STAGE",                pattern:/^STAGE$/i },
    { label:"SEATLABELS",           pattern:/^SEATLABELS$/i }
];

function _ltCollect(container, buckets) {
    var i, grp, name, t;
    if (container.groupItems) {
        for (i = 0; i < container.groupItems.length; i++) {
            grp = container.groupItems[i];
            name = grp.name || "";
            for (t = 0; t < LT_TYPES.length; t++) {
                if (LT_TYPES[t].pattern.test(name)) {
                    buckets[LT_TYPES[t].label].items.push(grp);
                    if (/_\d+_$/.test(name)) buckets[LT_TYPES[t].label].legacy++;
                    break;
                }
            }
            _ltCollect(grp, buckets);
        }
    }
    if (container.layers) {
        // Also treat Layers with matching names as togglable
        for (i = 0; i < container.layers.length; i++) {
            var lyr = container.layers[i];
            name = lyr.name || "";
            for (t = 0; t < LT_TYPES.length; t++) {
                if (LT_TYPES[t].pattern.test(name)) {
                    buckets[LT_TYPES[t].label].items.push(lyr);
                    break;
                }
            }
            _ltCollect(lyr, buckets);
        }
    }
}

function _ltBuckets() {
    var buckets = {};
    for (var i = 0; i < LT_TYPES.length; i++) {
        buckets[LT_TYPES[i].label] = { items: [], legacy: 0 };
    }
    return buckets;
}

function _ltStatus(items) {
    if (!items || items.length === 0) return "EMPTY";
    var vis = 0, hid = 0;
    for (var i = 0; i < items.length; i++) {
        var isHidden = false;
        try {
            if (items[i].typename === "Layer") isHidden = !items[i].visible;
            else isHidden = items[i].hidden;
        } catch (e) {}
        if (isHidden) hid++; else vis++;
    }
    if (vis === items.length) return "VISIBLE";
    if (hid === items.length) return "HIDDEN";
    return "MIXED";
}

function _ltSetVis(items, visible) {
    for (var i = 0; i < items.length; i++) {
        try {
            if (items[i].typename === "Layer") items[i].visible = visible;
            else items[i].hidden = !visible;
        } catch (e) {}
    }
}

function layerToggleScan() {
    try {
        if (app.documents.length === 0) return '{"error":"No doc"}';
        var buckets = _ltBuckets();
        _ltCollect(app.activeDocument, buckets);
        var out = { types: [] };
        for (var i = 0; i < LT_TYPES.length; i++) {
            var lbl = LT_TYPES[i].label;
            var b = buckets[lbl];
            out.types.push({
                label:  lbl,
                count:  b.items.length,
                legacy: b.legacy,
                status: _ltStatus(b.items)
            });
        }
        return _jsonStringify(out);
    } catch (e) { return '{"error":"' + String(e).replace(/"/g,"") + '"}'; }
}

function layerToggleAct(label, action) {
    try {
        if (app.documents.length === 0) return "ERROR: No doc";
        var buckets = _ltBuckets();
        _ltCollect(app.activeDocument, buckets);

        if (action === "solo") {
            for (var k in buckets) {
                if (!buckets.hasOwnProperty(k)) continue;
                _ltSetVis(buckets[k].items, (k === label));
            }
        } else {
            var b = buckets[label];
            if (!b) return "ERROR: Unknown label " + label;
            _ltSetVis(b.items, action === "show");
        }
        app.redraw();
        return "\u2705 " + label + " " + action;
    } catch (e) { return "layerToggleAct error: " + e; }
}

function layerToggleBulk(action) {
    try {
        if (app.documents.length === 0) return "ERROR: No doc";
        var buckets = _ltBuckets();
        _ltCollect(app.activeDocument, buckets);
        var visible = action === "showAll";
        for (var k in buckets) {
            if (!buckets.hasOwnProperty(k)) continue;
            _ltSetVis(buckets[k].items, visible);
        }
        app.redraw();
        return "\u2705 " + action;
    } catch (e) { return "layerToggleBulk error: " + e; }
}

function layerTogglePreset(labelsJSON) {
    try {
        if (app.documents.length === 0) return "ERROR: No doc";
        var labels = eval("(" + labelsJSON + ")");
        var showSet = {};
        for (var i = 0; i < labels.length; i++) showSet[labels[i]] = true;

        var buckets = _ltBuckets();
        _ltCollect(app.activeDocument, buckets);
        for (var k in buckets) {
            if (!buckets.hasOwnProperty(k)) continue;
            _ltSetVis(buckets[k].items, !!showSet[k]);
        }
        app.redraw();
        return "\u2705 Preset applied: " + labels.join(",");
    } catch (e) { return "layerTogglePreset error: " + e; }
}

/* Simple JSON stringifier — ES3-safe fallback */
function _jsonStringify(v) {
 if(v===null||v===undefined)return "null";
 if(typeof v==="boolean")return String(v);
 if(typeof v==="number")return isFinite(v)?String(v):"null";
 if(typeof v==="string")return '"'+v.replace(/[\\"\x00-\x1f\u2028\u2029]/g,function(c){
  if(c==='"')return '\\"';if(c==='\\')return '\\\\';
  return '\\u'+('0000'+c.charCodeAt(0).toString(16)).slice(-4);
 })+'"';
 var out=[],i;
 if(v instanceof Array){for(i=0;i<v.length;i++)out.push(_jsonStringify(v[i]));return '['+out.join(',')+']';}
 if(typeof v==="object"){for(i in v)if(Object.prototype.hasOwnProperty.call(v,i))out.push(_jsonStringify(String(i))+':'+_jsonStringify(v[i]));return '{'+out.join(',')+'}';}
 return "null";
}


/* ═══════════════════════════════════════════════════════════════
   §80 — CONVERT TO SEAT SHAPE (7×7 rounded rect with dedup)
   ═══════════════════════════════════════════════════════════════ */

function convertToSeatShape(paramsJSON) {
    try {
        if (app.documents.length === 0) return "ERROR: No doc";
        var doc = app.activeDocument;
        var sel = doc.selection;
        if (!sel || sel.length === 0) return "ERROR: Nothing selected";

        var p = eval("(" + paramsJSON + ")");
        var tolerance  = parseFloat(p.tolerance)  || 2;
        var fillHex    = String(p.fill || "#CCCCCC").replace("#", "");
        var keepFill   = p.keepFill !== false;
        var useGroup   = p.group !== false;
        var removeOrig = p.removeOrig !== false;

        var SEAT_W = 7, SEAT_H = 7, RX = 1.5, RY = 1.5;

        // Collect leaf paths recursively
        var allPaths = [];
        function collectPaths(it) {
            if (!it) return;
            if (it.typename === "PathItem") allPaths.push(it);
            else if (it.typename === "CompoundPathItem") {
                if (it.pathItems.length > 0) allPaths.push(it.pathItems[0]);
            } else if (it.typename === "GroupItem" && it.pageItems) {
                for (var i = 0; i < it.pageItems.length; i++) collectPaths(it.pageItems[i]);
            }
        }
        for (var s = 0; s < sel.length; s++) collectPaths(sel[s]);

        if (allPaths.length === 0) return "ERROR: No path items in selection";

        function getCenter(pi) {
            var gb = pi.geometricBounds;
            return { x: (gb[0]+gb[2])/2, y: (gb[1]+gb[3])/2 };
        }

        // Dedupe by centre proximity
        var unique = [], dupeCount = 0;
        for (var pi = 0; pi < allPaths.length; pi++) {
            var c = getCenter(allPaths[pi]);
            var isDupe = false;
            for (var u = 0; u < unique.length; u++) {
                if (Math.abs(c.x - unique[u].center.x) <= tolerance &&
                    Math.abs(c.y - unique[u].center.y) <= tolerance) {
                    isDupe = true; dupeCount++; break;
                }
            }
            if (!isDupe) {
                var fc = null;
                try { if (allPaths[pi].filled) fc = allPaths[pi].fillColor; } catch (e) {}
                unique.push({ center: c, path: allPaths[pi], fillColor: fc });
            }
        }

        // Determine parent — use first path's parent
        var parentLayer = unique[0].path.layer || doc.activeLayer;
        var targetParent;
        if (useGroup) {
            targetParent = parentLayer.groupItems.add();
            targetParent.name = "CONVERTED_SEATS";
            try { targetParent.move(unique[0].path, ElementPlacement.PLACEBEFORE); } catch (e) {}
        } else {
            targetParent = parentLayer;
        }

        // Default fill colour
        var defaultFill;
        try {
            var r = parseInt(fillHex.substring(0,2), 16);
            var g = parseInt(fillHex.substring(2,4), 16);
            var b = parseInt(fillHex.substring(4,6), 16);
            defaultFill = makeColorSafe(r, g, b);
        } catch (e) {
            defaultFill = makeColorSafe(204, 204, 204);
        }

        var created = 0;
        for (var i = 0; i < unique.length; i++) {
            var cx = unique[i].center.x, cy = unique[i].center.y;
            try {
                var seat = targetParent.pathItems.roundedRectangle(
                    cy + SEAT_H/2, cx - SEAT_W/2, SEAT_W, SEAT_H, RX, RY
                );
                seat.filled = true;
                seat.fillColor = (keepFill && unique[i].fillColor) ? unique[i].fillColor : defaultFill;
                seat.stroked = false;
                created++;
            } catch (e) {}
        }

        // Remove originals
        var removed = 0;
        if (removeOrig) {
            for (var rr = allPaths.length - 1; rr >= 0; rr--) {
                try {
                    var parent = allPaths[rr].parent;
                    if (parent && parent.typename === "CompoundPathItem") {
                        parent.remove();
                    } else {
                        allPaths[rr].remove();
                    }
                    removed++;
                } catch (e) {}
            }
        }

        app.redraw();
        var msg = "\u2705 Convert complete\n";
        msg += "Paths scanned:     " + allPaths.length + "\n";
        msg += "Duplicates merged: " + dupeCount + "\n";
        msg += "Seats created:     " + created + " (7\u00D77 px, rx/ry 1.5)\n";
        msg += "Originals removed: " + removed + "\n";
        if (useGroup) msg += "\nPlaced in group: CONVERTED_SEATS";
        return msg;
    } catch (e) {
        return "convertToSeatShape error: " + e + " (line " + (e.line || "?") + ")";
    }
}


/* ═══════════════════════════════════════════════════════════════
   §81 — SEATS TO ZONE (2-step: scan + build)
   ═══════════════════════════════════════════════════════════════ */

function seatsToZoneScan() {
    try {
        if (app.documents.length === 0) return '{"error":"No doc"}';
        var doc = app.activeDocument;
        var sel = doc.selection;
        if (!sel || sel.length === 0) return '{"error":"Nothing selected","clusters":[]}';

        function _leafPaths(item, arr) {
            if (!item) return;
            if (item.typename === "PathItem") arr.push(item);
            else if (item.typename === "CompoundPathItem") {
                for (var i = 0; i < item.pathItems.length; i++) arr.push(item.pathItems[i]);
            } else if (item.typename === "GroupItem" && item.pageItems) {
                for (var j = 0; j < item.pageItems.length; j++) _leafPaths(item.pageItems[j], arr);
            }
        }

        var clusters = [], loose = [];
        for (var s = 0; s < sel.length; s++) {
            var it = sel[s];
            if (it.typename === "GroupItem") {
                var ps = [];
                _leafPaths(it, ps);
                if (ps.length > 0) {
                    clusters.push({
                        seatCount: ps.length,
                        sourceName: it.name || null,
                        suggestedName: (it.name || "").replace(/^ZONE_/i, "") || ("Z" + (clusters.length + 1))
                    });
                }
            } else if (it.typename === "PathItem" || it.typename === "CompoundPathItem") {
                var lp = [];
                _leafPaths(it, lp);
                for (var k = 0; k < lp.length; k++) loose.push(lp[k]);
            }
        }
        if (loose.length > 0) {
            clusters.push({ seatCount: loose.length, sourceName: null, suggestedName: "LOOSE" });
        }

        return _jsonStringify({ clusters: clusters });
    } catch (e) { return '{"error":"' + String(e) + '","clusters":[]}'; }
}

function seatsToZoneBuild(paramsJSON) {
    try {
        if (app.documents.length === 0) return "ERROR: No doc";
        var doc = app.activeDocument;
        var sel = doc.selection;
        if (!sel || sel.length === 0) return "ERROR: Nothing selected";

        var p = eval("(" + paramsJSON + ")");
        var names = p.zoneNames || [];
        var PAD = parseFloat(p.padding) || 6;
        var LABEL_SIZE = parseFloat(p.fontSize) || 30;
        var createSL = p.createSeatLabels !== false;

        var C_SEC_FILL   = makeColorSafe(241, 241, 241);
        var C_SEC_STROKE = makeColorSafe(209,210,212);
        var C_BADGE      = makeColorSafe(255, 255, 255);
        var C_LABEL      = makeColorSafe(109,110,112);

        function _leafPaths(item, arr) {
            if (!item) return;
            if (item.typename === "PathItem") arr.push(item);
            else if (item.typename === "CompoundPathItem") {
                for (var i = 0; i < item.pathItems.length; i++) arr.push(item.pathItems[i]);
            } else if (item.typename === "GroupItem" && item.pageItems) {
                for (var j = 0; j < item.pageItems.length; j++) _leafPaths(item.pageItems[j], arr);
            }
        }
        function _boundsOf(items) {
            var l = Infinity, t = -Infinity, r = -Infinity, b = Infinity;
            for (var i = 0; i < items.length; i++) {
                var gb = items[i].geometricBounds;
                if (gb[0] < l) l = gb[0];
                if (gb[1] > t) t = gb[1];
                if (gb[2] > r) r = gb[2];
                if (gb[3] < b) b = gb[3];
            }
            return [l, t, r, b];
        }

        // Rebuild clusters (same logic as scan)
        var clusters = [], loose = [], clusterSources = [];
        for (var s = 0; s < sel.length; s++) {
            var it = sel[s];
            if (it.typename === "GroupItem") {
                var ps = [];
                _leafPaths(it, ps);
                if (ps.length > 0) {
                    clusters.push(ps);
                    clusterSources.push(it);
                }
            } else if (it.typename === "PathItem" || it.typename === "CompoundPathItem") {
                var lp = [];
                _leafPaths(it, lp);
                for (var k = 0; k < lp.length; k++) loose.push(lp[k]);
            }
        }
        if (loose.length > 0) { clusters.push(loose); clusterSources.push(null); }

        if (clusters.length === 0) return "ERROR: No path clusters found";
        if (clusters.length !== names.length) return "ERROR: Zone name count mismatch (" + clusters.length + " clusters, " + names.length + " names)";

        var targetLayer = doc.activeLayer;
        var seatLabelsExists = false;
        if (targetLayer.groupItems) {
            for (var gl = 0; gl < targetLayer.groupItems.length; gl++) {
                if (targetLayer.groupItems[gl].name === "SEATLABELS") { seatLabelsExists = true; break; }
            }
        }

        var report = [];
        for (var z = clusters.length - 1; z >= 0; z--) {
            var zoneName = names[z] || ("Z" + (z+1));
            var seats = clusters[z];
            var bounds = _boundsOf(seats);
            var sL = bounds[0], sT = bounds[1], sR = bounds[2], sB = bounds[3];

            // Create zone group
            var zoneGroup = targetLayer.groupItems.add();
            zoneGroup.name = "ZONE_" + zoneName;

            // Sub-groups (reverse order)
            var secDecor = zoneGroup.groupItems.add(); secDecor.name = "SECTIONDECORATION";

            // Badge + label
            var estTextW = Math.max(40, zoneName.length * 18);
            var badgeW = estTextW + 8;
            var badgeH = 44;
            var badgeCX = (sL + sR) / 2;
            var badgeCY = (sT + sB) / 2;
            var badge = secDecor.pathItems.rectangle(badgeCY + badgeH/2, badgeCX - badgeW/2, badgeW, badgeH);
            badge.fillColor = C_BADGE;
            badge.stroked = true;
            badge.strokeColor = C_SEC_STROKE;
            badge.strokeWidth = 1;

            var tf = secDecor.textFrames.add();
            tf.contents = zoneName;
            tf.textRange.characterAttributes.size = LABEL_SIZE;
            try { tf.textRange.characterAttributes.textFont = app.textFonts.getByName("ArialMT"); }
            catch (e) { try { tf.textRange.characterAttributes.textFont = app.textFonts.getByName("Arial"); } catch (e2) {} }
            tf.textRange.characterAttributes.fillColor = C_LABEL;
            tf.left = badgeCX - tf.width/2;
            tf.top = badgeCY + tf.height/2;

            var seatDecor = zoneGroup.groupItems.add(); seatDecor.name = "SEATDECORATION";
            var seatGrp = zoneGroup.groupItems.add(); seatGrp.name = "SEAT";
            var underSeat = zoneGroup.groupItems.add(); underSeat.name = "UNDERSEATDECORATION";
            var secGrp = zoneGroup.groupItems.add(); secGrp.name = "SECTION";

            var secRect = secGrp.pathItems.rectangle(
                sT + PAD, sL - PAD, (sR - sL) + PAD*2, (sT - sB) + PAD*2
            );
            secRect.fillColor = C_SEC_FILL;
            secRect.stroked = true;
            secRect.strokeColor = C_SEC_STROKE;
            secRect.strokeWidth = 1;

            // Move seats in
            for (var m = seats.length - 1; m >= 0; m--) {
                try { seats[m].move(seatGrp, ElementPlacement.PLACEATBEGINNING); } catch (e) {}
            }

            // Remove empty source group
            if (clusterSources[z]) {
                try {
                    if (clusterSources[z].pageItems.length === 0) clusterSources[z].remove();
                } catch (e) {}
            }

            // Reorder for correct z-order
            try {
                secGrp.zOrder(ZOrderMethod.SENDTOBACK);
                underSeat.move(secGrp, ElementPlacement.PLACEAFTER);
                seatGrp.move(underSeat, ElementPlacement.PLACEAFTER);
                seatDecor.move(seatGrp, ElementPlacement.PLACEAFTER);
                secDecor.move(seatDecor, ElementPlacement.PLACEAFTER);
            } catch (e) {}

            report.push("  ZONE_" + zoneName + ": " + seats.length + " seats");
        }

        if (createSL && !seatLabelsExists) {
            var slg = targetLayer.groupItems.add();
            slg.name = "SEATLABELS";
            try { slg.zOrder(ZOrderMethod.BRINGTOFRONT); } catch (e) {}
            report.push("  + SEATLABELS (empty)");
        }

        app.redraw();
        return "\u2705 Zones created:\n" + report.join("\n") +
               "\n\nPer-zone hierarchy:\n" +
               "  ZONE_name\n" +
               "    \u251C SECTION\n" +
               "    \u251C UNDERSEATDECORATION\n" +
               "    \u251C SEAT\n" +
               "    \u251C SEATDECORATION\n" +
               "    \u2514 SECTIONDECORATION";
    } catch (e) {
        return "seatsToZoneBuild error: " + e + " (line " + (e.line || "?") + ")";
    }
}


/* ═══════════════════════════════════════════════════════════════
   §82 — HIERARCHY VALIDATOR (10-item compliance check)
   ═══════════════════════════════════════════════════════════════ */

function hierarchyValidate() {
    try {
        if (app.documents.length === 0) return '{"error":"No doc","checks":[]}';
        var doc = app.activeDocument;
        var checks = [];

        function push(label, status, detail) {
            checks.push({ label: label, status: status, detail: detail || "" });
        }

        // 1. STAGE contains only ONE shape
        var stage = findGroupByName(doc, "STAGE");
        if (!stage) push("STAGE contains exactly ONE shape", "fail", "STAGE group missing");
        else {
            var shapeCount = 0;
            if (stage.pageItems) {
                for (var i = 0; i < stage.pageItems.length; i++) {
                    var t = stage.pageItems[i].typename;
                    if (t === "PathItem" || t === "CompoundPathItem" || t === "Rectangle") shapeCount++;
                }
            }
            push("STAGE contains exactly ONE shape",
                shapeCount === 1 ? "pass" : "fail",
                shapeCount === 1 ? "" : shapeCount + " shape(s) found");
        }

        // 2. STAGE has no text, no sub-groups
        if (!stage) push("STAGE has no text, no sub-groups", "fail", "STAGE missing");
        else {
            var textCount = 0, subgroupCount = 0;
            if (stage.pageItems) {
                for (var j = 0; j < stage.pageItems.length; j++) {
                    if (stage.pageItems[j].typename === "TextFrame") textCount++;
                    if (stage.pageItems[j].typename === "GroupItem") subgroupCount++;
                }
            }
            var issues = [];
            if (textCount > 0) issues.push(textCount + " text");
            if (subgroupCount > 0) issues.push(subgroupCount + " sub-group");
            push("STAGE has no text, no sub-groups",
                issues.length === 0 ? "pass" : "fail",
                issues.join(", "));
        }

        // 3. DECORATION exists (holds stage label, stairs, doors)
        var deco = findGroupByName(doc, "DECORATION");
        push("DECORATION contains stage label + fixtures",
            deco ? "pass" : "fail",
            deco ? (deco.pageItems ? deco.pageItems.length + " items" : "empty") : "missing");

        // 4. All sublayer names correct (no _n_ suffixes except required)
        var badNames = [];
        function scanNames(container) {
            if (!container) return;
            if (container.name) {
                // Numbered suffix on non-SOP names
                if (/^(SECTIONDECORATION|UNDERSEATDECORATION|SEATDECORATION|SEATLABELS|DECORATION|SECTION|SEAT|STAGE)\d+$/i.test(container.name)) {
                    badNames.push(container.name);
                }
            }
            if (container.pageItems) {
                for (var i = 0; i < container.pageItems.length; i++) scanNames(container.pageItems[i]);
            }
            if (container.layers) {
                for (var i = 0; i < container.layers.length; i++) scanNames(container.layers[i]);
            }
        }
        scanNames(doc);
        push("All sublayer names correct (no _n_ artefacts)",
            badNames.length === 0 ? "pass" : "fail",
            badNames.length === 0 ? "" : badNames.slice(0,3).join(", ") + (badNames.length > 3 ? " +" + (badNames.length-3) : ""));

        // 5. SECTION contains exactly ONE shape
        var sections = [];
        findGroupsByExactName(doc, "SECTION", sections);
        var secBadCount = 0;
        for (var ss = 0; ss < sections.length; ss++) {
            var sc = 0;
            if (sections[ss].pageItems) {
                for (var sj = 0; sj < sections[ss].pageItems.length; sj++) {
                    var st = sections[ss].pageItems[sj].typename;
                    if (st === "PathItem" || st === "CompoundPathItem" || st === "Rectangle") sc++;
                }
            }
            if (sc !== 1) secBadCount++;
        }
        if (sections.length === 0) push("Each SECTION contains exactly ONE shape", "warn", "No SECTION groups found");
        else push("Each SECTION contains exactly ONE shape",
            secBadCount === 0 ? "pass" : "fail",
            secBadCount === 0 ? sections.length + " section(s)" : secBadCount + "/" + sections.length + " wrong");

        // 6. SEAT contains seat elements
        var seats = [];
        collectSeats(doc, seats);
        push("SEAT groups contain seat elements",
            seats.length > 0 ? "pass" : "warn",
            seats.length + " seats total");

        // 7. SECTIONDECORATION no nested groups
        var sdecs = [];
        findGroupsByExactName(doc, "SECTIONDECORATION", sdecs);
        var nestedCount = 0;
        for (var sdi = 0; sdi < sdecs.length; sdi++) {
            if (sdecs[sdi].pageItems) {
                for (var sdj = 0; sdj < sdecs[sdi].pageItems.length; sdj++) {
                    if (sdecs[sdi].pageItems[sdj].typename === "GroupItem") nestedCount++;
                }
            }
        }
        if (sdecs.length === 0) push("SECTIONDECORATION has no nested groups", "warn", "None found");
        else push("SECTIONDECORATION has no nested groups",
            nestedCount === 0 ? "pass" : "warn",
            nestedCount === 0 ? "" : nestedCount + " nested group(s)");

        // 8. SEATLABELS present and empty
        var sl = findGroupByName(doc, "SEATLABELS");
        if (!sl) push("SEATLABELS present and empty", "fail", "missing — add via FIX tab");
        else {
            var slChildren = sl.pageItems ? sl.pageItems.length : 0;
            push("SEATLABELS present and empty",
                slChildren === 0 ? "pass" : "fail",
                slChildren === 0 ? "" : "has " + slChildren + " child(ren)");
        }

        // 9. Z-order: STAGE > DECORATION > ZONES > SEATLABELS
        // Check topmost is SEATLABELS or similar; bottommost is STAGE
        var topLevel = [];
        if (doc.layers && doc.layers.length > 0) {
            // Check on primary layer or across layers
            var primaryLayer = doc.layers[0];
            if (primaryLayer.pageItems) {
                for (var tl = 0; tl < primaryLayer.pageItems.length; tl++) {
                    var tn = primaryLayer.pageItems[tl].name;
                    if (tn === "STAGE" || tn === "DECORATION" || tn === "SEATLABELS" || tn.indexOf("ZONE") === 0) {
                        topLevel.push(tn);
                    }
                }
            }
        }
        // In AI, index 0 = top. So expected order from top: SEATLABELS, ZONES..., DECORATION, STAGE
        var zOrderOk = false;
        if (topLevel.length > 0) {
            var slIdx = -1, stgIdx = -1;
            for (var ti = 0; ti < topLevel.length; ti++) {
                if (topLevel[ti] === "SEATLABELS") slIdx = ti;
                if (topLevel[ti] === "STAGE") stgIdx = ti;
            }
            // SEATLABELS should come before STAGE (smaller idx = higher in stack)
            zOrderOk = (slIdx === -1 || stgIdx === -1 || slIdx < stgIdx);
        }
        push("Z-order: STAGE > DECORATION > ZONES > SEATLABELS",
            zOrderOk ? "pass" : "warn",
            zOrderOk ? "" : "reorder needed — run FIX → Fix Z-Order");

        // 10. No CSS transforms on seat groups (detectable by rotation)
        var rotated = 0;
        for (var ri = 0; ri < seats.length; ri++) {
            try { if (Math.abs(seats[ri].rotation) > 0.1) rotated++; } catch (e) {}
        }
        push("No rotation/transforms on seat elements",
            rotated === 0 ? "pass" : "fail",
            rotated === 0 ? "" : rotated + " rotated seat(s)");

        return _jsonStringify({ checks: checks });
    } catch (e) {
        return '{"error":"' + String(e).replace(/"/g,"") + '","checks":[]}';
    }
}


// v6.5.1: backward-compatible v5 public API additions.
function buildResult(ok, message, data) {
    return { ok: ok, message: String(message), data: data || {}, ts: new Date().getTime() };
}
function stringifyResult(r) {
    if (!r || typeof r.ok === "undefined") return String(r);
    return (r.ok ? "\u2705 " : "\u274C ") + r.message;
}
function autoBackupDocument(tag) { return createBackupSnapshot(tag); }
function detectHierarchyMode(doc) {
    var hL = false, hG = false;
    if (doc.layers) for (var i = 0; i < doc.layers.length; i++)
        if (doc.layers[i].name && doc.layers[i].name.indexOf("ZONE_") === 0) { hL = true; break; }
    function sg(c) { if (!c || !c.pageItems) return; for (var j = 0; j < c.pageItems.length; j++) {
        var it = c.pageItems[j];
        if (it.typename === "GroupItem" && it.name && it.name.indexOf("ZONE_") === 0) { hG = true; return; }
        if (it.pageItems) sg(it); } }
    sg(doc);
    if (hL && hG) return "mixed"; if (hL) return "layer"; if (hG) return "group"; return "group";
}
function eachZone(doc, fn) {
    if (doc.layers) for (var i = 0; i < doc.layers.length; i++)
        if (doc.layers[i].name && doc.layers[i].name.indexOf("ZONE_") === 0) fn(doc.layers[i], "layer");
    function wg(c) { if (!c || !c.pageItems) return;
        for (var j = 0; j < c.pageItems.length; j++) {
            var it = c.pageItems[j];
            if (it.typename === "GroupItem" && it.name && it.name.indexOf("ZONE_") === 0) fn(it, "group");
            else if (it.pageItems) wg(it);
        }
    }
    wg(doc);
}
function findSeatContainer(zone) {
    if (!zone || !zone.pageItems) return null;
    for (var i = 0; i < zone.pageItems.length; i++)
        if (zone.pageItems[i].name === "SEAT" || zone.pageItems[i].name === "SEAT") return zone.pageItems[i];
    if (zone.layers) for (var j = 0; j < zone.layers.length; j++)
        if (zone.layers[j].name === "SEAT") return zone.layers[j];
    return null;
}
function runFixPipeline(name) {
 if(!app.documents.length)return "ERROR: No document open.";
 var pipeline=FIX_PIPELINES[name];if(!pipeline)return "ERROR: Unknown pipeline: "+name;
 var failed=0,results=[];
 for(var i=0;i<pipeline.length;i++){
  try{var fn=eval(pipeline[i]);var r=String(fn());if(/error|failed|blocked/i.test(r))failed++;results.push(pipeline[i]+": "+r);}
  catch(e){failed++;results.push(pipeline[i]+": ERROR: "+e);}
 }
 return "=== Pipeline "+name+": "+failed+" failed steps ===\n"+results.join("\n");
}
function fixAllSOPFull()  { return runFixPipeline("full");      }
function hexToRGB(hex) {
    hex=String(hex||'').replace(/^#/,'');if(/^[a-f0-9]{3}$/i.test(hex))hex=hex.charAt(0)+hex.charAt(0)+hex.charAt(1)+hex.charAt(1)+hex.charAt(2)+hex.charAt(2);
    if(!/^[a-f0-9]{6}$/i.test(hex))return {r:143,g:199,b:255};
    return {r:parseInt(hex.substr(0,2),16),g:parseInt(hex.substr(2,2),16),b:parseInt(hex.substr(4,2),16)};
}
function djb2Hash(str) {
    str = String(str);
    var h1 = 5381;
    for (var i = 0; i < str.length; i++) {
        h1 = (((h1 << 5) + h1) + str.charCodeAt(i)) >>> 0;
    }
    var h2 = 52711;
    for (var j = str.length - 1; j >= 0; j--) {
        h2 = (((h2 << 5) + h2) ^ str.charCodeAt(j)) >>> 0;
    }
    return ("00000000" + h1.toString(16)).slice(-8) +
           ("00000" + h2.toString(16)).slice(-5);
}
function requireDoc() {
    if (app.documents.length === 0) {
        throw "No document open.\nOpen a file first, then try again.";
    }
    return app.activeDocument;
}
function collectSeatsScoped(doc, seats, scopeCSV) {
    if (!scopeCSV || scopeCSV === "ALL") {
        collectSeats(doc, seats);
        return;
    }
    var allowed = {};
    var zones = scopeCSV.split(",");
    for (var i = 0; i < zones.length; i++) {
        var z = sopTrim(zones[i]);
        if (z) allowed[z] = true;
    }
    // Only collect from matching ZONE groups
    function scanZone(container) {
        if (!container) return;
        if (container.name && allowed[container.name]) {
            collectSeats(container, seats);
            return; // don't recurse into children \u2014 collectSeats handles that
        }
        if (container.layers) {
            for (var i = 0; i < container.layers.length; i++)
                scanZone(container.layers[i]);
        }
        if (container.pageItems) {
            for (var i = 0; i < container.pageItems.length; i++)
                scanZone(container.pageItems[i]);
        }
    }
    scanZone(doc);
}
function safeExportSVG(doc, svgFile, opts) {
 var staging=new File(svgFile.parent.fsName+"/.yw-export-"+new Date().getTime()+".svg");
 try {
  doc.exportFile(staging,ExportType.SVG,opts||safeSOPExportOpts());
  stripAI2026Suffixes(staging);
  var result=sanitizeSOPSVG(staging);
  if(!result.ok)throw new Error("Export blocked: "+result.message);
  if(!staging.copy(svgFile.fsName))throw new Error("Cannot publish SVG: "+svgFile.fsName);
 } finally {if(staging.exists)staging.remove();}
}
function safeNoColor() {
    try { return new NoColor(); }
    catch (e) {
        // Fallback: create a transparent color
        var c = new RGBColor();
        c.red = 0; c.green = 0; c.blue = 0;
        return c;
    }
}
var SOP_RULES = {
    seat:   { width:7, height:7, rx:1.5, ry:1.5, step:9, aisle:27, labelSize:30 },
    names:  {
        stage:"STAGE", decoration:"DECORATION", seatlabels:"SEATLABELS",
        section:"SECTION", underseat:"UNDERSEATDECORATION",
        seat:"SEAT", seatdecoration:"SEATDECORATION",
        sectiondecoration:"SECTIONDECORATION"
    },
    colors: {
        sectionFill:[241,241,241], sectionStroke:[209,210,212],
        decorFill:[255,255,255],  decorStroke:[209,210,212],
        stageFill:[224,224,224],  stageStroke:[204,204,204],
        labelText:[109,110,112]
    },
    forbidden:["ClipPathItem","RasterItem","PlacedItem","SymbolItem","MeshItem"],
    idPattern:/^seatData-[A-Za-z0-9]+-([0-9]+)-\\1-1-[a-f0-9]{6,13}$/
};
var FIX_PIPELINES = {
    colors:["fixSectionFills","fixSectionStrokes","fixSeatStrokes","fixSeatOpacity",
            "fixLabelColors","fixTextStrokes","fixDecorBadgeFills","fixStageFill"],
    ids:["fixSeatDataCase","fixGroupHyphens","fixHashSpaces","fixSeatFieldMismatch",
         "fixField4","fixMalformedIDs","fixDuplicateHashes","autoFixSeatIDs"],
    structure:["fixSubLayerNames","addSEATLABELS","fixStageGroup","fixZOrder","cleanEmptyGroups"],
    geometry:["fixSeatSizes","alignToPixelGrid","snapToGrid"],
    full:[
        "fixSubLayerNames","addSEATLABELS",
        "removeAllForbidden",
        "fixZOrder","fixStageGroup","fixStageFill","fixStageLabel",
        "fixSectionFills","fixSectionStrokes","fixSeatStrokes",
        "fixSeatOpacity","fixLabelColors","fixTextStrokes","fixDecorBadgeFills",
        "fixSeatSizes","alignToPixelGrid",
        "fixSeatDataCase","fixGroupHyphens","fixHashSpaces",
        "fixSeatFieldMismatch","fixField4","fixMalformedIDs",
        "fixDuplicateHashes","autoFixSeatIDs",
        "cleanHiddenLayers","cleanEmptyGroups","removeStrayObjects"
    ]
};

// Production Studio host integration, v6.5.1. All entry points are ES3.
function ywStudioCaptureSVG() {
 var f=null;
 try {
  if(!app.documents.length)throw new Error("No document open.");
  f=new File(Folder.temp.fsName+"/yw-studio-"+new Date().getTime()+".svg");
  var d=app.activeDocument;
  d.exportFile(f,ExportType.SVG,safeSOPExportOpts());
  if(!f.exists||f.length>15000000)throw new Error("SVG missing or exceeds the 15 MB Studio bridge limit.");
  f.encoding="UTF-8";if(!f.open("r"))throw new Error("Cannot read temporary SVG.");
  var svg=f.read();f.close();
  return _jsonStringify({ok:true,name:d.name,svg:svg});
 }catch(e){return "ERROR: Capture SVG: "+e+" line="+(e.line||"?");}
 finally{if(f){try{f.close();f.remove();}catch(ignore){}}}
}
function ywStudioOpenSVG(svg) {
 var f=null;
 try {
  svg=String(svg||"");
  if(!/<svg\b/i.test(svg)||svg.length>15000000)throw new Error("Invalid SVG or exceeds 15 MB.");
  if(/<!DOCTYPE|<!ENTITY|<script\b|<foreignObject\b|\son[a-z]+\s*=|(?:href|src)\s*=\s*["']\s*(?:https?:|file:|javascript:|\/\/)/i.test(svg))throw new Error("Unsafe or external SVG content is not allowed.");
  f=new File(Folder.temp.fsName+"/yw-studio-revision-"+new Date().getTime()+".svg");
  f.encoding="UTF-8";if(!f.open("w"))throw new Error("Cannot create SVG revision.");
  f.write(svg);f.close();app.open(f);
  return "Opened Studio revision as a separate SVG document. Save As AI to retain it. Original document remains open.";
 }catch(e){return "ERROR: Open Studio SVG: "+e+" line="+(e.line||"?");}
 // Keep the temp source while the new Illustrator document refers to it.
}
function ywAuditAndAutoFix() {
 if(!app.documents.length)return "ERROR: No document open.";
 var before=runFullChecklist();
 var steps=[fixSubLayerNames,addSEATLABELS,fixSectionFills,fixSectionStrokes,fixSeatStrokes,fixSeatOpacity,fixLabelColors];
 var log=[],fail=0;
 for(var i=0;i<steps.length;i++){
  try{var r=String(steps[i]());log.push(r);if(/error|failed/i.test(r))fail++;}
  catch(e){fail++;log.push("ERROR: "+e);}
 }
 return "=== Audit + conservative auto-fix ===\nFailed steps: "+fail+"\nID changes, seat movement and artwork deletion require explicit tools.\n\nBEFORE\n"+before+"\n\nFIXES\n"+log.join("\n")+"\n\nAFTER\n"+runFullChecklist();
}
// Set only after all core declarations and initialization have succeeded.
var YW_HOST_VERSION="6.5.1";

function ywBuildPath(parent, points, origin, fill, stroke) {
    var path=parent.pathItems.add(),pts=[];
    for(var i=0;i<points.length;i++)pts.push([origin[0]+points[i][0],origin[1]-points[i][1]]);
    path.setEntirePath(pts);path.closed=true;path.filled=!!fill;if(fill)path.fillColor=fill;
    path.stroked=!!stroke;if(stroke){path.strokeColor=stroke;path.strokeWidth=1;}
    return path;
}
function ywBuildLabel(parent,text,cx,bottom,size,above) {
    var t=parent.textFrames.add();t.contents=String(text);t.name='zone_label';
    var a=t.textRange.characterAttributes;a.size=size;a.fillColor=makeColorSafe(109,110,112);a.strokeColor=new NoColor();
    try{a.textFont=app.textFonts.getByName('ArialMT');}catch(ignore){}
    t.position=[cx-t.width/2,above?bottom+t.height:bottom+t.height/2];
    t.zOrder(ZOrderMethod.BRINGTOFRONT);return t;
}
function ywBuildStage(p) {
    if(!app.documents.length)return 'ERROR: Open a document before building a stage.';
    var created=null,newLabel=null,committed=false;
    try{
        var doc=app.activeDocument,w=p.width===undefined?p.w:p.width,h=p.height===undefined?p.h:p.height;
        var kind=p.shape||p.stageType||'rect',x=YWGeometry.number(p.x,200,-15000,15000,'Stage X'),y=YWGeometry.number(p.y,50,-15000,15000,'Stage Y');
        var size=YWGeometry.number(p.fontSize,30,8,120,'Label size'),rotation=YWGeometry.number(p.rotation,0,-360,360,'Rotation');
        var outline=YWGeometry.transform(YWGeometry.stage(kind,w,h,p.cornerRadius),x,y,rotation),b=YWGeometry.bounds(outline);
        var index=doc.artboards.getActiveArtboardIndex(),ab=doc.artboards[index].artboardRect,origin=[ab[0],ab[1]];
        var stage=findGroupByName(doc,'STAGE'),deco=findGroupByName(doc,'DECORATION');
        if(!stage&&p.createLayers===false)throw new Error('STAGE is missing. Enable creation of missing layers.');
        if(!deco&&p.createLayers===false)throw new Error('DECORATION is missing. Enable creation of missing layers.');
        if(stage&&(stage.locked||stage.hidden||stage.visible===false))throw new Error('Unlock and show STAGE before rebuilding.');
        if(deco&&(deco.locked||deco.hidden||deco.visible===false))throw new Error('Unlock and show DECORATION before rebuilding.');
        var old=[],labels=[],i;
        if(stage){
            if(stage.layers&&stage.layers.length)throw new Error('STAGE has nested layers. Flatten its hierarchy before replacing it.');
            for(i=0;i<stage.pageItems.length;i++)if(stage.pageItems[i].parent===stage){if(stage.pageItems[i].locked)throw new Error('Unlock existing stage artwork first.');old.push(stage.pageItems[i]);}
        }
        if(old.length&&p.replaceExisting===false)throw new Error('A stage already exists. Enable Replace existing stage to keep one stage shape.');
        if(deco)for(i=0;i<deco.textFrames.length;i++)if(deco.textFrames[i].parent===deco&&deco.textFrames[i].name==='stage_label'){if(deco.textFrames[i].locked)throw new Error('Unlock the existing stage label first.');labels.push(deco.textFrames[i]);}
        if(!stage){stage=doc.layers.add();stage.name='STAGE';stage.zOrder(ZOrderMethod.SENDTOBACK);}
        if(!deco){deco=doc.layers.add();deco.name='DECORATION';}
        created=ywBuildPath(stage,outline,origin,makeColorSafe(224,224,224),makeColorSafe(204,204,204));created.name='stage_shape';
        var label=p.label===undefined?'STAGE':String(p.label);
        if(label){newLabel=ywBuildLabel(deco,label,origin[0]+(b[0]+b[2])/2,origin[1]-(b[1]+b[3])/2,size,false);newLabel.name='stage_label';}
        // Build the replacement successfully before removing old generated content.
        committed=true;
        for(i=0;i<old.length;i++)old[i].remove();for(i=0;i<labels.length;i++)labels[i].remove();
        stage.zOrder(ZOrderMethod.SENDTOBACK);app.redraw();
        return 'Stage built: '+kind+'\nOne closed path in STAGE; label in DECORATION.\nPosition is measured from the active artboard. Existing unrelated decoration is preserved.';
    }catch(e){try{if(!committed){if(created)created.remove();if(newLabel)newLabel.remove();}}catch(ignore){}return 'ERROR: Stage builder: '+e+' (line '+(e.line||'?')+')';}
}
function ywSOPAuditData() {
    if(!app.documents.length)throw new Error('No document open.');
    var doc=app.activeDocument, nodes=[],seats=[],stages=[],sections=[],labels=[],decos=[],hidden=0,suffix=0,orphans=0;
    function children(o){var a=[],i,c;if(o.layers)for(i=0;i<o.layers.length;i++){c=o.layers[i];if(c.parent===o)a.push(c);}if(o.pageItems)for(i=0;i<o.pageItems.length;i++){c=o.pageItems[i];if(c.parent===o)a.push(c);}return a;}
    function walk(o,inSeats){var a=children(o);for(var i=0;i<a.length;i++){var n=a[i],name=String(n.name||''),container=n.typename==='GroupItem'||n.typename==='Layer';nodes.push(n);if(n.hidden||n.visible===false)hidden++;if(/^(SECTION|SEAT|SEATDECORATION|UNDERSEATDECORATION|SECTIONDECORATION|SEATLABELS)(?:_\d+_|\d+)$/.test(name))suffix++;if(container){if(name==='STAGE')stages.push(n);if(name==='SECTION')sections.push(n);if(name==='SECTIONDECORATION')decos.push(n);if(name==='SEATLABELS')labels.push(n);walk(n,inSeats||/^SEAT(?:_\d+_)?$/.test(name));}else if(inSeats||/^seatData-/i.test(name)){seats.push(n);if(!inSeats)orphans++;}}}
    walk(doc,false);
    var rows=[],pass=0,fail=0,pending=0;
    function check(name,ok,detail){var status=ok===null?'PENDING':ok?'PASS':'FAIL';if(ok===null)pending++;else if(ok)pass++;else fail++;rows.push({name:name,status:status,detail:detail||''});}
    function rgb(c,r,g,b){return c&&c.typename==='RGBColor'&&Math.abs(c.red-r)<.6&&Math.abs(c.green-g)<.6&&Math.abs(c.blue-b)<.6;}
    function shapes(o){var a=children(o);return a.length===1&&(a[0].typename==='PathItem'||a[0].typename==='CompoundPathItem');}
    var ids={},hashes={},dups=0,bad=0,mismatch=0,field4=0,groupBad=0,hashBad=0,spaces=0,hashDup=0,wrong=0,stroke=0,kind=0,boundsBad=0,gaps=0,buckets={},geometryUnknown=false;
    var ab=doc.artboards[doc.artboards.getActiveArtboardIndex()].artboardRect;
    for(var i=0;i<seats.length;i++){
        var s=seats[i],id=String(s.name||''),parts=id.split('-'),valid=/^seatData-([A-Za-z0-9_]+)-(\d+)-\2-1-([a-f0-9]{6,13})$/.test(id);
        if(!valid)bad++;if(ids['$'+id])dups++;ids['$'+id]=true;
        if(parts.length!==6||!/^\d+$/.test(parts[2]||'')||parts[2]!==parts[3])mismatch++;
        if(parts[4]!=='1')field4++;if(parts.length!==6||!/^[A-Za-z0-9_]+$/.test(parts[1]||''))groupBad++;
        var hash=parts[5]||'';if(!/^[a-f0-9]{6,13}$/.test(hash))hashBad++;if(hashes['$'+hash])hashDup++;hashes['$'+hash]=true;if(/\s/.test(id))spaces++;
        if(s.typename!=='PathItem')kind++;if(s.stroked)stroke++;
        var b=s.geometricBounds;
        if(!b||!isFinite(b[0]+b[1]+b[2]+b[3])){wrong++;boundsBad++;geometryUnknown=true;continue;}
        var w=b[2]-b[0],h=b[1]-b[3];if(Math.abs(w-7)>.01||Math.abs(h-7)>.01){wrong++;geometryUnknown=true;continue;}
        if(b[0]<ab[0]-.01||b[1]>ab[1]+.01||b[2]>ab[2]+.01||b[3]<ab[3]-.01)boundsBad++;
        var bx=Math.floor(b[0]/16),by=Math.floor(b[3]/16);
        for(var dx=-1;dx<=1;dx++)for(var dy=-1;dy<=1;dy++){var bucket=buckets['$'+(bx+dx)+','+(by+dy)]||[];for(var j=0;j<bucket.length;j++){var q=bucket[j],gx=Math.max(0,b[0]-q[2],q[0]-b[2]),gy=Math.max(0,b[3]-q[1],q[3]-b[1]);if(Math.sqrt(gx*gx+gy*gy)<1.99)gaps++;}}
        var key='$'+bx+','+by;if(!buckets[key])buckets[key]=[];buckets[key].push(b);
    }
    // Eight export-element checks: Illustrator DOM cannot prove final SVG tags.
    var forbidden=['clipPath','mask','symbol','image','use','filter','circle','ellipse / polygon'];
    for(i=0;i<forbidden.length;i++)check('No '+forbidden[i],null,'Verify exported SVG; not inferred from Illustrator.');
    var hasSeats=seats.length>0;
    check('Every seat has a valid unique seatData ID',hasSeats?bad===0&&dups===0:null,seats.length+' seats; '+bad+' malformed');
    check('No duplicate seat IDs',hasSeats?dups===0:null,dups+' duplicate(s)');
    check('Five payload fields after seatData prefix',hasSeats?groupBad===0:null);
    check('SEAT number fields match',hasSeats?mismatch===0:null);
    check('Field 4 equals 1',hasSeats?field4===0:null);
    check('GROUP contains no hyphens',hasSeats?groupBad===0:null);
    check('Unique 6-13 character hexadecimal hashes',hasSeats?hashBad===0&&hashDup===0:null,hashDup+' duplicate hashes');
    check('No spaces in seat IDs',hasSeats?spaces===0:null);
    check('Complete seat ID pattern',hasSeats?bad===0:null);
    var stageOK=stages.length===1&&shapes(stages[0]),sectionOK=sections.length>0,flat=true,empty=labels.length===1;
    for(i=0;i<sections.length;i++)if(!shapes(sections[i]))sectionOK=false;
    for(i=0;i<decos.length;i++){var a=children(decos[i]);for(j=0;j<a.length;j++)if(a[j].typename==='GroupItem'||a[j].typename==='Layer')flat=false;}
    for(i=0;i<labels.length;i++)if(children(labels[i]).length)empty=false;
    check('Exactly one STAGE containing one shape',stageOK,stages.length+' STAGE containers');check('STAGE has no text or subgroups',stageOK);
    check('DECORATION present',!!findGroupByName(doc,'DECORATION'));check('Canonical sublayer names',suffix===0,suffix+' suffixed names');check('SECTION contains exactly one shape',sectionOK);
    check('All seats inside SEAT containers',orphans===0,orphans+' orphan seats');check('SECTIONDECORATION has no nested containers',flat);check('SEATLABELS exists and is empty',empty);
    check('Required export stacking order',null,'Inspect exported hierarchy.');check('No CSS transforms on seat groups',null,'Inspect exported SVG.');
    check('Seats are path elements',hasSeats?kind===0:null);check('Seats measure 7 x 7 px',hasSeats?wrong===0:null,wrong+' wrong or unreadable bounds');check('Seat corner radius 1.5 px',null,'Validate path curvature or exported rect rx/ry.');check('Seats have no stroke',hasSeats?stroke===0:null);
    check('Approved seat palette',null,'Compare against venue-approved category palette.');check('Minimum seat gap 2 px',hasSeats?(gaps?false:geometryUnknown?null:true):null,gaps+' close pairs; axis-aligned bounds test');check('Seats inside active artboard',hasSeats?boundsBad===0:null,boundsBad+' outside or unreadable');
    var fill=true,line=true,stageColor=stageOK,textColor=true,textStroke=true,textCount=0;
    for(i=0;i<sections.length;i++){a=children(sections[i]);for(j=0;j<a.length;j++){if(!a[j].filled||!rgb(a[j].fillColor,241,241,241))fill=false;if(!a[j].stroked||!rgb(a[j].strokeColor,209,210,212))line=false;}}
    if(stageOK){var sp=children(stages[0])[0];stageColor=!!sp.filled&&rgb(sp.fillColor,224,224,224)&&!!sp.stroked&&rgb(sp.strokeColor,204,204,204);}
    for(i=0;i<nodes.length;i++)if(nodes[i].typename==='TextFrame'){textCount++;var chars=nodes[i].characters;for(j=0;chars&&j<chars.length;j++){var ca=chars[j].characterAttributes;if(!rgb(ca.fillColor,109,110,112))textColor=false;if(ca.strokeColor&&ca.strokeColor.typename!=='NoColor')textStroke=false;}}
    check('SECTION fill #F1F1F1',sections.length?fill:null);check('SECTION stroke #D1D2D4',sections.length?line:null);check('STAGE fill #E0E0E0 / stroke #CCCCCC',stageColor);check('Label text #6d6e70',textCount?textColor:null);check('Text fill only, no stroke',textCount?textStroke:null);
    check('Valid exported XML',null,'Export check');check('SVG below 5 MB',null,'Export check');check('SVG at most 500 KB ideal',null,'Export check');check('No hidden layers or objects',hidden===0,hidden+' hidden');check('UTF-8 export',null,'Export check');check('Manifest seat count matches',null,'Compare the approved manifest');check('Aisles match manifest numbering',null,'Compare source and manifest');
    check('Source overlay within 1 px',null,'Visual source comparison required');check('Ten-seat source spot check',null,'Visual source comparison required');check('Constructor staging passes',null,'Test uploaded map in Constructor');check('Lead sign-off',null,'Record reviewer and date');
    return {checks:rows,pass:pass,fail:fail,pending:pending,seats:seats.length};
}
function ywWalkArtwork(root,fn) {
    var i,n,a=[];if(root.layers)for(i=0;i<root.layers.length;i++){n=root.layers[i];if(n.parent===root)a.push(n);}if(root.pageItems)for(i=0;i<root.pageItems.length;i++){n=root.pageItems[i];if(n.parent===root)a.push(n);}
    for(i=0;i<a.length;i++){fn(a[i]);if(a[i].typename==='Layer'||a[i].typename==='GroupItem')ywWalkArtwork(a[i],fn);}
}