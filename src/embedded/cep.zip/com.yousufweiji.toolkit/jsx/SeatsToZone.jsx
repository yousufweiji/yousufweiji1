/**
 * SeatsToZone.jsx
 * ---------------
 * Select seat elements (individual or in groups) and run this script
 * to auto-build the full SOP-compliant ZONE hierarchy.
 *
 * Behaviour:
 *   - Individual (ungrouped) seats  → one zone
 *   - Multiple groups selected      → each group becomes its own zone
 *   - Mix of groups + loose seats   → groups become zones, loose seats become one zone
 *
 * Created hierarchy per zone (SOP §4):
 *   ZONE_{name}
 *     ├─ SECTION          (auto-generated bounding shape)
 *     ├─ UNDERSEATDECORATION (empty, placeholder)
 *     ├─ SEAT             (seats moved here)
 *     ├─ SEATDECORATION      (empty, placeholder)
 *     └─ SECTIONDECORATION(label badge + text)
 *
 *   SEATLABELS is created once at the document root (if missing).
 *
 * Usage: Select seats → File → Scripts → SeatsToZone.jsx
 */

(function () {

    // ─── Guards ───
    if (app.documents.length === 0) { alert("No document open."); return; }
    var doc = app.activeDocument;
    var sel = doc.selection;
    if (!sel || sel.length === 0) {
        alert("Nothing selected.\nSelect seat paths or groups of seats, then run again.");
        return;
    }

    // ─── Settings ───
    var SECTION_FILL    = makeRGB(241, 241, 241); // #F1F1F1
    var SECTION_STROKE  = makeRGB(209,210,212); // #D1D2D4
    var BADGE_FILL      = makeRGB(255, 255, 255); // #FFFFFF
    var LABEL_FILL      = makeRGB(109,110,112); // #6d6e70
    var SECTION_PAD     = 6; // px padding around seats for the section shape
    var BADGE_PAD       = 4; // extra padding for the decoration badge
    var LABEL_SIZE      = 30; // px — SOP standard
    var STROKE_WIDTH    = 1;

    // ─── Helpers ───
    function makeRGB(r, g, b) {
        var c = new RGBColor();
        c.red = r; c.green = g; c.blue = b;
        return c;
    }

    function getBoundsOfItems(items) {
        var l = Infinity, t = -Infinity, r = -Infinity, b = Infinity;
        for (var i = 0; i < items.length; i++) {
            var gb = items[i].geometricBounds; // [left, top, right, bottom]
            if (gb[0] < l) l = gb[0];
            if (gb[1] > t) t = gb[1];
            if (gb[2] > r) r = gb[2];
            if (gb[3] < b) b = gb[3];
        }
        return [l, t, r, b];
    }

    /** Collect all leaf PathItems from an item recursively */
    function collectLeafPaths(item, arr) {
        if (item.typename === "PathItem") {
            arr.push(item);
        } else if (item.typename === "CompoundPathItem") {
            for (var i = 0; i < item.pathItems.length; i++) {
                arr.push(item.pathItems[i]);
            }
        } else if (item.typename === "GroupItem") {
            for (var j = 0; j < item.pageItems.length; j++) {
                collectLeafPaths(item.pageItems[j], arr);
            }
        }
    }

    // ─── Categorise selection into clusters ───
    // Each cluster = { seats: [PathItem], sourceName: string|null }
    var clusters = [];
    var loosePaths = [];

    for (var s = 0; s < sel.length; s++) {
        var item = sel[s];
        if (item.typename === "GroupItem") {
            var paths = [];
            collectLeafPaths(item, paths);
            if (paths.length > 0) {
                clusters.push({
                    seats: paths,
                    sourceGroup: item,
                    sourceName: item.name || null
                });
            }
        } else if (item.typename === "PathItem" || item.typename === "CompoundPathItem") {
            var lp = [];
            collectLeafPaths(item, lp);
            for (var k = 0; k < lp.length; k++) loosePaths.push(lp[k]);
        }
    }

    // Loose paths form their own cluster
    if (loosePaths.length > 0) {
        clusters.push({
            seats: loosePaths,
            sourceGroup: null,
            sourceName: null
        });
    }

    if (clusters.length === 0) {
        alert("No seat paths found in selection.");
        return;
    }

    // ─── Prompt for zone names ───
    var zoneNames = [];
    for (var c = 0; c < clusters.length; c++) {
        var defaultName = clusters[c].sourceName || ("ZONE_" + (c + 1));
        // Clean up: strip existing ZONE_ prefix if present
        defaultName = defaultName.replace(/^ZONE_/i, "");
        var input = prompt(
            "Zone " + (c + 1) + " of " + clusters.length +
            "  (" + clusters[c].seats.length + " seats)\n\n" +
            "Enter zone name (e.g. A, VIP, 101):",
            defaultName
        );
        if (input === null) { alert("Cancelled."); return; }
        input = input.replace(/^\s+|\s+$/g, "");
        if (input === "") input = "ZONE" + (c + 1);
        zoneNames.push(input);
    }

    // ─── Determine insertion target ───
    // We place zones on the active layer, before SEATLABELS if it exists
    var targetLayer = doc.activeLayer;

    // ─── Ensure SEATLABELS exists at root ───
    var seatLabelsExists = false;
    try {
        for (var gl = 0; gl < targetLayer.groupItems.length; gl++) {
            if (targetLayer.groupItems[gl].name === "SEATLABELS") {
                seatLabelsExists = true;
                break;
            }
        }
    } catch (e) {}

    // ─── Build each zone ───
    var report = [];

    for (var z = clusters.length - 1; z >= 0; z--) {
        var zoneName = zoneNames[z];
        var seats    = clusters[z].seats;
        var seatCount = seats.length;

        // Compute bounds of all seats
        var bounds = getBoundsOfItems(seats);
        var sL = bounds[0], sT = bounds[1], sR = bounds[2], sB = bounds[3];

        // ── Create ZONE group ──
        var zoneGroup = targetLayer.groupItems.add();
        zoneGroup.name = "ZONE_" + zoneName;

        // ── Build sub-layers in REVERSE order (last added = first child = back) ──
        // We need z-order: SECTION (back) → UNDERSEATDECORATION → SEAT → SEATDECORATION → SECTIONDECORATION (front)

        // 5. SECTIONDECORATION (front — added first so it ends up on top after moves)
        var secDecorGroup = zoneGroup.groupItems.add();
        secDecorGroup.name = "SECTIONDECORATION";

        // Badge background (white rounded rect behind label)
        var labelText = zoneName;
        // Estimate text width (~18px per char at 30px font, rough)
        var estTextW = labelText.length * 18;
        if (estTextW < 40) estTextW = 40;
        var estTextH = 36;
        var badgeCX = (sL + sR) / 2;
        var badgeCY = (sT + sB) / 2;
        var badgeW = estTextW + BADGE_PAD * 2;
        var badgeH = estTextH + BADGE_PAD * 2;

        var badge = secDecorGroup.pathItems.rectangle(
            badgeCY + badgeH / 2,   // top
            badgeCX - badgeW / 2,   // left
            badgeW,                  // width
            badgeH                   // height
        );
        badge.fillColor = BADGE_FILL;
        badge.stroked = true;
        badge.strokeColor = SECTION_STROKE;
        badge.strokeWidth = STROKE_WIDTH;
        badge.name = "";

        // Label text
        var labelTF = secDecorGroup.textFrames.add();
        labelTF.contents = labelText;
        labelTF.textRange.characterAttributes.size = LABEL_SIZE;
        try {
            labelTF.textRange.characterAttributes.textFont =
                app.textFonts.getByName("ArialMT");
        } catch (e) {
            try {
                labelTF.textRange.characterAttributes.textFont =
                    app.textFonts.getByName("Arial");
            } catch (e2) {}
        }
        labelTF.textRange.characterAttributes.fillColor = LABEL_FILL;
        // Center the text on the badge
        labelTF.left = badgeCX - labelTF.width / 2;
        labelTF.top  = badgeCY + labelTF.height / 2;

        // 4. SEATDECORATION (empty)
        var seatDecorGroup = zoneGroup.groupItems.add();
        seatDecorGroup.name = "SEATDECORATION";

        // 3. SEAT — seats will be moved here
        var seatGroup = zoneGroup.groupItems.add();
        seatGroup.name = "SEAT";

        // 2. UNDERSEATDECORATION (empty)
        var underSeatGroup = zoneGroup.groupItems.add();
        underSeatGroup.name = "UNDERSEATDECORATION";

        // 1. SECTION — bounding shape (back)
        var sectionGroup = zoneGroup.groupItems.add();
        sectionGroup.name = "SECTION";

        var secRect = sectionGroup.pathItems.rectangle(
            sT + SECTION_PAD,           // top
            sL - SECTION_PAD,           // left
            (sR - sL) + SECTION_PAD * 2, // width
            (sT - sB) + SECTION_PAD * 2  // height
        );
        secRect.fillColor = SECTION_FILL;
        secRect.stroked = true;
        secRect.strokeColor = SECTION_STROKE;
        secRect.strokeWidth = STROKE_WIDTH;

        // ── Move seats into SEAT ──
        // Move in reverse to preserve order
        for (var m = seats.length - 1; m >= 0; m--) {
            try {
                seats[m].move(seatGroup, ElementPlacement.PLACEATBEGINNING);
            } catch (e) {}
        }

        // ── Clean up source group if it's now empty ──
        if (clusters[z].sourceGroup) {
            try {
                if (clusters[z].sourceGroup.pageItems.length === 0) {
                    clusters[z].sourceGroup.remove();
                }
            } catch (e) {}
        }

        // ── Reorder sub-layers so z-order is correct ──
        // Target order (bottom to top): SECTION → UNDERSEAT → SEAT → SEATDECOR → SECTIONDECOR
        // Move each to front in reverse desired order
        try {
            sectionGroup.zOrder(ZOrderMethod.SENDTOBACK);
            underSeatGroup.move(sectionGroup, ElementPlacement.PLACEAFTER);
            seatGroup.move(underSeatGroup, ElementPlacement.PLACEAFTER);
            seatDecorGroup.move(seatGroup, ElementPlacement.PLACEAFTER);
            secDecorGroup.move(seatDecorGroup, ElementPlacement.PLACEAFTER);
        } catch (e) {}

        report.push("  ZONE_" + zoneName + ":  " + seatCount + " seats");
    }

    // ─── Add SEATLABELS if not present ───
    if (!seatLabelsExists) {
        var slGroup = targetLayer.groupItems.add();
        slGroup.name = "SEATLABELS";
        // Move to front (last in z-order = top)
        slGroup.zOrder(ZOrderMethod.BRINGTOFRONT);
        report.push("\n  SEATLABELS group created (empty, as required).");
    }

    // ─── Final report ───
    var msg = "Zones created successfully!\n";
    msg += "─────────────────────────\n";
    msg += report.join("\n") + "\n\n";
    msg += "Hierarchy per zone:\n";
    msg += "  ZONE_{name}\n";
    msg += "    \u251C SECTION          (auto bounding shape)\n";
    msg += "    \u251C UNDERSEATDECORATION (empty)\n";
    msg += "    \u251C SEAT             (seats moved here)\n";
    msg += "    \u251C SEATDECORATION      (empty)\n";
    msg += "    \u2514 SECTIONDECORATION(label + badge)\n\n";
    msg += "Remember to verify seat IDs and\n";
    msg += "adjust section shapes if needed.";
    alert(msg);

})();
