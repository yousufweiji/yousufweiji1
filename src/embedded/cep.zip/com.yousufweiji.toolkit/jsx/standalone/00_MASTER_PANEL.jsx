//@target illustrator
#targetengine "platinumlist"
#include "lib/_SOP_CORE.jsx"
#include "lib/_HELPERS.jsx"

// PLATINUMLIST MASTER PANEL v6.5.1
//   - Merged HEAL + VALIDATE + EXPORT into one section
//   - Added "Run All (Validate -> Fix -> Export)" chain button
//   - Added 4 new utility scripts (referenced from workspace root)

var dlg = new Window("palette", "Platinumlist Hall Map v6.5.1", undefined);
dlg.orientation = "column";
dlg.alignChildren = "fill";
dlg.preferredSize.width = 360;

var header = dlg.add("panel");
header.add("statictext", undefined, "PLATINUMLIST HALL MAP TOOLKIT");
header.add("statictext", undefined, "SOP May 2026 | v" + SOP.VERSION + " (canonical names)");

// Resolve workspace root (two levels above standalone/)
//   .../com.yousufweiji.toolkit/jsx/standalone/00_MASTER_PANEL.jsx
//   workspace root = parent.parent.parent
var SCRIPT_DIR = File($.fileName).parent;                       // standalone/
var TOOLKIT_DIR = SCRIPT_DIR.parent.parent;                     // com.yousufweiji.toolkit/
var WORKSPACE_ROOT = TOOLKIT_DIR.parent;                        // PlatinumlistHallMap_v5_UNIFIED/

function runStd(rel) { $.evalFile(SCRIPT_DIR + "/" + rel); }
function runRoot(rel) {
 var engine=new File(SCRIPT_DIR.parent.fsName+"/sopFunctions.jsx");
 if(!engine.open("r")){alert("Missing core: "+engine.fsName);return;}
 var code=engine.read();engine.close();eval(code);
 if(rel==="17-SeatsToZone.jsx"){
  alert(seatsToZoneScan());if(!confirm("Build zones from the selected seats?"))return;alert(seatsToZoneBuild("{}"));
 }else if(rel==="18-ConvertToSeatShape.jsx"){
  if(confirm("Replace selected shapes with 7 x 7 seats?"))alert(convertToSeatShape("{}"));
 }else if(rel==="19-ResizeSeats.jsx"){
  if(confirm("Resize/reflow selected seats?"))alert(seatResizerRun("{}"));
 }else if(rel==="LayerToggle.jsx"){
  var action=prompt("Layer action: show or hide", "show");if(action==="show"||action==="hide")alert(layerToggleBulk(action==="show"?"showAll":"hideAll"));
 }
}

// IMPORT
var pImport = dlg.add("panel", undefined, "IMPORT FROM SOURCE");
pImport.orientation = "column"; pImport.alignChildren = "fill";
pImport.add("button", undefined, "Image (PNG/JPG) -> SVG").onClick = function(){
  runStd("IMPORT/IMG_TO_SVG.jsx");
};
pImport.add("button", undefined, "PDF Layout -> SVG").onClick = function(){
  runStd("IMPORT/PDF_TO_SVG.jsx");
};
pImport.add("button", undefined, "JSON (Ticketing) -> SVG").onClick = function(){
  runStd("IMPORT/JSON_TO_SVG.jsx");
};
pImport.add("button", undefined, "Excel/CSV Manifest -> Layout").onClick = function(){
  runStd("IMPORT/EXCEL_TO_LAYOUT.jsx");
};

// BUILD
var pBuild = dlg.add("panel", undefined, "BUILD FROM SCRATCH");
pBuild.orientation = "column"; pBuild.alignChildren = "fill";
pBuild.add("button", undefined, "Grid (Theatre)").onClick = function(){
  runStd("BUILD/GRID_BUILDER.jsx");
};
pBuild.add("button", undefined, "Arc (Curved/Amphitheatre)").onClick = function(){
  runStd("BUILD/ARC_BUILDER.jsx");
};

pBuild.add("button",undefined,"8 Map Layouts / 12 Stage Shapes").onClick=function(){runStd("BUILD/MAP_STAGE_BUILDER.jsx");};

// VALIDATE / FIX / EXPORT  (merged from HEAL + VALIDATE + EXPORT)
var pVFE = dlg.add("panel", undefined, "VALIDATE / FIX / EXPORT");
pVFE.orientation = "column"; pVFE.alignChildren = "fill";

// Run All chain — validate -> fix -> export
var btnRunAll = pVFE.add("button", undefined, "*** Run All (Validate -> Fix -> Export) ***");
btnRunAll.onClick = function(){
  var doc;
  try { doc = app.activeDocument; }
  catch(e) { alert("No document open."); return; }

  var report = [];
  var failed = false;

  function step(label, file) {
    if (failed) return;
    try {
      report.push("[ STEP ] " + label);
      $.evalFile(file);
      report.push("   -> done");
    } catch (e) {
      report.push("   -> FAILED: " + e);
      failed = true;
    }
  }

  // 1. VALIDATE
  step("Validate (50-Item QA)",   SCRIPT_DIR + "/VALIDATE/QA_50_ITEMS.jsx");

  // 2. FIX (heal/clean)
  step("Fix - Remove unwanted",   SCRIPT_DIR + "/HEAL/REMOVE_UNWANTED.jsx");
  step("Fix - Auto-heal",         SCRIPT_DIR + "/HEAL/AUTO_HEALER.jsx");

  // 3. EXPORT
  step("Export - SOP SVG",        SCRIPT_DIR + "/EXPORT/SOP_EXPORT.jsx");
  step("Export - Optimize SVG",   SCRIPT_DIR + "/EXPORT/OPTIMIZE_SVG.jsx");

  alert("RUN ALL " + (failed ? "STOPPED" : "COMPLETE") + "\n\n" + report.join("\n"));
};

pVFE.add("statictext", undefined, "------------------------------");

// Validate
pVFE.add("statictext", undefined, "Validate:");
pVFE.add("button", undefined, "  Run 50-Item QA").onClick = function(){
  runStd("VALIDATE/QA_50_ITEMS.jsx");
};
pVFE.add("button", undefined, "  Preview Overlay").onClick = function(){
  runStd("VALIDATE/PREVIEW_OVERLAY.jsx");
};

// Fix
pVFE.add("statictext", undefined, "Fix / Heal:");
pVFE.add("button", undefined, "  Remove Unwanted Paths").onClick = function(){
  runStd("HEAL/REMOVE_UNWANTED.jsx");
};
pVFE.add("button", undefined, "  Auto-Heal Everything").onClick = function(){
  runStd("HEAL/AUTO_HEALER.jsx");
};

// Export
pVFE.add("statictext", undefined, "Export:");
pVFE.add("button", undefined, "  SOP Export SVG").onClick = function(){
  runStd("EXPORT/SOP_EXPORT.jsx");
};
pVFE.add("button", undefined, "  Optimize SVG").onClick = function(){
  runStd("EXPORT/OPTIMIZE_SVG.jsx");
};

// UTILITY  (4 new scripts referenced from workspace root + existing SeatsToZone)
var pUtil = dlg.add("panel", undefined, "UTILITY");
pUtil.orientation = "column"; pUtil.alignChildren = "fill";

pUtil.add("button", undefined, "Seats -> Zone (select seats first)").onClick = function(){
  runRoot("17-SeatsToZone.jsx");
};
pUtil.add("button", undefined, "Convert -> 7x7 Seat Shape").onClick = function(){
  runRoot("18-ConvertToSeatShape.jsx");
};
pUtil.add("button", undefined, "Resize & Reflow Seats (7x7 / 9px)").onClick = function(){
  runRoot("19-ResizeSeats.jsx");
};
pUtil.add("button", undefined, "Layer Toggle (Show/Hide/Solo)").onClick = function(){
  runRoot("LayerToggle.jsx");
};

dlg.add("button", undefined, "Close").onClick = function(){ dlg.close(); };
dlg.show();
