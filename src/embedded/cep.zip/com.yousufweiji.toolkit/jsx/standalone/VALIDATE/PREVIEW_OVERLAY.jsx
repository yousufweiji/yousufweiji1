//@target illustrator
#include "../lib/_SOP_CORE.jsx"
#include "../lib/_HELPERS.jsx"

// PREVIEW OVERLAY v6.5.1 — Visual seat count + zone outline check

(function(){
  if(app.documents.length===0){alert("No document open.");return;}
  var doc=app.activeDocument;
  var seatCount=0;
  var zoneData=[];

  function walk(parent,zoneName){
    if(isSeatLayer(parent.name)){
      for(var i=0;i<parent.pathItems.length;i++){
        if(parent.pathItems[i].name&&parent.pathItems[i].name.indexOf('seatData-')===0){
          seatCount++;
        }
      }
    }
    for(var l=0;l<parent.layers.length;l++){
      var ln=parent.layers[l].name;
      var zn=zoneName;
      if(ln.indexOf('ZONE')===0) zn=ln;
      walk(parent.layers[l],zn);
    }
  }

  // Count seats per zone
  var zones={};
  function countPerZone(parent,zn){
    if(isSeatLayer(parent.name)){
      for(var i=0;i<parent.pathItems.length;i++){
        if(parent.pathItems[i].name&&parent.pathItems[i].name.indexOf('seatData-')===0){
          if(!zones[zn]) zones[zn]=0;
          zones[zn]++;
        }
      }
    }
    for(var l=0;l<parent.layers.length;l++){
      var ln=parent.layers[l].name;
      var newZn=zn;
      if(ln.indexOf('ZONE')===0) newZn=ln;
      countPerZone(parent.layers[l],newZn);
    }
  }
  countPerZone(doc,'ROOT');

  var report='SEAT COUNT PREVIEW\n══════════════════\n\n';
  var total=0;
  for(var z in zones){
    if(!zones.hasOwnProperty(z)) continue;
    report+=z+': '+zones[z]+' seats\n';
    total+=zones[z];
  }
  report+='\nTOTAL: '+total+' seats\n';

  // Check hierarchy
  report+='\nHIERARCHY CHECK\n';
  var layers=['STAGE','DECORATION','SEATLABELS'];
  for(var li=0;li<layers.length;li++){
    try{doc.layers.getByName(layers[li]);report+=layers[li]+': FOUND\n';}
    catch(e){report+=layers[li]+': MISSING\n';}
  }

  var dlg=new Window("dialog","Preview Overlay");
  dlg.preferredSize.width=400;
  var txt=dlg.add("edittext",undefined,report,{multiline:true,scrolling:true});
  txt.minimumSize=[380,300];
  dlg.add("button",undefined,"OK");
  dlg.show();
})();
