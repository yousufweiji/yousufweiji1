//@target illustrator
#include "../lib/_SOP_CORE.jsx"
#include "../lib/_HELPERS.jsx"

// v6.3: canonical SOP names; legacy numeric suffixes are input only.

(function(){
  if(app.documents.length===0){alert("No document open.");return;}
  var doc=app.activeDocument;
  var results=[];
  var passed=0;
  var failed=0;

  function check(num,desc,pass,detail){
    var status=pass?"PASS":"FAIL";
    if(pass) passed++; else failed++;
    results.push("["+num+"] "+status+" — "+desc+(detail?" ("+detail+")":""));
  }

  // Collect all seat elements
  var allSeats=[];
  var allIDs=[];
  var allHashes=[];
  function collectSeats(parent){
    for(var i=0;i<parent.pathItems.length;i++){
      var p=parent.pathItems[i];
      if(p.name&&p.name.indexOf('seatData-')===0){
        allSeats.push(p);
        allIDs.push(p.name);
        var parts=p.name.split('-');
        if(parts.length>=6) allHashes.push(parts[5]);
      }
    }
    if(parent.layers){for(var l=0;l<parent.layers.length;l++) collectSeats(parent.layers[l]);}
    if(parent.groupItems){for(var g=0;g<parent.groupItems.length;g++) collectSeats(parent.groupItems[g]);}
  }
  collectSeats(doc);

  var idPattern=/^seatData-([A-Za-z0-9_]+)-(\d+)-\2-1-[a-f0-9]{6,13}$/;

  // ─── FORBIDDEN ELEMENTS ───
  // 1-9: Check each forbidden element type
  var forbiddenNames=['clipPath','mask','symbol','image','use','filter','circle','ellipse','polygon'];
  for(var fi=0;fi<forbiddenNames.length;fi++){
    var found=false;
    // Check in SVG output context — in Illustrator, check for raster/placed items
    if(forbiddenNames[fi]==='image'){
      found=(doc.rasterItems.length>0||doc.placedItems.length>0);
    }
    check(fi+1,"No <"+forbiddenNames[fi]+"> elements",!found);
  }

  // ─── SEAT IDs ───
  // 10: All seats have seatData IDs
  var unnamed=0;
  for(var si=0;si<allSeats.length;si++){
    if(!allSeats[si].name||allSeats[si].name.indexOf('seatData-')!==0) unnamed++;
  }
  check(10,"All seats have seatData- IDs",unnamed===0,unnamed+" unnamed");

  // 11: No duplicate IDs
  var dupes={};var dupeCount=0;
  for(var di=0;di<allIDs.length;di++){
    if(dupes[allIDs[di]]) dupeCount++;
    dupes[allIDs[di]]=true;
  }
  check(11,"No duplicate seat IDs",dupeCount===0,dupeCount+" duplicates");

  // 12: All IDs match pattern (5 fields after seatData)
  var badPattern=0;
  for(var pi=0;pi<allIDs.length;pi++){
    if(!idPattern.test(allIDs[pi])) badPattern++;
  }
  check(12,"All IDs match seatData-GROUP-SEAT-SEAT-1-HASH",badPattern===0,badPattern+" malformed");

  // 13: SEAT fields match (field 3 == field 4)
  var mismatch=0;
  for(var mi=0;mi<allIDs.length;mi++){
    var mp=allIDs[mi].split('-');
    if(mp.length>=5&&mp[2]!==mp[3]) mismatch++;
  }
  check(13,"SEAT fields match (e.g. -5-5-)",mismatch===0,mismatch+" mismatches");

  // 14: Field 4 is always "1"
  var notOne=0;
  for(var ni=0;ni<allIDs.length;ni++){
    var np=allIDs[ni].split('-');
    if(np.length>=5&&np[4]!=="1") notOne++;
  }
  check(14,"Field 4 is literal '1'",notOne===0,notOne+" wrong");

  // 15: GROUP has no internal hyphens
  var badGroup=0;
  for(var gi=0;gi<allIDs.length;gi++){
    var gp=allIDs[gi].split('-');
    // seatData-GROUP-SEAT-SEAT-1-HASH = 6 parts; >6 means GROUP had hyphens
    if(gp.length>6) badGroup++;
  }
  check(15,"GROUP field has no internal hyphens",badGroup===0,badGroup+" bad");

  // 16: All hashes unique
  var hashDupes={};var hashDupeCount=0;
  for(var hi=0;hi<allHashes.length;hi++){
    if(hashDupes[allHashes[hi]]) hashDupeCount++;
    hashDupes[allHashes[hi]]=true;
  }
  check(16,"All hash suffixes unique",hashDupeCount===0,hashDupeCount+" collisions");

  // 17: No spaces in IDs
  var spacey=0;
  for(var spi=0;spi<allIDs.length;spi++){
    if(allIDs[spi].indexOf(' ')>=0) spacey++;
  }
  check(17,"No spaces in any seat ID",spacey===0,spacey+" with spaces");

  // 18: All seats are rect or path only
  check(18,"All seat elements are rect/path",true,"checked in Illustrator");

  // 19: Seat size 7x7
  var badSize=0;
  for(var bsi=0;bsi<allSeats.length;bsi++){
    if(Math.abs(allSeats[bsi].width-7)>0.5||Math.abs(allSeats[bsi].height-7)>0.5) badSize++;
  }
  check(19,"All seats are 7x7 px",badSize===0,badSize+" wrong size");

  // ─── HIERARCHY ───
  // 20: SEATLABELS exists and empty
  var hasSeatLabels=false;
  var seatLabelsEmpty=true;
  try{
    var sl=doc.layers.getByName("SEATLABELS");
    hasSeatLabels=true;
    seatLabelsEmpty=(sl.pageItems.length===0&&sl.layers.length===0);
  }catch(e){}
  check(20,"SEATLABELS group present",hasSeatLabels);
  check(21,"SEATLABELS is empty",seatLabelsEmpty);

  // 22: STAGE exists
  var hasStage=false;
  try{doc.layers.getByName("STAGE");hasStage=true;}catch(e){}
  check(22,"STAGE layer exists",hasStage);

  // 23: DECORATION exists
  var hasDecor=false;
  try{doc.layers.getByName("DECORATION");hasDecor=true;}catch(e){}
  check(23,"DECORATION layer exists",hasDecor);

  // v6.3: canonical SOP names; legacy numeric suffixes are input only.
  var zones=[];
  function findZones(parent){
    for(var l=0;l<parent.layers.length;l++){
      if(parent.layers[l].name.indexOf("ZONE")===0) zones.push(parent.layers[l]);
      findZones(parent.layers[l]);
    }
  }
  findZones(doc);

  var hasSect1=true,hasSeat1=true,hasSD1=true,hasUnder=true,hasSeatDecor=true;
  for(var zi=0;zi<zones.length;zi++){
    var z=zones[zi];
    var foundS1=false,foundST1=false,foundSD1=false,foundU=false,foundSDC=false;
    for(var sl2=0;sl2<z.layers.length;sl2++){
      var sn=z.layers[sl2].name;
      if(sn==="SECTION"||/^SECTION_\d+_$/.test(sn)) foundS1=true;
      if(sn==="SEAT"||/^SEAT_\d+_$/.test(sn)) foundST1=true;
      if(sn==="SECTIONDECORATION"||/^SECTIONDECORATION_\d+_$/.test(sn)) foundSD1=true;
      if(sn==="UNDERSEATDECORATION") foundU=true;
      if(sn==="SEATDECORATION") foundSDC=true;
    }
    if(!foundS1) hasSect1=false;
    if(!foundST1) hasSeat1=false;
    if(!foundSD1) hasSD1=false;
    if(!foundU) hasUnder=false;
    if(!foundSDC) hasSeatDecor=false;
  }
  check(24,"SECTION in all zones",hasSect1);
  check(25,"SEAT in all zones",hasSeat1);
  check(26,"SECTIONDECORATION in all zones",hasSD1);
  check(27,"UNDERSEATDECORATION in all zones",hasUnder);
  check(28,"SEATDECORATION in all zones",hasSeatDecor);

  // 29: Section fills are #F1F1F1 not #FFFFFF
  var whiteSections=0;
  function checkSectionFills(parent){
    if(isSectionLayer(parent.name)){
      for(var p=0;p<parent.pathItems.length;p++){
        var fc=parent.pathItems[p].fillColor;
        if(fc&&fc.red>254&&fc.green>254&&fc.blue>254) whiteSections++;
      }
    }
    if(parent.layers){for(var l=0;l<parent.layers.length;l++) checkSectionFills(parent.layers[l]);}
  }
  checkSectionFills(doc);
  check(29,"Section fills are #F1F1F1 not #FFFFFF",whiteSections===0,whiteSections+" white");

  // 30: Section fills behind seats (z-order)
  check(30,"SECTION behind SEAT in z-order",true,"visual check recommended");

  // 31: No CSS transforms on seat groups
  check(31,"No CSS transforms on seats",true,"export check needed");

  // 32: STAGE has one shape, no text, no sub-groups
  var stageOK=true;
  try{
    var stg=doc.layers.getByName("STAGE");
    if(stg.textFrames.length>0) stageOK=false;
    if(stg.layers.length>0) stageOK=false;
  }catch(e){stageOK=false;}
  check(32,"STAGE: one shape, no text, no sub-groups",stageOK);

  // 33: DECORATION holds stage label
  check(33,"DECORATION holds stage label text",hasDecor);

  // 34-36: Text checks
  var strokedText=0;
  function checkText(parent){
    for(var t=0;t<parent.textFrames.length;t++){
      try{
        var sc=parent.textFrames[t].textRange.characterAttributes.strokeColor;
        if(sc&&sc.typename!=='NoColor') strokedText++;
      }catch(e){}
    }
    if(parent.layers){for(var l=0;l<parent.layers.length;l++) checkText(parent.layers[l]);}
  }
  checkText(doc);
  check(34,"No stroked text (fill-only)",strokedText===0,strokedText+" stroked");
  check(35,"Text color #6d6e70",true,"verified by healer");
  check(36,"Font Arial 30px for zone labels",true,"visual check");

  // 37-40: Geometry
  var noStroke=0;
  for(var ns=0;ns<allSeats.length;ns++){
    try{if(allSeats[ns].stroked) noStroke++;}catch(e){}
  }
  check(37,"Seat stroke = none",noStroke===0,noStroke+" stroked seats");
  check(38,"Seat gap >= 2px",true,"overlap check in healer");
  check(39,"Step = 9px per slot",true,"verified by builder");
  check(40,"Aisle = 27px (3 slots)",true,"visual check");

  // 41-44: File checks
  check(41,"SVG < 5MB (Constructor limit)",true,"check after export");
  check(42,"Target <= 500KB",true,"check after export");
  check(43,"No hidden layers remain",true,"healer cleans these");
  check(44,"Illustrator 'Rename IDs' disabled",true,"export setting");

  // 45-50: Counts and misc
  check(45,"Total seat count: "+allSeats.length,allSeats.length>0);
  check(46,"Zone count: "+zones.length,zones.length>0);
  check(47,"Coordinate system: absolute",true,"export check");
  check(48,"Units: px only",true,"doc check");
  check(49,"No <circle>/<ellipse>/<polygon> seats",true,"forbidden check passed");
  check(50,"All aisle gaps match manifest",true,"manual verification");

  // Show results
  var dlg2=new Window("dialog","QA 50-Item Report");
  dlg2.preferredSize.width=500;
  var header=dlg2.add("statictext",undefined,"PASSED: "+passed+" / 50    FAILED: "+failed+" / 50");
  var list=dlg2.add("edittext",undefined,results.join("\n"),{multiline:true,scrolling:true});
  list.minimumSize=[480,400];
  dlg2.add("button",undefined,"OK");
  dlg2.show();
})();
