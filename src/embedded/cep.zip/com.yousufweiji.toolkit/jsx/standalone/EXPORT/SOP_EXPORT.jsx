#target illustrator
(function(){
 var engine=new File(new File($.fileName).parent.parent.parent.fsName+"/sopFunctions.jsx");
 if(!engine.exists){alert("Missing core: "+engine.fsName);return;}
 // evalFile inside this private function confines core helper names to this execution.
 engine.encoding="UTF-8";
 if(!engine.open("r")){alert("Cannot read core");return;}
 var code=engine.read();engine.close();
 eval(code);
 alert(stripAndExport());
})();
