//@target illustrator
#include "../lib/_SOP_CORE.jsx"
#include "../lib/_HELPERS.jsx"

// OPTIMIZE SVG v6.5.1 — Strip metadata, reduce decimals, compress

(function(){
  var f=File.openDialog("Select SVG to optimize","SVG:*.svg");
  if(!f) return;
  f.open('r');f.encoding='UTF-8';
  var content=f.read();
  f.close();
  var origSize=content.length;

  // 1. Strip XML comments
  content=content.replace(/<!--[\s\S]*?-->/g,'');

  // 2. Strip metadata blocks
  content=content.replace(/<metadata[\s\S]*?<\/metadata>/gi,'');

  // 3. Strip empty defs
  content=content.replace(/<defs\s*\/>/gi,'');
  content=content.replace(/<defs>\s*<\/defs>/gi,'');

  // 4. Strip Illustrator-specific attributes
  content=content.replace(/\s+xmlns:x="[^"]*"/g,'');
  content=content.replace(/\s+xmlns:i="[^"]*"/g,'');
  content=content.replace(/\s+i:[a-zA-Z]+="[^"]*"/g,'');
  content=content.replace(/\s+x:i="[^"]*"/g,'');

  // 5. Reduce decimal places to 2
  // Preserve geometry, IDs and text; global numeric replacement is unsafe.

  // 6. Collapse whitespace (but not inside text content)
  content=content.replace(/\n\s*\n/g,'\n');
  content=content.replace(/\t/g,' ');
  content=content.replace(/  +/g,' ');

  // 7. Strip forbidden elements if any leaked through
  var forbidden=SOP.FORBIDDEN;
  for(var i=0;i<forbidden.length;i++){
    var tag=forbidden[i];
    var re=new RegExp('<'+tag+'[\\s\\S]*?(\\/'+tag+'>|\\/>)','gi');
    if(re.test(content)){alert('Optimization blocked: unsupported '+tag+'. Use the SOP export or Studio repair tools.');return;}
  }

  var newSize=content.length;
  var saved=origSize-newSize;
  var pct=Math.round((saved/origSize)*100);

  // Save
  var outPath=f.fsName.replace(/\.svg$/i,'_optimized.svg');
  var out=new File(outPath);
  out.open('w');out.encoding='UTF-8';
  out.write(content);
  out.close();

  alert("SVG Optimized!\n\nBefore: "+Math.round(origSize/1024)+" KB\nAfter: "+Math.round(newSize/1024)+" KB\nSaved: "+Math.round(saved/1024)+" KB ("+pct+"%)\n\nFile: "+outPath);
})();
