//@target illustrator
#include "../lib/_SOP_CORE.jsx"
#include "../lib/_HELPERS.jsx"

// REMOVE UNWANTED PATHS v6.5.1 — Scans & removes forbidden elements + stray objects

(function(){
  if(app.documents.length===0){alert("No document open.");return;}
  var doc=app.activeDocument;
  var report={hidden:0,zero:0,tiny:0,stray:0,empty:0,locked:0,raster:0};
  var toRemove=[];

  function walk(parent){
    var items;
    try{items=parent.pageItems;}catch(e){return;}
    for(var i=items.length-1;i>=0;i--){
      var it=items[i];
      if(/^(SECTION|UNDERSEATDECORATION|SEAT|SEATDECORATION|SECTIONDECORATION|SEATLABELS|STAGE|DECORATION)(?:_\d+_)?$/.test(it.name))continue;
      try{
        if(it.hidden){report.hidden++;toRemove.push(it);continue;}
        if(it.width===0&&it.height===0){report.zero++;toRemove.push(it);continue;}
        if(it.width<2&&it.height<2&&(!it.name||it.name.indexOf('seatData')!==0)){
          report.tiny++;toRemove.push(it);continue;
        }
        if(it.typename==='RasterItem'||it.typename==='PlacedItem'){
          report.raster++;toRemove.push(it);continue;
        }
        if(it.typename==='GroupItem'&&it.pageItems.length===0){
          report.empty++;toRemove.push(it);continue;
        }
      }catch(e){}
    }
    if(parent.layers){for(var l=0;l<parent.layers.length;l++) walk(parent.layers[l]);}
    if(parent.groupItems){for(var g=0;g<parent.groupItems.length;g++) walk(parent.groupItems[g]);}
  }

  function countLocked(parent){
    for(var i=0;i<parent.layers.length;i++){
      if(parent.layers[i].locked) report.locked++;
      if(parent.layers[i].layers.length) countLocked(parent.layers[i]);
    }
  }

  walk(doc);
  countLocked(doc);
  var total=report.hidden+report.zero+report.tiny+report.raster+report.empty;

  var dlg=new Window("dialog","Remove Unwanted Report");
  dlg.preferredSize.width=380;
  var p1=dlg.add("panel",undefined,"Scan Results");
  p1.alignChildren="left";p1.alignment="fill";
  p1.add("statictext",undefined,"Hidden items: "+report.hidden);
  p1.add("statictext",undefined,"Zero-size: "+report.zero);
  p1.add("statictext",undefined,"Tiny non-seat (<2px): "+report.tiny);
  p1.add("statictext",undefined,"Raster/placed images: "+report.raster);
  p1.add("statictext",undefined,"Empty groups: "+report.empty);
  p1.add("statictext",undefined,"Locked layers: "+report.locked);
  p1.add("statictext",undefined,"TOTAL removable: "+total);
  var btnGrp=dlg.add("group");
  var removeBtn=btnGrp.add("button",undefined,"Remove All ("+total+")");
  var cancelBtn=btnGrp.add("button",undefined,"Cancel");
  removeBtn.onClick=function(){
    var removed=0;
    for(var r=0;r<toRemove.length;r++){try{toRemove[r].remove();removed++;}catch(e){}}
    alert("Removed "+removed+" items.");dlg.close();
  };
  cancelBtn.onClick=function(){dlg.close();};
  dlg.show();
})();
