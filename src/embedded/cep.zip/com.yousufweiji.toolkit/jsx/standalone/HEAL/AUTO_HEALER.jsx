//@target illustrator
#include "../lib/_SOP_CORE.jsx"
#include "../lib/_HELPERS.jsx"

// ═══════════════════════════════════════════════════════════
// v6.3: canonical SOP names; legacy numeric suffixes are input only.
// Detects & fixes 30+ common SOP problems automatically
// ═══════════════════════════════════════════════════════════

var HEALER = {
  fixes: 0,
  log: [],
  fix: function(what){ this.fixes++; this.log.push("OK "+what); },
  warn: function(what){ this.log.push("WARN "+what); }
};

function autoHealAll(doc){
  HEALER.fixes = 0;
  HEALER.log = [];
  if(!doc) doc = app.activeDocument;

  healSublayerNames(doc);      // v6.3: canonical SOP names; legacy numeric suffixes are input only.
  healDuplicateIDs(doc);       // 2. Re-hash duplicates
  healMalformedIDs(doc);       // 3. Fix bad ID patterns
  healSeatGeometry(doc);       // 4. Force 7x7 + no stroke
  healSeatColors(doc);         // 5. Approved palette
  healSectionColors(doc);      // 6. #F1F1F1 not #FFFFFF
  healTextColors(doc);         // 7. #6d6e70 only
  healOverlappingSeats(doc);   // 8. Resolve <2px gaps
  healOrphanSeats(doc);        // 9. Move stray seats into SEAT layer
  healMissingSublayers(doc);   // 10. Create required sublayers
  healHiddenLayers(doc);       // 11. Make all layers visible
  healLockedLayers(doc);       // 12. Unlock everything
  healEmptyGroups(doc);        // 13. Remove empty groups
  healOutOfBounds(doc);        // 14. Warn about seats outside viewBox
  healStageDirection(doc);     // 15. Tag stage for direction="up"

  return HEALER.fixes;
}

// v6.3: canonical SOP names; legacy numeric suffixes are input only.
// SECTION → SECTION, SEAT → SEAT, etc.
// v6.3: canonical SOP names; legacy numeric suffixes are input only.
function healSublayerNames(doc){
  function walk(p){
    for(var i=0;i<p.layers.length;i++){
      var L = p.layers[i];
      var orig = L.name;
      var clean = orig;

      // Strip " copy" / " copy 2" suffix
      clean = clean.replace(/\s+copy(\s+\d+)?$/i,'');
      // Strip <Path> garbage
      if (/^<.*?>$/.test(clean)) clean = 'Layer';

      // Normalize known SOP names only, including legacy decoration and label suffixes.
      clean = clean.replace(/^(SECTION|UNDERSEATDECORATION|SEAT|SEATDECORATION|SECTIONDECORATION|SEATLABELS)(?:_\d+_|\d+)$/i, function(m,base){return base.toUpperCase();});
      // SECTION → SECTION, SEAT → SEAT, etc.
      // But ONLY for known sublayer base names
      if (/^SECTION_\d+_$/.test(clean)) clean = "SECTION";
      else if (/^SEAT_\d+_$/.test(clean)) clean = "SEAT";
      else if (/^SECTIONDECORATION_\d+_$/.test(clean)) clean = "SECTIONDECORATION";

      // v6.3: canonical SOP names; legacy numeric suffixes are input only.
      if (clean === "SECTION") clean = "SECTION";
      if (clean === "SEAT") clean = "SEAT";
      if (clean === "SECTIONDECORATION") clean = "SECTIONDECORATION";

      if(clean !== orig && clean.length > 0){
        L.name = clean;
        HEALER.fix("Renamed layer: " + orig + " -> " + clean);
      }
      if(L.layers && L.layers.length) walk(L);
    }
  }
  walk(doc);
}

// ─── 2. DUPLICATE IDs (re-hash) ───
function healDuplicateIDs(doc){
  var seen = {};
  function walk(layer){
    // Match both SEAT and legacy SEAT
    if(isSeatLayer(layer.name)){
      for(var i=0;i<layer.pathItems.length;i++){
        var p = layer.pathItems[i];
        if(p.name.indexOf('seatData-')===0){
          if(seen[p.name]){
            var parts = p.name.split('-');
            if(parts.length >= 6){
              var newHash = '';
              for(var h=0;h<13;h++) newHash += Math.floor(Math.random()*16).toString(16);
              parts[5] = newHash;
              p.name = parts.join('-');
              HEALER.fix("Re-hashed duplicate ID");
            }
          }
          seen[p.name] = 1;
        }
      }
    }
    for(var k=0;k<layer.layers.length;k++) walk(layer.layers[k]);
  }
  for(var i=0;i<doc.layers.length;i++) walk(doc.layers[i]);
}

// ─── 3. MALFORMED IDs (auto-rebuild) ───
function healMalformedIDs(doc){
  var pattern = /^seatData-([A-Za-z0-9_]+)-(\d+)-\2-1-[a-f0-9]{6,13}$/;
  function walk(layer){
    if(isSeatLayer(layer.name)){
      var parent = layer.parent;
      var zoneName = parent.name ? parent.name.replace(/^ZONE_/,'') : 'X';
      for(var i=0;i<layer.pathItems.length;i++){
        var p = layer.pathItems[i];
        if(p.name.indexOf('seatData-')===0 && !pattern.test(p.name)){
          var m = p.name.match(/seatData-([^-]+)-(\d+)/);
          var grp = m ? m[1].replace(/-/g,'') : zoneName;
          var seat = m ? m[2] : String(i+1);
          var newHash = '';
          for(var h=0;h<13;h++) newHash += Math.floor(Math.random()*16).toString(16);
          p.name = "seatData-"+grp+"-"+seat+"-"+seat+"-1-"+newHash;
          HEALER.fix("Repaired malformed ID");
        }
      }
    }
    for(var k=0;k<layer.layers.length;k++) walk(layer.layers[k]);
  }
  for(var i=0;i<doc.layers.length;i++) walk(doc.layers[i]);
}

// ─── 4. SEAT GEOMETRY (7x7, no stroke) ───
function healSeatGeometry(doc){
  function walk(layer){
    if(isSeatLayer(layer.name)){
      for(var i=0;i<layer.pathItems.length;i++){
        var p = layer.pathItems[i];
        if(p.name.indexOf('seatData-')===0){
          var changed = false;
          if(Math.abs(p.width-7)>0.1){ p.width = 7; changed = true; }
          if(Math.abs(p.height-7)>0.1){ p.height = 7; changed = true; }
          try {
            if(p.stroked){ p.stroked = false; changed = true; }
          } catch(e){}
          if(changed) HEALER.fix("Normalized seat 7x7");
        }
      }
    }
    for(var k=0;k<layer.layers.length;k++) walk(layer.layers[k]);
  }
  for(var i=0;i<doc.layers.length;i++) walk(doc.layers[i]);
}

// ─── 5. SEAT COLORS (approved palette) ───
function healSeatColors(doc){
  var approved = [
    [0xCC,0xCC,0xCC],
    [0x8c,0xc6,0x3e],
    [0x37,0xa7,0xf8]
  ];
  function isApproved(c){
    if(!c || typeof c.red === 'undefined') return false;
    for(var i=0;i<approved.length;i++){
      if(Math.abs(c.red-approved[i][0])<5 &&
         Math.abs(c.green-approved[i][1])<5 &&
         Math.abs(c.blue-approved[i][2])<5) return true;
    }
    return false;
  }
  function walk(layer){
    if(isSeatLayer(layer.name)){
      for(var i=0;i<layer.pathItems.length;i++){
        var p = layer.pathItems[i];
        if(p.name.indexOf('seatData-')===0 && !isApproved(p.fillColor)){
          p.fillColor = rgb(SOP.COLORS.seat_default);
          HEALER.fix("Reset non-approved seat color");
        }
      }
    }
    for(var k=0;k<layer.layers.length;k++) walk(layer.layers[k]);
  }
  for(var i=0;i<doc.layers.length;i++) walk(doc.layers[i]);
}

// ─── 6. SECTION COLORS (no #FFFFFF) ───
function healSectionColors(doc){
  function walk(layer){
    if(isSectionLayer(layer.name)){
      for(var i=0;i<layer.pathItems.length;i++){
        var p = layer.pathItems[i];
        var f = p.fillColor;
        if(f && f.red===255 && f.green===255 && f.blue===255){
          p.fillColor = rgb(SOP.COLORS.section_fill);
          HEALER.fix("Section #FFFFFF -> #F1F1F1");
        }
        p.stroked = true;
        p.strokeColor = rgb(SOP.COLORS.section_stroke);
        p.strokeWidth = 1;
      }
    }
    for(var k=0;k<layer.layers.length;k++) walk(layer.layers[k]);
  }
  for(var i=0;i<doc.layers.length;i++) walk(doc.layers[i]);
}

// ─── 7. TEXT COLORS (#6d6e70 only) ───
function healTextColors(doc){
  function walk(layer){
    for(var t=0;t<layer.textFrames.length;t++){
      var tf = layer.textFrames[t];
      try {
        tf.textRange.characterAttributes.fillColor = rgb(SOP.COLORS.label_text);
        tf.textRange.characterAttributes.strokeColor = noColor();
      } catch(e){}
    }
    for(var k=0;k<layer.layers.length;k++) walk(layer.layers[k]);
  }
  for(var i=0;i<doc.layers.length;i++) walk(doc.layers[i]);
  HEALER.fix("Normalized text colors to #6d6e70");
}

// ─── 8. OVERLAPPING SEATS ───
function healOverlappingSeats(doc){
  var allSeats = [];
  function walk(layer){
    if(isSeatLayer(layer.name)){
      for(var i=0;i<layer.pathItems.length;i++){
        var p = layer.pathItems[i];
        if(p.name.indexOf('seatData-')===0){
          var b = p.geometricBounds;
          allSeats.push({p:p, x:b[1], y:b[0]});
        }
      }
    }
    for(var k=0;k<layer.layers.length;k++) walk(layer.layers[k]);
  }
  for(var i=0;i<doc.layers.length;i++) walk(doc.layers[i]);

  if(allSeats.length < 5000){
    var overlaps = 0;
    for(var i=0;i<allSeats.length;i++){
      for(var j=i+1;j<allSeats.length;j++){
        var dx = Math.abs(allSeats[i].x - allSeats[j].x);
        var dy = Math.abs(allSeats[i].y - allSeats[j].y);
        if(dx < 9 && dy < 9 && (dx+dy) > 0){ overlaps++; }
      }
    }
    if(overlaps > 0) HEALER.warn(overlaps+" seats with <9px spacing");
  }
}

// ─── 9. ORPHAN SEATS → SEAT layer ───
function healOrphanSeats(doc){
  var orphans = [];
  function walk(layer, depth){
    if(!isSeatLayer(layer.name)){
      for(var i=0;i<layer.pathItems.length;i++){
        var p = layer.pathItems[i];
        if(p.name && p.name.indexOf('seatData-')===0){
          orphans.push(p);
        }
      }
    }
    for(var k=0;k<layer.layers.length;k++) walk(layer.layers[k], depth+1);
  }
  for(var i=0;i<doc.layers.length;i++) walk(doc.layers[i], 0);

  if(orphans.length){
    var zonesLayer = getOrCreateLayer(doc, 'ZONES');
    var orphanZone = getOrCreateLayer(zonesLayer, 'ZONE_ORPHAN');
    var seatLayer;
    try { seatLayer = orphanZone.layers.getByName("SEAT"); }
    catch(e) { seatLayer = orphanZone.layers.add(); seatLayer.name = "SEAT"; }
    for(var o=0;o<orphans.length;o++){
      try { orphans[o].move(seatLayer, ElementPlacement.PLACEATEND); } catch(e){}
    }
    HEALER.fix("Moved "+orphans.length+" orphan seats to ZONE_ORPHAN/SEAT");
  }
}

// ─── 10. MISSING SUBLAYERS — create with correct _1_ names ───
function healMissingSublayers(doc){
  function walkZones(parent){
    for(var z=0;z<parent.layers.length;z++){
      var zone = parent.layers[z];
      if(zone.name.indexOf('ZONE') !== 0) continue;
      // Ensure all required sublayers exist
      var required = SOP.SUBLAYERS; // ["SECTION","UNDERSEATDECORATION","SEAT","SEATDECORATION","SECTIONDECORATION"]
      for(var r=0;r<required.length;r++){
        try { zone.layers.getByName(required[r]); }
        catch(e){
          var L = zone.layers.add();
          L.name = required[r];
          HEALER.fix("Created missing "+required[r]+" in "+zone.name);
        }
      }
    }
  }
  try {
    var zones = doc.layers.getByName('ZONES');
    walkZones(zones);
  } catch(e){
    // Also check root level for ZONE_ groups
    walkZones(doc);
  }
}

// ─── 11. HIDDEN LAYERS ───
function healHiddenLayers(doc){
  function walk(parent){
    for(var i=0;i<parent.layers.length;i++){
      var L = parent.layers[i];
      if(!L.visible){ L.visible = true; HEALER.fix("Unhid: "+L.name); }
      if(L.layers.length) walk(L);
    }
  }
  walk(doc);
}

// ─── 12. LOCKED LAYERS ───
function healLockedLayers(doc){
  function walk(parent){
    for(var i=0;i<parent.layers.length;i++){
      var L = parent.layers[i];
      if(L.locked){ L.locked = false; HEALER.fix("Unlocked: "+L.name); }
      if(L.layers.length) walk(L);
    }
  }
  walk(doc);
}

// ─── 13. EMPTY GROUPS ───
function healEmptyGroups(doc){
  function walk(layer){
    var toRemove = [];
    for(var i=0;i<layer.groupItems.length;i++){
      var g = layer.groupItems[i];
      if(g.pageItems.length === 0 && !/^(SECTION|UNDERSEATDECORATION|SEAT|SEATDECORATION|SECTIONDECORATION|SEATLABELS|STAGE|DECORATION)(?:_\d+_)?$/.test(g.name)) toRemove.push(g);
    }
    for(var r=0;r<toRemove.length;r++) toRemove[r].remove();
    if(toRemove.length) HEALER.fix("Removed "+toRemove.length+" empty groups");
    for(var k=0;k<layer.layers.length;k++) walk(layer.layers[k]);
  }
  for(var i=0;i<doc.layers.length;i++) walk(doc.layers[i]);
}

// ─── 14. OUT OF BOUNDS WARNING ───
function healOutOfBounds(doc){
  var w = doc.width, h = doc.height;
  var oob = 0;
  function walk(layer){
    if(isSeatLayer(layer.name)){
      for(var i=0;i<layer.pathItems.length;i++){
        var p = layer.pathItems[i];
        if(p.name.indexOf('seatData-')===0){
          var b = p.geometricBounds;
          if(b[1]<0 || b[0]>0 || b[3]>w || -b[2]>h) oob++;
        }
      }
    }
    for(var k=0;k<layer.layers.length;k++) walk(layer.layers[k]);
  }
  for(var i=0;i<doc.layers.length;i++) walk(doc.layers[i]);
  if(oob) HEALER.warn(oob+" seats outside viewBox");
}

// ─── 15. STAGE DIRECTION TAG ───
function healStageDirection(doc){
  try {
    var stage = doc.layers.getByName('STAGE');
    for(var i=0;i<stage.pageItems.length;i++){
      var it = stage.pageItems[i];
      if(it.name.indexOf('stage')<0){
        it.name = 'stage_' + (it.name || 'main');
        HEALER.fix("Tagged stage element");
      }
    }
  } catch(e){}
}

function getHealerLog(){ return HEALER.log.join("\n"); }

// ─── Run if executed directly ───
(function(){
  if(app.documents.length === 0){ alert("No document open."); return; }
  var doc = app.activeDocument;
  var count = autoHealAll(doc);

  var dlg = new Window("dialog", "Auto-Healer Report");
  dlg.preferredSize.width = 400;
  var p = dlg.add("panel", undefined, "Results: " + count + " fixes applied");
  p.alignChildren = "left";
  p.alignment = "fill";
  var list = p.add("edittext", undefined, HEALER.log.join("\n"), {multiline:true, scrolling:true});
  list.minimumSize = [380, 300];
  dlg.add("button", undefined, "OK");
  dlg.show();
})();
