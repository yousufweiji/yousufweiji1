//@target illustrator
#include "../lib/_SOP_CORE.jsx"
#include "../lib/_platinumlist_lib.jsx"

// JSON TO SVG v6.5.1 — Ticketing partner map converter, canonical sublayer names

(function(){
  var dlg=new Window('dialog','JSON to SVG Converter');
  dlg.preferredSize.width=450;
  dlg.add('statictext',undefined,'JSON -> SVG SEAT MAP');

  var fGrp=dlg.add('group');
  var fInput=fGrp.add('edittext',undefined,'',{size:[320,25]});
  var browseBtn=fGrp.add('button',undefined,'Browse');

  var optP=dlg.add('panel',undefined,'Options');
  optP.alignment='fill';
  var fmtGrp=optP.add('group');
  fmtGrp.add('statictext',undefined,'Format:');
  var fmtDD=fmtGrp.add('dropdownlist',undefined,[
    'Auto-detect','Ticketmaster','Eventbrite','AXS','SeatGeek','Generic Array'
  ]);
  fmtDD.selection=0;
  var scGrp=optP.add('group');
  scGrp.add('statictext',undefined,'Scale:');
  var scaleInput=scGrp.add('edittext',undefined,'1.0',{size:[60,25]});

  var btnGrp=dlg.add('group');
  var buildBtn=btnGrp.add('button',undefined,'BUILD');
  var cancelBtn=btnGrp.add('button',undefined,'Cancel');

  var selectedFile=null;
  browseBtn.onClick=function(){
    var f=File.openDialog("Select JSON file","JSON:*.json");
    if(f){selectedFile=f;fInput.text=f.fsName;}
  };

  buildBtn.onClick=function(){
    if(!selectedFile){alert('Select a JSON file first.');return;}
    var scale=parseFloat(scaleInput.text)||1.0;
    dlg.close();

    try{
      selectedFile.open('r');selectedFile.encoding='UTF-8';
      var raw=selectedFile.read();
      selectedFile.close();
      var data=eval('('+raw+')');

      var doc;
      if(app.documents.length===0){
        doc=app.documents.add(DocumentColorSpace.RGB,5000,4000);
      }else{
        doc=app.activeDocument;
      }
      ensureSOPLayers(doc);
      var zonesLayer=getOrCreateLayer(doc,'ZONES');

      // Normalize data to [{zone,row,seat,x,y}]
      var seats=[];
      if(data.sections){
        // Ticketmaster-style: {sections:[{name,rows:[{name,seats:[{num,x,y}]}]}]}
        for(var s=0;s<data.sections.length;s++){
          var sec=data.sections[s];
          var secName=sec.name||sec.label||String(s+1);
          if(sec.rows){
            for(var r=0;r<sec.rows.length;r++){
              var row=sec.rows[r];
              var rowName=row.name||row.label||String.fromCharCode(65+r);
              if(row.seats){
                for(var st=0;st<row.seats.length;st++){
                  var seat=row.seats[st];
                  seats.push({
                    zone:secName,row:rowName,
                    seat:seat.num||seat.number||seat.id||(st+1),
                    x:(seat.x||seat.cx||st*SOP.STEP)*scale,
                    y:(seat.y||seat.cy||r*SOP.STEP)*scale
                  });
                }
              }
            }
          }
        }
      }else if(data instanceof Array){
        // Generic flat array
        for(var a=0;a<data.length;a++){
          var item=data[a];
          seats.push({
            zone:item.zone||item.section||item.area||'A',
            row:item.row||'A',
            seat:item.seat||item.number||item.num||(a+1),
            x:(item.x||item.cx||0)*scale,
            y:(item.y||item.cy||0)*scale
          });
        }
      }

      if(seats.length===0){alert('No seats found in JSON.');return;}

      // Normalize coords (shift to positive space)
      var minX=Infinity,minY=Infinity;
      for(var n=0;n<seats.length;n++){
        if(seats[n].x<minX)minX=seats[n].x;
        if(seats[n].y<minY)minY=seats[n].y;
      }
      var offsetX=50-minX;
      var offsetY=50-minY;

      // Group by zone
      var zoneMap={};
      for(var z=0;z<seats.length;z++){
        var zn=seats[z].zone.replace(/[^A-Za-z0-9]/g,'');
        if(!zoneMap[zn])zoneMap[zn]=[];
        zoneMap[zn].push(seats[z]);
      }

      var totalSeats=0;
      for(var zoneName in zoneMap){
        if(!zoneMap.hasOwnProperty(zoneName)) continue;
        var zSeats=zoneMap[zoneName];
        var zoneLayer=getOrCreateLayer(zonesLayer,'ZONE_'+zoneName);

        // v6.3: canonical SOP names; legacy numeric suffixes are input only.
        var secLayer=getOrCreateLayer(zoneLayer,'SECTION');
        getOrCreateLayer(zoneLayer,'UNDERSEATDECORATION');
        var seatLayer=getOrCreateLayer(zoneLayer,'SEAT');
        getOrCreateLayer(zoneLayer,'SEATDECORATION');
        var sdLayer=getOrCreateLayer(zoneLayer,'SECTIONDECORATION');

        var bMinX=Infinity,bMinY=Infinity,bMaxX=-Infinity,bMaxY=-Infinity;
        for(var si=0;si<zSeats.length;si++){
          var s=zSeats[si];
          var sx=s.x+offsetX;
          var sy=s.y+offsetY;
          var rect=seatLayer.pathItems.rectangle(-sy,sx,SOP.SEAT_W,SOP.SEAT_H);
          rect.fillColor=rgb(SOP.COLORS.seat_default);
          rect.stroked=false;
          var grp=zoneName+(s.row||'').replace(/-/g,'');
          rect.name=makeSeatID(grp,s.seat);
          totalSeats++;
          if(sx<bMinX)bMinX=sx;
          if(sx+7>bMaxX)bMaxX=sx+7;
          if(sy<bMinY)bMinY=sy;
          if(sy+7>bMaxY)bMaxY=sy+7;
        }

        // Section background
        var pad=8;
        var bg=secLayer.pathItems.rectangle(-(bMinY-pad),bMinX-pad,bMaxX-bMinX+pad*2,bMaxY-bMinY+pad*2);
        bg.fillColor=rgb(SOP.COLORS.section_fill);
        bg.stroked=true;bg.strokeColor=rgb(SOP.COLORS.section_stroke);bg.strokeWidth=1;

        // Label
        var lbl=sdLayer.textFrames.add();
        lbl.contents=zoneName;
        lbl.textRange.characterAttributes.size=30;
        lbl.textRange.characterAttributes.fillColor=rgb(SOP.COLORS.label_text);
        try{lbl.textRange.characterAttributes.textFont=app.textFonts.getByName("ArialMT");}catch(e){}
        lbl.left=(bMinX+bMaxX)/2-lbl.width/2;
        lbl.top=-(bMinY+bMaxY)/2+lbl.height/2;
      }

      getOrCreateLayer(doc,'SEATLABELS');
      alert('JSON converted!\n'+totalSeats+' seats created across zones.\nRun QA 50 to verify.');
    }catch(e){
      alert('Error: '+e);
    }
  };

  cancelBtn.onClick=function(){dlg.close();};
  dlg.show();
})();
