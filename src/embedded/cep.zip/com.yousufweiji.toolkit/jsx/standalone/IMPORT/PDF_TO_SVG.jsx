//@target illustrator
#include "../lib/_SOP_CORE.jsx"
#include "../lib/_HELPERS.jsx"

// PDF TO SVG v6.5.1 — PDF layout converter, canonical sublayer names

(function(){
  var dlg=new Window('dialog','PDF to SVG Converter');
  dlg.preferredSize.width=420;
  dlg.add('statictext',undefined,'PDF -> SVG SEAT MAP');

  var fGrp=dlg.add('group');
  var fInput=fGrp.add('edittext',undefined,'',{size:[300,25]});
  var browseBtn=fGrp.add('button',undefined,'Browse');

  var optP=dlg.add('panel',undefined,'Options');
  optP.alignment='fill';
  var g1=optP.add('group');
  g1.add('statictext',undefined,'Scale:');
  var scaleInput=g1.add('edittext',undefined,'1.0',{size:[60,25]});
  g1.add('statictext',undefined,'Min seat size:');
  var minInput=g1.add('edittext',undefined,'4',{size:[40,25]});
  g1.add('statictext',undefined,'Max:');
  var maxInput=g1.add('edittext',undefined,'12',{size:[40,25]});
  var cbRemove=optP.add('checkbox',undefined,'Remove non-seat junk');
  cbRemove.value=true;
  var cbNorm=optP.add('checkbox',undefined,'Normalize seats to 7x7');
  cbNorm.value=true;
  var cbBuild=optP.add('checkbox',undefined,'Build SOP hierarchy');
  cbBuild.value=true;

  var btnGrp=dlg.add('group');
  var buildBtn=btnGrp.add('button',undefined,'CONVERT');
  var cancelBtn=btnGrp.add('button',undefined,'Cancel');

  var selectedFile=null;
  browseBtn.onClick=function(){
    var f=File.openDialog("Select PDF","PDF:*.pdf");
    if(f){selectedFile=f;fInput.text=f.fsName;}
  };

  buildBtn.onClick=function(){
    if(!selectedFile){alert('Select a PDF first.');return;}
    var scale=parseFloat(scaleInput.text)||1.0;
    var seatMin=parseFloat(minInput.text)||4;
    var seatMax=parseFloat(maxInput.text)||12;
    var removeJunk=cbRemove.value;
    var normalize=cbNorm.value;
    var buildSOP=cbBuild.value;
    dlg.close();

    try{
      // Open PDF
      var pdfOpts=new PDFFileOptions();
      pdfOpts.pageToOpen=1;
      pdfOpts.pDFCropToBox=PDFBoxType.PDFMEDIABOX;
      var doc=app.open(selectedFile,DocumentColorSpace.RGB,pdfOpts);

      // Categorize all paths
      var seats=[];
      var junk=[];
      var sections=[];

      function categorize(parent){
        for(var i=parent.pathItems.length-1;i>=0;i--){
          var p=parent.pathItems[i];
          try{
            var w=p.width;
            var h=p.height;
            if(w>=seatMin&&w<=seatMax&&h>=seatMin&&h<=seatMax){
              seats.push(p);
            }else if(w>50&&h>30){
              sections.push(p);
            }else if(w<2||h<2){
              junk.push(p);
            }
          }catch(e){}
        }
        if(parent.layers){for(var l=0;l<parent.layers.length;l++) categorize(parent.layers[l]);}
        if(parent.groupItems){for(var g=0;g<parent.groupItems.length;g++) categorize(parent.groupItems[g]);}
      }
      categorize(doc);

      // Remove junk
      var removedCount=0;
      if(removeJunk){
        for(var j=0;j<junk.length;j++){
          try{junk[j].remove();removedCount++;}catch(e){}
        }
      }

      // Normalize seats to 7x7
      if(normalize){
        for(var s=0;s<seats.length;s++){
          try{
            seats[s].width=SOP.SEAT_W;
            seats[s].height=SOP.SEAT_H;
            seats[s].stroked=false;
            seats[s].fillColor=rgb(SOP.COLORS.seat_default);
          }catch(e){}
        }
      }

      // Build SOP hierarchy
      if(buildSOP){
        ensureSOPLayers(doc);
        var zonesLayer=getOrCreateLayer(doc,'ZONES');
        var zoneLayer=getOrCreateLayer(zonesLayer,'ZONE_A');

        // v6.3: canonical SOP names; legacy numeric suffixes are input only.
        var secLayer=getOrCreateLayer(zoneLayer,'SECTION');
        getOrCreateLayer(zoneLayer,'UNDERSEATDECORATION');
        var seatLayer=getOrCreateLayer(zoneLayer,'SEAT');
        getOrCreateLayer(zoneLayer,'SEATDECORATION');
        var sdLayer=getOrCreateLayer(zoneLayer,'SECTIONDECORATION');

        // Move seats into SEAT
        for(var ms=seats.length-1;ms>=0;ms--){
          try{
            var grp='A';
            seats[ms].name=makeSeatID(grp+'A',ms+1);
            seats[ms].move(seatLayer,ElementPlacement.PLACEATEND);
          }catch(e){}
        }

        // Create section background from bounds
        if(seats.length>0){
          var bMinX=Infinity,bMinY=Infinity,bMaxX=-Infinity,bMaxY=-Infinity;
          for(var bs=0;bs<seats.length;bs++){
            try{
              var b=seats[bs].geometricBounds;
              if(b[1]<bMinX)bMinX=b[1];
              if(b[0]>bMaxY)bMaxY=b[0]; // AI coords: top is positive
              if(b[3]>bMaxX)bMaxX=b[3];
              if(b[2]<bMinY)bMinY=b[2];
            }catch(e){}
          }
          var pad=10;
          var bg=secLayer.pathItems.rectangle(bMaxY+pad,bMinX-pad,bMaxX-bMinX+pad*2,bMaxY-bMinY+pad*2);
          bg.fillColor=rgb(SOP.COLORS.section_fill);
          bg.stroked=true;bg.strokeColor=rgb(SOP.COLORS.section_stroke);bg.strokeWidth=1;
        }

        getOrCreateLayer(doc,'SEATLABELS');
      }

      alert('PDF Converted!\n\nSeats found: '+seats.length+'\nJunk removed: '+removedCount+'\nSections detected: '+sections.length+'\n\nRun Auto-Healer then QA 50 to verify.');
    }catch(e){
      alert('Error: '+e);
    }
  };

  cancelBtn.onClick=function(){dlg.close();};
  dlg.show();
})();
