//@target illustrator
#include "../lib/_SOP_CORE.jsx"
#include "../lib/_HELPERS.jsx"

// EXCEL/CSV TO LAYOUT v6.5.1 — Manifest to seat map, canonical sublayer names

(function(){
  var f=File.openDialog("Select CSV manifest","CSV:*.csv;*.txt");
  if(!f) return;
  f.open('r');f.encoding='UTF-8';
  var raw=f.read();
  f.close();

  var lines=raw.split(/\r?\n/);
  if(lines.length<2){alert("CSV has no data rows.");return;}

  var headers=lines[0].split(/[,\t]/);
  var zoneIdx=-1,rowIdx=-1,seatIdx=-1,countIdx=-1;
  for(var h=0;h<headers.length;h++){
    var hh=headers[h].toUpperCase().replace(/[" ]/g,'');
    if(hh.indexOf('ZONE')>=0||hh.indexOf('SECTION')>=0) zoneIdx=h;
    if(hh.indexOf('ROW')>=0) rowIdx=h;
    if((hh==='SEAT'||hh.indexOf('SEAT')>=0)&&hh.indexOf('COUNT')<0) seatIdx=h;
    if(hh.indexOf('COUNT')>=0||hh.indexOf('TOTAL')>=0) countIdx=h;
  }
  if(zoneIdx<0){alert("No ZONE/SECTION column found in CSV.");return;}

  // Parse into zone/row structure
  var zoneMap={};
  for(var i=1;i<lines.length;i++){
    var line=lines[i].replace(/^\s+|\s+$/g,'');
    if(!line) continue;
    var cells=line.split(/[,\t]/);
    var zoneName=(cells[zoneIdx]||'A').replace(/[" ]/g,'');
    var rowName=rowIdx>=0?(cells[rowIdx]||'A').replace(/[" ]/g,''):'A';
    var seatNum=seatIdx>=0?parseInt(cells[seatIdx])||1:1;
    var count=countIdx>=0?parseInt(cells[countIdx])||1:1;

    if(!zoneMap[zoneName]) zoneMap[zoneName]={};
    if(!zoneMap[zoneName][rowName]) zoneMap[zoneName][rowName]=0;
    if(countIdx>=0){
      zoneMap[zoneName][rowName]=Math.max(zoneMap[zoneName][rowName],count);
    }else{
      zoneMap[zoneName][rowName]=Math.max(zoneMap[zoneName][rowName],seatNum);
    }
  }

  // Build
  var doc;
  if(app.documents.length===0){
    doc=app.documents.add(DocumentColorSpace.RGB,5000,4000);
  }else{
    doc=app.activeDocument;
  }
  ensureSOPLayers(doc);
  var zonesLayer=getOrCreateLayer(doc,'ZONES');

  var startY=100;
  var zoneGap=40;
  var totalSeats=0;

  for(var zn in zoneMap){
    if(!zoneMap.hasOwnProperty(zn)) continue;
    var zoneLayer=getOrCreateLayer(zonesLayer,'ZONE_'+zn);

    // v6.3: canonical SOP names; legacy numeric suffixes are input only.
    var secLayer=getOrCreateLayer(zoneLayer,'SECTION');
    getOrCreateLayer(zoneLayer,'UNDERSEATDECORATION');
    var seatLayer=getOrCreateLayer(zoneLayer,'SEAT');
    getOrCreateLayer(zoneLayer,'SEATDECORATION');
    var sdLayer=getOrCreateLayer(zoneLayer,'SECTIONDECORATION');

    var startX=100;
    var rowKeys=[];
    for(var rk in zoneMap[zn]){if(zoneMap[zn].hasOwnProperty(rk)) rowKeys.push(rk);}
    rowKeys.sort();

    var maxCols=0;
    for(var ri=0;ri<rowKeys.length;ri++){
      var rowName=rowKeys[ri];
      var cols=zoneMap[zn][rowName];
      if(cols>maxCols) maxCols=cols;
      for(var c=0;c<cols;c++){
        var sx=startX+c*SOP.STEP;
        var sy=startY+ri*SOP.STEP;
        var seat=seatLayer.pathItems.rectangle(-sy,sx,SOP.SEAT_W,SOP.SEAT_H);
        seat.fillColor=rgb(SOP.COLORS.seat_default);
        seat.stroked=false;
        var grp=zn+rowName.replace(/-/g,'');
        seat.name=makeSeatID(grp,c+1);
        totalSeats++;
      }
    }

    // Section background
    var pad=8;
    var secW=maxCols*SOP.STEP+pad*2;
    var secH=rowKeys.length*SOP.STEP+pad*2;
    var bg=secLayer.pathItems.rectangle(-(startY-pad),startX-pad,secW,secH);
    bg.fillColor=rgb(SOP.COLORS.section_fill);
    bg.stroked=true;bg.strokeColor=rgb(SOP.COLORS.section_stroke);bg.strokeWidth=1;

    // Label
    var lbl=sdLayer.textFrames.add();
    lbl.contents=zn;
    lbl.textRange.characterAttributes.size=30;
    lbl.textRange.characterAttributes.fillColor=rgb(SOP.COLORS.label_text);
    try{lbl.textRange.characterAttributes.textFont=app.textFonts.getByName("ArialMT");}catch(e){}
    lbl.left=startX+secW/2-lbl.width/2;
    lbl.top=-(startY+secH/2-lbl.height/2);

    startY+=rowKeys.length*SOP.STEP+zoneGap;
  }

  getOrCreateLayer(doc,'SEATLABELS');
  alert('CSV manifest converted!\n'+totalSeats+' seats created.\nRun QA 50 to verify.');
})();
