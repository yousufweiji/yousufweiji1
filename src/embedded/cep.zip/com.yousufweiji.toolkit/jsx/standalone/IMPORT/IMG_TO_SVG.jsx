//@target illustrator
#include "../lib/_SOP_CORE.jsx"
#include "../lib/_platinumlist_lib.jsx"

// IMAGE TO SEAT MAP v6.5.1 — canonical sublayer names

(function(){
  var dlg=new Window('dialog','Image to Seat Map');
  dlg.preferredSize=[500,400];
  dlg.add('statictext',undefined,'IMAGE -> SEAT MAP CONVERTER');

  var fGrp=dlg.add('group');
  var fInput=fGrp.add('edittext',undefined,'',{size:[350,25]});
  var browseBtn=fGrp.add('button',undefined,'Browse');

  var optP=dlg.add('panel',undefined,'Configuration');
  optP.alignment='fill';
  var sGrp=optP.add('group');
  sGrp.add('statictext',undefined,'Scale %:');
  var scaleInput=sGrp.add('edittext',undefined,'100',{size:[60,25]});
  var mGrp=optP.add('group');
  mGrp.add('statictext',undefined,'Mode:');
  var modeDD=mGrp.add('dropdownlist',undefined,[
    'Reference Only','Grid Overlay','Smart Detect','Full Auto'
  ]);
  modeDD.selection=0;
  var secGrp=optP.add('group');
  secGrp.add('statictext',undefined,'Sections:');
  var secInput=secGrp.add('edittext',undefined,'4',{size:[50,25]});
  var opGrp=optP.add('group');
  opGrp.add('statictext',undefined,'Ref opacity %:');
  var opInput=opGrp.add('edittext',undefined,'40',{size:[50,25]});

  var btnGrp=dlg.add('group');
  var processBtn=btnGrp.add('button',undefined,'PROCESS');
  var cancelBtn=btnGrp.add('button',undefined,'Cancel');

  var selectedFile=null;
  browseBtn.onClick=function(){
    var f=File.openDialog("Select image","Images:*.png;*.jpg;*.jpeg;*.tif;*.bmp");
    if(f){selectedFile=f;fInput.text=f.fsName;}
  };

  processBtn.onClick=function(){
    if(!selectedFile){alert('Select an image first.');return;}
    var scale=parseInt(scaleInput.text)||100;
    var mode=modeDD.selection.index;
    var sections=parseInt(secInput.text)||4;
    var opacity=parseInt(opInput.text)||40;
    dlg.close();

    try{
      var doc;
      if(app.documents.length===0){
        doc=app.documents.add(DocumentColorSpace.RGB,5000,4000);
      }else{
        doc=app.activeDocument;
      }

      // Place reference image
      var refLayer=PL.getOrCreate(doc,'REFERENCE_IMAGE');
      refLayer.locked=false;
      var placed=refLayer.placedItems.add();
      placed.file=selectedFile;
      placed.position=[0,0];
      if(scale!==100) placed.resize(scale,scale);
      refLayer.opacity=opacity;
      var imgW=placed.width;
      var imgH=placed.height;
      doc.artboards[0].artboardRect=[0,0,imgW,-imgH];

      // Create SOP layers
      for(var i=0;i<PL.LAYER_ORDER.length;i++){
        PL.getOrCreate(doc,PL.LAYER_ORDER[i]);
      }

      var seatCount=0;

      if(mode===0){
        alert('Reference placed. Trace seats manually.\nOpacity: '+opacity+'%');
      }
      else if(mode===1){
        // Grid overlay
        var gridLayer=PL.getOrCreate(doc,'GRID_HELPER');
        for(var gx=0;gx<imgW;gx+=PL.STEP*10){
          var vl=gridLayer.pathItems.add();
          vl.setEntirePath([[gx,0],[gx,-imgH]]);
          vl.strokeColor=PL.rgb({r:100,g:100,b:255});
          vl.strokeWidth=0.25;
          vl.fillColor=PL.noColor();
        }
        for(var gy=0;gy<imgH;gy+=PL.STEP*10){
          var hl=gridLayer.pathItems.add();
          hl.setEntirePath([[0,-gy],[imgW,-gy]]);
          hl.strokeColor=PL.rgb({r:100,g:100,b:255});
          hl.strokeWidth=0.25;
          hl.fillColor=PL.noColor();
        }
        gridLayer.locked=true;
        alert('Grid overlay created ('+PL.STEP*10+'px). Place seats on grid.');
      }
      else if(mode===2||mode===3){
        // Smart detect / Full auto
        var zonesLayer=doc.layers.getByName('ZONES');
        var secW=imgW/Math.ceil(Math.sqrt(sections));
        var secH=imgH/Math.ceil(sections/Math.ceil(Math.sqrt(sections)));
        var sIdx=0;

        for(var sy=0;sy<imgH;sy+=secH){
          for(var sx=0;sx<imgW;sx+=secW){
            if(sIdx>=sections) break;
            var zoneName=String.fromCharCode(65+sIdx);
            var zoneLayer=PL.getOrCreate(zonesLayer,'ZONE_'+zoneName);

            // v6.3: canonical SOP names; legacy numeric suffixes are input only.
            var seatLayer=PL.getOrCreate(zoneLayer,'SEAT');
            var secLayer=PL.getOrCreate(zoneLayer,'SECTION');
            PL.getOrCreate(zoneLayer,'UNDERSEATDECORATION');
            PL.getOrCreate(zoneLayer,'SEATDECORATION');

            // Section background
            var innerW=Math.min(secW-20,imgW-sx-20);
            var innerH=Math.min(secH-20,imgH-sy-20);
            var secRect=secLayer.pathItems.rectangle(-(sy+10),sx+10,innerW,innerH);
            secRect.fillColor=PL.rgb(PL.COLORS.section);
            secRect.strokeColor=PL.rgb(PL.COLORS.stroke);
            secRect.strokeWidth=1;

            // Estimate seat grid
            var margin=30;
            var iW=innerW-margin*2;
            var iH=innerH-margin*2;
            var cols=Math.floor(iW/PL.STEP);
            var rows=Math.floor(iH/PL.STEP);
            var rowLabels=[];
            for(var ri=0;ri<rows;ri++){
              if(ri<26) rowLabels.push(String.fromCharCode(65+ri));
              else rowLabels.push(String.fromCharCode(65+Math.floor(ri/26)-1)+String.fromCharCode(65+(ri%26)));
            }

            for(var r=0;r<rows;r++){
              for(var c=0;c<cols;c++){
                var seatX=sx+margin+c*PL.STEP;
                var seatY=sy+margin+r*PL.STEP;
                var seat=seatLayer.pathItems.rectangle(-seatY,seatX,PL.SEAT_W,PL.SEAT_H);
                seat.fillColor=PL.rgb(PL.COLORS.seat);
                seat.stroked=false;
                seat.name=PL.seatID(zoneName+rowLabels[r],c+1,seatCount);
                seatCount++;
              }
            }

            // FIXED: Label in SECTIONDECORATION
            var decoLayer=PL.getOrCreate(zoneLayer,'SECTIONDECORATION');
            var label=decoLayer.textFrames.add();
            label.contents=zoneName;
            label.position=[sx+innerW/2-10,-(sy+innerH+15)];
            label.textRange.characterAttributes.fillColor=PL.rgb(PL.COLORS.text);
            label.textRange.characterAttributes.size=30;
            try{label.textRange.characterAttributes.textFont=app.textFonts.getByName("ArialMT");}catch(e){}

            sIdx++;
          }
        }

        refLayer.locked=true;
        PL.getOrCreate(doc,'SEATLABELS');
        alert('Generated '+seatCount+' seats in '+sections+' sections.\nReview against reference image.');
      }
    }catch(e){
      alert('Error: '+e);
    }
  };

  cancelBtn.onClick=function(){dlg.close();};
  dlg.show();
})();
