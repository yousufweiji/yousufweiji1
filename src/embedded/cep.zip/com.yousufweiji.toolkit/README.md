# Yousufweiji Hall Map Toolkit 6.5.1

CEP-only build. Production Studio is removed.

## Install

1. Close Illustrator completely.
2. Back up the existing com.yousufweiji.toolkit extension folder outside the CEP extensions directory.
3. Extract this ZIP. Put its com.yousufweiji.toolkit folder in %APPDATA%\Adobe\CEP\extensions\ as a clean replacement, not a merge. The manifest must be at com.yousufweiji.toolkit\CSXS\manifest.xml.
4. Reopen Illustrator and open Window > Extensions > Yousufweiji Hall Map Toolkit. Confirm the bridge reports operational. Retain your existing CEP debug configuration for this unsigned extension.

Build > Stage+ offers twelve stage shapes, dimensions, rotation and artboard-relative placement. Create > Stage uses the same builder.

Prebuild offers eight layouts. Names appear above the section's upper edge. Matching outline keeps seats visible; White overlay covers seats like the supplied reference. Generate creates a new document.

ScriptUI fallback: run jsx/standalone/00_MASTER_PANEL.jsx through File > Scripts > Other Script; choose 8 Map Layouts / 12 Stage Shapes.

Validate+Export > Inspect SVG file checks a saved SVG without changing it. Advanced > QA 50 distinguishes measured results from pending review.

Read CHANGELOG.md and VALIDATION_REPORT.md. Live Illustrator verification remains necessary.
