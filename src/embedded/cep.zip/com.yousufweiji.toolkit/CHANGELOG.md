# 6.5.1 — Advanced tab repair

Fixed the missing Advanced-mode navigation handlers. Previously the Import page remained visible when another mode was clicked. All ten tiles now switch their corresponding pages. Native buttons also support keyboard activation and expose the selected state.

Fixed a duplicate btnStripMeta ID shared by Fix and Advanced > Optimize. The Advanced metadata action now has its own ID and handler.

Retains the 6.5.0 SOP upgrade, stage options, Prebuild layouts and ScriptUI. Production Studio remains removed. Versions updated together to 6.5.1.

Validation: reproduced the original navigation failure in 6.5.0, then tested all ten modes, all 46 action-button bindings, ten representative mocked host dispatches, Enter/Space activation and leaving/reopening Advanced. No browser page errors. Static syntax/ES3, public API, DOM references, duplicate DOM IDs, script includes and host references passed. Manifest XML parsed; ZIP CRC verified.

This patch fixes panel navigation and wiring. Actual Illustrator execution of every Advanced operation has not been tested; browser dispatch tests use a simulated bridge.

Install: close Illustrator, replace the existing com.yousufweiji.toolkit folder with the folder from this ZIP (do not merge), then reopen Illustrator.

## Prior upgrade
# Yousufweiji Hall Map Toolkit 6.5.0

SOP reliability update to the approved 6.4.0 CEP build. Production Studio stays removed. The twelve stage options, eight map layouts, matching SECTIONDECORATION geometry, above-edge zone names and ScriptUI fallback are retained.

## Corrected

- Aligned builder/healer/shared ScriptUI text colour to #6d6e70 and section stroke to #D1D2D4. Updated displayed SOP guidance.
- Colour correction preserves label font size and position instead of resetting labels to 30 px.
- Removed export renaming rules that could silently truncate legitimate numbered zones, including ZONE_A12 and ZONE_VIP2026.
- Stage direction injection now also runs after canonical suffix normalization, targeting the STAGE shape. Unrelated direction attributes no longer prevent insertion; explicit stage directions remain unchanged.
- Fixed hexadecimal colour conversion so zero channels remain zero: black and pure green no longer become fallback colours.
- Replaced the legacy 50-item report's hard-coded successes with measured PASS/FAIL results and explicit PENDING checks. Traverses both groups and layers without counting flattened collection items twice.
- Reports duplicate IDs/hashes, malformed IDs, exact coincident seats, minimum two-pixel bounding-box gaps, hidden artwork, canonical naming, section/stage structure, empty SEATLABELS, active-artboard bounds and SOP colours.
- Replaced the quadratic overlap scan and incorrect artboard-coordinate comparisons in the corresponding healer checks.
- Group-based section/text healers and missing-sublayer repair now handle generated maps. Blocked edits are reported.
- Orphan detection no longer relocates seats to a guessed ZONE_ORPHAN. It identifies them for explicit zone assignment, preserving source positions and zone intent.

## Added

Validate+Export > Inspect SVG file: a read-only browser XML check for malformed XML, forbidden elements, duplicated seat IDs/hashes, malformed seat numbers, suffixed containers, stage shape/direction, nonempty SEATLABELS, seat rectangle dimensions/rounding, transforms, hidden nodes, colours and file-size limits. SVG content is parsed without embedding it in the panel. Existing files are unchanged.

The inspector marks CSS-dependent checks, path curvature and source/runtime checks for review. It does not replace comparison with the approved manifest or Constructor staging.

## Compatibility

All previously supplied public ExtendScript function names remain. JSX is ES3-compatible. Manifest, panel, bridge marker and ScriptUI versions are 6.5.0. The installed extension was not modified; use the supplied clean replacement ZIP.
