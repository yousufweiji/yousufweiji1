# SOP reference decisions

Reviewed all extracted text from Platinumlist_ULTIMATE_FINAL_SOP.pdf (May 2026, five pages) and Platinumlist_HallMap_Technical_Appendix_March2026.pdf (13 pages). Rendered and visually reviewed the full QA checklist and runtime stage/seat-contract page.

- May SOP pp.1,4: 7 x 7 seats, 1.5 px rounding, 2 px minimum gap, section #F1F1F1, section stroke #D1D2D4, label #6d6e70, stage #E0E0E0/#CCCCCC. These guide the corrections and inspection checks.
- May SOP pp.2,4: use matching repeated seat numbers and unique 6–13 lowercase hex hashes. The appendix's example validator contains a different/inconsistent seat regex; it was not copied. Five fields means five payload fields AFTER the seatData prefix (six split tokens).
- May SOP pp.4–5: visual comparisons, manifest checks, Constructor staging and sign-off require evidence. The panel no longer marks these passed automatically.
- Appendix A1/A2/A7: server-processed runtime SVG and seat JSON are different from authoring SVG. Authored seats are retained; this update does not remove them or fabricate server configuration, r/p attributes or runtime classes.
- Appendix A1.4/A8: STAGE must be unique and have one shape; direction is required. Missing direction defaults to up on clean export, while explicit up/down/left/right values are retained.
- Appendix A1.2: authored nodes must not carry do-not-save-this-node. SVG inspection detects that temporary runtime class.
- Appendix A11's legacy suffixed names do not override the newer May SOP's strict canonical names.
- User-approved full-section decoration and ABOVE-edge labels take precedence over the small label badge illustrated in the SOP template. That approved geometry is preserved.
- The supplied documents do not establish this venue's complete approved seat palette, source fidelity, manifest or live staging result. Those checks remain pending.

This was a local code review against supplied documents, not a new verification of the live Platinumlist runtime or server APIs.
